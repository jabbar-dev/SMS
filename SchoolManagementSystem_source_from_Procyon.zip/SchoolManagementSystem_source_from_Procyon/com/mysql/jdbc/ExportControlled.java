// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.io.IOException;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class ExportControlled
{
    protected static boolean enabled() {
        return true;
    }
    
    protected static void transformSocketToSSLSocket(final MysqlIO mysqlIO) throws CommunicationsException {
        final SSLSocketFactory sslFact = (SSLSocketFactory)SSLSocketFactory.getDefault();
        try {
            mysqlIO.mysqlConnection = sslFact.createSocket(mysqlIO.mysqlConnection, mysqlIO.host, mysqlIO.port, true);
            ((SSLSocket)mysqlIO.mysqlConnection).setEnabledProtocols(new String[] { "TLSv1" });
            ((SSLSocket)mysqlIO.mysqlConnection).startHandshake();
            if (mysqlIO.connection.getUseUnbufferedInput()) {
                mysqlIO.mysqlInput = mysqlIO.mysqlConnection.getInputStream();
            }
            else {
                mysqlIO.mysqlInput = new BufferedInputStream(mysqlIO.mysqlConnection.getInputStream(), 16384);
            }
            (mysqlIO.mysqlOutput = new BufferedOutputStream(mysqlIO.mysqlConnection.getOutputStream(), 16384)).flush();
        }
        catch (IOException ioEx) {
            throw new CommunicationsException(mysqlIO.connection, mysqlIO.lastPacketSentTimeMs, ioEx);
        }
    }
    
    private ExportControlled() {
    }
}
