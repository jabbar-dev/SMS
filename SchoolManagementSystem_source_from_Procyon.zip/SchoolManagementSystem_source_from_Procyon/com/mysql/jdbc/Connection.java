// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.io.Reader;
import java.io.InputStream;
import java.net.URL;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Ref;
import java.sql.ParameterMetaData;
import java.sql.ResultSetMetaData;
import java.sql.Date;
import java.sql.Clob;
import java.sql.Blob;
import java.math.BigDecimal;
import java.lang.reflect.Constructor;
import com.mysql.jdbc.log.NullLogger;
import java.sql.Savepoint;
import com.mysql.jdbc.profiler.ProfilerEvent;
import java.sql.SQLWarning;
import java.io.IOException;
import java.util.Stack;
import java.io.UnsupportedEncodingException;
import java.util.Locale;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.StringTokenizer;
import java.util.ArrayList;
import com.mysql.jdbc.log.LogFactory;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.lang.reflect.Method;
import java.lang.reflect.Array;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Properties;
import com.mysql.jdbc.util.LRUCache;
import java.util.List;
import com.mysql.jdbc.profiler.ProfileEventSink;
import java.util.TimeZone;
import java.util.Timer;
import com.mysql.jdbc.log.Log;
import java.util.Map;

public class Connection extends ConnectionProperties implements java.sql.Connection
{
    private static final String JDBC_LOCAL_CHARACTER_SET_RESULTS = "jdbc.local.character_set_results";
    private static final Object CHARSET_CONVERTER_NOT_AVAILABLE_MARKER;
    public static Map charsetMap;
    protected static final String DEFAULT_LOGGER_CLASS = "com.mysql.jdbc.log.StandardLogger";
    private static final int HISTOGRAM_BUCKETS = 20;
    private static final String LOGGER_INSTANCE_NAME = "MySQL";
    private static Map mapTransIsolationNameToValue;
    private static final Log NULL_LOGGER;
    private static Map roundRobinStatsMap;
    private static final Map serverCollationByUrl;
    private static final Map serverConfigByUrl;
    private static Timer cancelTimer;
    private boolean autoCommit;
    private Map cachedPreparedStatementParams;
    private String characterSetMetadata;
    private String characterSetResultsOnServer;
    private Map charsetConverterMap;
    private Map charsetToNumBytesMap;
    private long connectionCreationTimeMillis;
    private long connectionId;
    private String database;
    private DatabaseMetaData dbmd;
    private TimeZone defaultTimeZone;
    private ProfileEventSink eventSink;
    private boolean executingFailoverReconnect;
    private boolean failedOver;
    private Throwable forceClosedReason;
    private Throwable forcedClosedLocation;
    private boolean hasIsolationLevels;
    private boolean hasQuotedIdentifiers;
    private String host;
    private List hostList;
    private int hostListSize;
    private String[] indexToCharsetMapping;
    private MysqlIO io;
    private boolean isClientTzUTC;
    private boolean isClosed;
    private boolean isInGlobalTx;
    private boolean isRunningOnJDK13;
    private int isolationLevel;
    private boolean isServerTzUTC;
    private long lastQueryFinishedTime;
    private Log log;
    private long longestQueryTimeMs;
    private boolean lowerCaseTableNames;
    private long masterFailTimeMillis;
    private int maxAllowedPacket;
    private long maximumNumberTablesAccessed;
    private boolean maxRowsChanged;
    private long metricsLastReportedMs;
    private long minimumNumberTablesAccessed;
    private final Object mutex;
    private String myURL;
    private boolean needsPing;
    private int netBufferLength;
    private boolean noBackslashEscapes;
    private long numberOfPreparedExecutes;
    private long numberOfPrepares;
    private long numberOfQueriesIssued;
    private long numberOfResultSetsCreated;
    private long[] numTablesMetricsHistBreakpoints;
    private int[] numTablesMetricsHistCounts;
    private long[] oldHistBreakpoints;
    private int[] oldHistCounts;
    private Map openStatements;
    private LRUCache parsedCallableStatementCache;
    private boolean parserKnowsUnicode;
    private String password;
    private long[] perfMetricsHistBreakpoints;
    private int[] perfMetricsHistCounts;
    private Throwable pointOfOrigin;
    private int port;
    private boolean preferSlaveDuringFailover;
    private Properties props;
    private long queriesIssuedFailedOver;
    private boolean readInfoMsg;
    private boolean readOnly;
    protected LRUCache resultSetMetadataCache;
    private TimeZone serverTimezoneTZ;
    private Map serverVariables;
    private long shortestQueryTimeMs;
    private Map statementsUsingMaxRows;
    private double totalQueryTimeMs;
    private boolean transactionsSupported;
    private Map typeMap;
    private boolean useAnsiQuotes;
    private String user;
    private boolean useServerPreparedStmts;
    private LRUCache serverSideStatementCheckCache;
    private LRUCache serverSideStatementCache;
    private Calendar sessionCalendar;
    private Calendar utcCalendar;
    private String origHostToConnectTo;
    private int origPortToConnectTo;
    private String origDatabaseToConnectTo;
    private String errorMessageEncoding;
    private boolean usePlatformCharsetConverters;
    private boolean usingCachedConfig;
    private boolean hasTriedMasterFlag;
    
    protected static SQLException appendMessageToException(final SQLException sqlEx, final String messageToAppend) {
        final String origMessage = sqlEx.getMessage();
        final String sqlState = sqlEx.getSQLState();
        final int vendorErrorCode = sqlEx.getErrorCode();
        final StringBuffer messageBuf = new StringBuffer(origMessage.length() + messageToAppend.length());
        messageBuf.append(origMessage);
        messageBuf.append(messageToAppend);
        final SQLException sqlExceptionWithNewMessage = SQLError.createSQLException(messageBuf.toString(), sqlState, vendorErrorCode);
        try {
            Method getStackTraceMethod = null;
            Method setStackTraceMethod = null;
            Object theStackTraceAsObject = null;
            final Class stackTraceElementClass = Class.forName("java.lang.StackTraceElement");
            final Class stackTraceElementArrayClass = Array.newInstance(stackTraceElementClass, new int[] { 0 }).getClass();
            getStackTraceMethod = Throwable.class.getMethod("getStackTrace", (Class[])new Class[0]);
            setStackTraceMethod = Throwable.class.getMethod("setStackTrace", stackTraceElementArrayClass);
            if (getStackTraceMethod != null && setStackTraceMethod != null) {
                theStackTraceAsObject = getStackTraceMethod.invoke(sqlEx, new Object[0]);
                setStackTraceMethod.invoke(sqlExceptionWithNewMessage, theStackTraceAsObject);
            }
        }
        catch (NoClassDefFoundError noClassDefFound) {}
        catch (NoSuchMethodException noSuchMethodEx) {}
        catch (Throwable t) {}
        return sqlExceptionWithNewMessage;
    }
    
    protected static Timer getCancelTimer() {
        return Connection.cancelTimer;
    }
    
    private static synchronized int getNextRoundRobinHostIndex(final String url, final List hostList) {
        if (Connection.roundRobinStatsMap == null) {
            Connection.roundRobinStatsMap = new HashMap();
        }
        int[] index = Connection.roundRobinStatsMap.get(url);
        if (index == null) {
            index = new int[] { -1 };
            Connection.roundRobinStatsMap.put(url, index);
        }
        final int[] array = index;
        final int n = 0;
        ++array[n];
        if (index[0] >= hostList.size()) {
            index[0] = 0;
        }
        return index[0];
    }
    
    private static boolean nullSafeCompare(final String s1, final String s2) {
        return (s1 == null && s2 == null) || ((s1 != null || s2 == null) && s1.equals(s2));
    }
    
    Connection(final String hostToConnectTo, final int portToConnectTo, final Properties info, String databaseToConnectTo, final String url) throws SQLException {
        this.autoCommit = true;
        this.characterSetMetadata = null;
        this.characterSetResultsOnServer = null;
        this.charsetConverterMap = new HashMap(CharsetMapping.getNumberOfCharsetsConfigured());
        this.connectionCreationTimeMillis = 0L;
        this.database = null;
        this.dbmd = null;
        this.executingFailoverReconnect = false;
        this.failedOver = false;
        this.hasIsolationLevels = false;
        this.hasQuotedIdentifiers = false;
        this.host = null;
        this.hostList = null;
        this.hostListSize = 0;
        this.indexToCharsetMapping = CharsetMapping.INDEX_TO_CHARSET;
        this.io = null;
        this.isClientTzUTC = false;
        this.isClosed = true;
        this.isInGlobalTx = false;
        this.isRunningOnJDK13 = false;
        this.isolationLevel = 2;
        this.isServerTzUTC = false;
        this.lastQueryFinishedTime = 0L;
        this.log = Connection.NULL_LOGGER;
        this.longestQueryTimeMs = 0L;
        this.lowerCaseTableNames = false;
        this.masterFailTimeMillis = 0L;
        this.maxAllowedPacket = 65536;
        this.maximumNumberTablesAccessed = 0L;
        this.maxRowsChanged = false;
        this.minimumNumberTablesAccessed = Long.MAX_VALUE;
        this.mutex = new Object();
        this.myURL = null;
        this.needsPing = false;
        this.netBufferLength = 16384;
        this.noBackslashEscapes = false;
        this.numberOfPreparedExecutes = 0L;
        this.numberOfPrepares = 0L;
        this.numberOfQueriesIssued = 0L;
        this.numberOfResultSetsCreated = 0L;
        this.oldHistBreakpoints = null;
        this.oldHistCounts = null;
        this.parserKnowsUnicode = false;
        this.password = null;
        this.port = 3306;
        this.preferSlaveDuringFailover = false;
        this.props = null;
        this.queriesIssuedFailedOver = 0L;
        this.readInfoMsg = false;
        this.readOnly = false;
        this.serverTimezoneTZ = null;
        this.serverVariables = null;
        this.shortestQueryTimeMs = Long.MAX_VALUE;
        this.totalQueryTimeMs = 0.0;
        this.transactionsSupported = false;
        this.useAnsiQuotes = false;
        this.user = null;
        this.useServerPreparedStmts = false;
        this.errorMessageEncoding = "Cp1252";
        this.usingCachedConfig = false;
        this.hasTriedMasterFlag = false;
        this.charsetToNumBytesMap = new HashMap();
        this.connectionCreationTimeMillis = System.currentTimeMillis();
        this.pointOfOrigin = new Throwable();
        this.origHostToConnectTo = hostToConnectTo;
        this.origPortToConnectTo = portToConnectTo;
        this.origDatabaseToConnectTo = databaseToConnectTo;
        try {
            Blob.class.getMethod("truncate", Long.TYPE);
            this.isRunningOnJDK13 = false;
        }
        catch (NoSuchMethodException nsme) {
            this.isRunningOnJDK13 = true;
        }
        this.sessionCalendar = new GregorianCalendar();
        (this.utcCalendar = new GregorianCalendar()).setTimeZone(TimeZone.getTimeZone("GMT"));
        this.log = LogFactory.getLogger(this.getLogger(), "MySQL");
        this.defaultTimeZone = Util.getDefaultTimeZone();
        if ("GMT".equalsIgnoreCase(this.defaultTimeZone.getID())) {
            this.isClientTzUTC = true;
        }
        else {
            this.isClientTzUTC = false;
        }
        this.openStatements = new HashMap();
        this.serverVariables = new HashMap();
        this.hostList = new ArrayList();
        if (hostToConnectTo == null) {
            this.host = "localhost";
            this.hostList.add(this.host);
        }
        else if (hostToConnectTo.indexOf(",") != -1) {
            final StringTokenizer hostTokenizer = new StringTokenizer(hostToConnectTo, ",", false);
            while (hostTokenizer.hasMoreTokens()) {
                this.hostList.add(hostTokenizer.nextToken().trim());
            }
        }
        else {
            this.host = hostToConnectTo;
            this.hostList.add(this.host);
        }
        this.hostListSize = this.hostList.size();
        this.port = portToConnectTo;
        if (databaseToConnectTo == null) {
            databaseToConnectTo = "";
        }
        this.database = databaseToConnectTo;
        this.myURL = url;
        this.user = info.getProperty("user");
        this.password = info.getProperty("password");
        if (this.user == null || this.user.equals("")) {
            this.user = "";
        }
        if (this.password == null) {
            this.password = "";
        }
        this.initializeDriverProperties(this.props = info);
        try {
            this.createNewIO(false);
            this.dbmd = new DatabaseMetaData(this, this.database);
        }
        catch (SQLException ex) {
            this.cleanup(ex);
            throw ex;
        }
        catch (Exception ex2) {
            this.cleanup(ex2);
            final StringBuffer mesg = new StringBuffer();
            if (this.getParanoid()) {
                mesg.append("Cannot connect to MySQL server on ");
                mesg.append(this.host);
                mesg.append(":");
                mesg.append(this.port);
                mesg.append(".\n\n");
                mesg.append("Make sure that there is a MySQL server ");
                mesg.append("running on the machine/port you are trying ");
                mesg.append("to connect to and that the machine this software is running on ");
                mesg.append("is able to connect to this host/port (i.e. not firewalled). ");
                mesg.append("Also make sure that the server has not been started with the --skip-networking ");
                mesg.append("flag.\n\n");
            }
            else {
                mesg.append("Unable to connect to database.");
            }
            mesg.append("Underlying exception: \n\n");
            mesg.append(ex2.getClass().getName());
            if (!this.getParanoid()) {
                mesg.append(Util.stackTraceToString(ex2));
            }
            throw SQLError.createSQLException(mesg.toString(), "08S01");
        }
    }
    
    private void addToHistogram(final int[] histogramCounts, final long[] histogramBreakpoints, final long value, final int numberOfTimes, final long currentLowerBound, final long currentUpperBound) {
        if (histogramCounts == null) {
            this.createInitialHistogram(histogramBreakpoints, currentLowerBound, currentUpperBound);
        }
        for (int i = 0; i < 20; ++i) {
            if (histogramBreakpoints[i] >= value) {
                final int n = i;
                histogramCounts[n] += numberOfTimes;
                break;
            }
        }
    }
    
    private void addToPerformanceHistogram(final long value, final int numberOfTimes) {
        this.checkAndCreatePerformanceHistogram();
        this.addToHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, value, numberOfTimes, (this.shortestQueryTimeMs == Long.MAX_VALUE) ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
    }
    
    private void addToTablesAccessedHistogram(final long value, final int numberOfTimes) {
        this.checkAndCreateTablesAccessedHistogram();
        this.addToHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, value, numberOfTimes, (this.minimumNumberTablesAccessed == Long.MAX_VALUE) ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
    }
    
    private void buildCollationMapping() throws SQLException {
        if (this.versionMeetsMinimum(4, 1, 0)) {
            TreeMap sortedCollationMap = null;
            if (this.getCacheServerConfiguration()) {
                synchronized (Connection.serverConfigByUrl) {
                    sortedCollationMap = Connection.serverCollationByUrl.get(this.getURL());
                }
            }
            Statement stmt = null;
            ResultSet results = null;
            try {
                if (sortedCollationMap == null) {
                    sortedCollationMap = new TreeMap();
                    stmt = (Statement)this.createStatement();
                    if (stmt.getMaxRows() != 0) {
                        stmt.setMaxRows(0);
                    }
                    results = (ResultSet)stmt.executeQuery("SHOW COLLATION");
                    while (results.next()) {
                        final String charsetName = results.getString(2);
                        final Integer charsetIndex = new Integer(results.getInt(3));
                        sortedCollationMap.put(charsetIndex, charsetName);
                    }
                    if (this.getCacheServerConfiguration()) {
                        synchronized (Connection.serverConfigByUrl) {
                            Connection.serverCollationByUrl.put(this.getURL(), sortedCollationMap);
                        }
                    }
                }
                int highestIndex = sortedCollationMap.lastKey();
                if (CharsetMapping.INDEX_TO_CHARSET.length > highestIndex) {
                    highestIndex = CharsetMapping.INDEX_TO_CHARSET.length;
                }
                this.indexToCharsetMapping = new String[highestIndex + 1];
                for (int i = 0; i < CharsetMapping.INDEX_TO_CHARSET.length; ++i) {
                    this.indexToCharsetMapping[i] = CharsetMapping.INDEX_TO_CHARSET[i];
                }
                for (final Map.Entry indexEntry : sortedCollationMap.entrySet()) {
                    final String mysqlCharsetName = indexEntry.getValue();
                    this.indexToCharsetMapping[indexEntry.getKey()] = CharsetMapping.getJavaEncodingForMysqlEncoding(mysqlCharsetName, this);
                }
            }
            catch (SQLException e) {
                throw e;
            }
            finally {
                if (results != null) {
                    try {
                        results.close();
                    }
                    catch (SQLException ex) {}
                }
                if (stmt != null) {
                    try {
                        stmt.close();
                    }
                    catch (SQLException ex2) {}
                }
            }
        }
        else {
            this.indexToCharsetMapping = CharsetMapping.INDEX_TO_CHARSET;
        }
    }
    
    private boolean canHandleAsServerPreparedStatement(final String sql) throws SQLException {
        if (sql == null || sql.length() == 0) {
            return true;
        }
        if (this.getCachePreparedStatements()) {
            synchronized (this.serverSideStatementCheckCache) {
                final Boolean flag = this.serverSideStatementCheckCache.get(sql);
                if (flag != null) {
                    return flag;
                }
                final boolean canHandle = this.canHandleAsServerPreparedStatementNoCache(sql);
                if (sql.length() < this.getPreparedStatementCacheSqlLimit()) {
                    this.serverSideStatementCheckCache.put(sql, canHandle ? Boolean.TRUE : Boolean.FALSE);
                }
                return canHandle;
            }
        }
        return this.canHandleAsServerPreparedStatementNoCache(sql);
    }
    
    private boolean canHandleAsServerPreparedStatementNoCache(final String sql) throws SQLException {
        if (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "CALL")) {
            return false;
        }
        boolean canHandleAsStatement = true;
        if (!this.versionMeetsMinimum(5, 0, 7) && (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "SELECT") || StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "DELETE") || StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "INSERT") || StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "UPDATE") || StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "REPLACE"))) {
            int currentPos = 0;
            final int statementLength = sql.length();
            final int lastPosToLook = statementLength - 7;
            final boolean allowBackslashEscapes = !this.noBackslashEscapes;
            final char quoteChar = this.useAnsiQuotes ? '\"' : '\'';
            boolean foundLimitWithPlaceholder = false;
            while (currentPos < lastPosToLook) {
                final int limitStart = StringUtils.indexOfIgnoreCaseRespectQuotes(currentPos, sql, "LIMIT ", quoteChar, allowBackslashEscapes);
                if (limitStart == -1) {
                    break;
                }
                for (currentPos = limitStart + 7; currentPos < statementLength; ++currentPos) {
                    final char c = sql.charAt(currentPos);
                    if (!Character.isDigit(c) && !Character.isWhitespace(c) && c != ',' && c != '?') {
                        break;
                    }
                    if (c == '?') {
                        foundLimitWithPlaceholder = true;
                        break;
                    }
                }
            }
            canHandleAsStatement = !foundLimitWithPlaceholder;
        }
        else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "CREATE TABLE")) {
            canHandleAsStatement = false;
        }
        else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "DO")) {
            canHandleAsStatement = false;
        }
        else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "SET")) {
            canHandleAsStatement = false;
        }
        return canHandleAsStatement;
    }
    
    public void changeUser(String userName, String newPassword) throws SQLException {
        if (userName == null || userName.equals("")) {
            userName = "";
        }
        if (newPassword == null) {
            newPassword = "";
        }
        this.io.changeUser(userName, newPassword, this.database);
        this.user = userName;
        this.password = newPassword;
        if (this.versionMeetsMinimum(4, 1, 0)) {
            this.configureClientCharacterSet();
        }
        this.setupServerForTruncationChecks();
    }
    
    private void checkAndCreatePerformanceHistogram() {
        if (this.perfMetricsHistCounts == null) {
            this.perfMetricsHistCounts = new int[20];
        }
        if (this.perfMetricsHistBreakpoints == null) {
            this.perfMetricsHistBreakpoints = new long[20];
        }
    }
    
    private void checkAndCreateTablesAccessedHistogram() {
        if (this.numTablesMetricsHistCounts == null) {
            this.numTablesMetricsHistCounts = new int[20];
        }
        if (this.numTablesMetricsHistBreakpoints == null) {
            this.numTablesMetricsHistBreakpoints = new long[20];
        }
    }
    
    private void checkClosed() throws SQLException {
        if (this.isClosed) {
            final StringBuffer messageBuf = new StringBuffer("No operations allowed after connection closed.");
            if (this.forcedClosedLocation != null || this.forceClosedReason != null) {
                messageBuf.append("Connection was implicitly closed ");
            }
            if (this.forcedClosedLocation != null) {
                messageBuf.append("\n\n");
                messageBuf.append(" at (stack trace):\n");
                messageBuf.append(Util.stackTraceToString(this.forcedClosedLocation));
            }
            if (this.forceClosedReason != null) {
                if (this.forcedClosedLocation != null) {
                    messageBuf.append("\n\nDue ");
                }
                else {
                    messageBuf.append("due ");
                }
                messageBuf.append("to underlying exception/error:\n");
                messageBuf.append(Util.stackTraceToString(this.forceClosedReason));
            }
            throw SQLError.createSQLException(messageBuf.toString(), "08003");
        }
    }
    
    private void checkServerEncoding() throws SQLException {
        if (this.getUseUnicode() && this.getEncoding() != null) {
            return;
        }
        String serverEncoding = this.serverVariables.get("character_set");
        if (serverEncoding == null) {
            serverEncoding = this.serverVariables.get("character_set_server");
        }
        String mappedServerEncoding = null;
        if (serverEncoding != null) {
            mappedServerEncoding = CharsetMapping.getJavaEncodingForMysqlEncoding(serverEncoding.toUpperCase(Locale.ENGLISH), this);
        }
        if (!this.getUseUnicode() && mappedServerEncoding != null) {
            final SingleByteCharsetConverter converter = this.getCharsetConverter(mappedServerEncoding);
            if (converter != null) {
                this.setUseUnicode(true);
                this.setEncoding(mappedServerEncoding);
                return;
            }
        }
        if (serverEncoding != null) {
            if (mappedServerEncoding == null && Character.isLowerCase(serverEncoding.charAt(0))) {
                final char[] ach = serverEncoding.toCharArray();
                ach[0] = Character.toUpperCase(serverEncoding.charAt(0));
                this.setEncoding(new String(ach));
            }
            if (mappedServerEncoding == null) {
                throw SQLError.createSQLException("Unknown character encoding on server '" + serverEncoding + "', use 'characterEncoding=' property " + " to provide correct mapping", "01S00");
            }
            try {
                "abc".getBytes(mappedServerEncoding);
                this.setEncoding(mappedServerEncoding);
                this.setUseUnicode(true);
            }
            catch (UnsupportedEncodingException UE) {
                throw SQLError.createSQLException("The driver can not map the character encoding '" + this.getEncoding() + "' that your server is using " + "to a character encoding your JVM understands. You " + "can specify this mapping manually by adding \"useUnicode=true\" " + "as well as \"characterEncoding=[an_encoding_your_jvm_understands]\" " + "to your JDBC URL.", "0S100");
            }
        }
    }
    
    private void checkTransactionIsolationLevel() throws SQLException {
        String txIsolationName = null;
        if (this.versionMeetsMinimum(4, 0, 3)) {
            txIsolationName = "tx_isolation";
        }
        else {
            txIsolationName = "transaction_isolation";
        }
        final String s = this.serverVariables.get(txIsolationName);
        if (s != null) {
            final Integer intTI = Connection.mapTransIsolationNameToValue.get(s);
            if (intTI != null) {
                this.isolationLevel = intTI;
            }
        }
    }
    
    private void cleanup(final Throwable whyCleanedUp) {
        try {
            if (this.io != null && !this.isClosed()) {
                this.realClose(false, false, false, whyCleanedUp);
            }
            else if (this.io != null) {
                this.io.forceClose();
            }
        }
        catch (SQLException ex) {}
        this.isClosed = true;
    }
    
    public void clearWarnings() throws SQLException {
    }
    
    public PreparedStatement clientPrepareStatement(final String sql) throws SQLException {
        return this.clientPrepareStatement(sql, 1005, 1007);
    }
    
    public java.sql.PreparedStatement clientPrepareStatement(final String sql, final int autoGenKeyIndex) throws SQLException {
        final java.sql.PreparedStatement pStmt = this.clientPrepareStatement(sql);
        ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
        return pStmt;
    }
    
    public PreparedStatement clientPrepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        return this.clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true);
    }
    
    protected PreparedStatement clientPrepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency, final boolean processEscapeCodesIfNeeded) throws SQLException {
        this.checkClosed();
        final String nativeSql = (processEscapeCodesIfNeeded && this.getProcessEscapeCodesForPrepStmts()) ? this.nativeSQL(sql) : sql;
        PreparedStatement pStmt = null;
        Label_0297: {
            if (this.getCachePreparedStatements()) {
                synchronized (this.cachedPreparedStatementParams) {
                    final PreparedStatement.ParseInfo pStmtInfo = this.cachedPreparedStatementParams.get(nativeSql);
                    if (pStmtInfo == null) {
                        pStmt = new PreparedStatement(this, nativeSql, this.database);
                        final PreparedStatement.ParseInfo parseInfo = pStmt.getParseInfo();
                        if (parseInfo.statementLength < this.getPreparedStatementCacheSqlLimit()) {
                            if (this.cachedPreparedStatementParams.size() >= this.getPreparedStatementCacheSize()) {
                                final Iterator oldestIter = this.cachedPreparedStatementParams.keySet().iterator();
                                long lruTime = Long.MAX_VALUE;
                                String oldestSql = null;
                                while (oldestIter.hasNext()) {
                                    final String sqlKey = oldestIter.next();
                                    final PreparedStatement.ParseInfo lruInfo = this.cachedPreparedStatementParams.get(sqlKey);
                                    if (lruInfo.lastUsed < lruTime) {
                                        lruTime = lruInfo.lastUsed;
                                        oldestSql = sqlKey;
                                    }
                                }
                                if (oldestSql != null) {
                                    this.cachedPreparedStatementParams.remove(oldestSql);
                                }
                            }
                            this.cachedPreparedStatementParams.put(nativeSql, pStmt.getParseInfo());
                        }
                    }
                    else {
                        pStmtInfo.lastUsed = System.currentTimeMillis();
                        pStmt = new PreparedStatement(this, nativeSql, this.database, pStmtInfo);
                    }
                    break Label_0297;
                }
            }
            pStmt = new PreparedStatement(this, nativeSql, this.database);
        }
        pStmt.setResultSetType(resultSetType);
        pStmt.setResultSetConcurrency(resultSetConcurrency);
        return pStmt;
    }
    
    public void close() throws SQLException {
        this.realClose(true, true, false, null);
    }
    
    private void closeAllOpenStatements() throws SQLException {
        SQLException postponedException = null;
        if (this.openStatements != null) {
            final List currentlyOpenStatements = new ArrayList();
            final Iterator iter = this.openStatements.keySet().iterator();
            while (iter.hasNext()) {
                currentlyOpenStatements.add(iter.next());
            }
            for (int numStmts = currentlyOpenStatements.size(), i = 0; i < numStmts; ++i) {
                final Statement stmt = currentlyOpenStatements.get(i);
                try {
                    stmt.realClose(false, true);
                }
                catch (SQLException sqlEx) {
                    postponedException = sqlEx;
                }
            }
            if (postponedException != null) {
                throw postponedException;
            }
        }
    }
    
    private void closeStatement(java.sql.Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            }
            catch (SQLException ex) {}
            stmt = null;
        }
    }
    
    public void commit() throws SQLException {
        synchronized (this.getMutex()) {
            this.checkClosed();
            try {
                if (this.autoCommit && !this.getRelaxAutoCommit()) {
                    throw SQLError.createSQLException("Can't call commit when autocommit=true");
                }
                if (this.transactionsSupported) {
                    if (this.getUseLocalSessionState() && this.versionMeetsMinimum(5, 0, 0) && !this.io.inTransactionOnServer()) {
                        return;
                    }
                    this.execSQL(null, "commit", -1, null, 1003, 1007, false, this.database, true, false);
                }
            }
            catch (SQLException sqlException) {
                if ("08S01".equals(sqlException.getSQLState())) {
                    throw SQLError.createSQLException("Communications link failure during commit(). Transaction resolution unknown.", "08007");
                }
                throw sqlException;
            }
            finally {
                this.needsPing = this.getReconnectAtTxEnd();
            }
        }
    }
    
    private void configureCharsetProperties() throws SQLException {
        if (this.getEncoding() != null) {
            try {
                final String testString = "abc";
                testString.getBytes(this.getEncoding());
            }
            catch (UnsupportedEncodingException UE) {
                final String oldEncoding = this.getEncoding();
                this.setEncoding(CharsetMapping.getJavaEncodingForMysqlEncoding(oldEncoding, this));
                if (this.getEncoding() == null) {
                    throw SQLError.createSQLException("Java does not support the MySQL character encoding  encoding '" + oldEncoding + "'.", "01S00");
                }
                try {
                    final String testString2 = "abc";
                    testString2.getBytes(this.getEncoding());
                }
                catch (UnsupportedEncodingException encodingEx) {
                    throw SQLError.createSQLException("Unsupported character encoding '" + this.getEncoding() + "'.", "01S00");
                }
            }
        }
    }
    
    private boolean configureClientCharacterSet() throws SQLException {
        String realJavaEncoding = this.getEncoding();
        boolean characterSetAlreadyConfigured = false;
        try {
            if (this.versionMeetsMinimum(4, 1, 0)) {
                characterSetAlreadyConfigured = true;
                this.setUseUnicode(true);
                this.configureCharsetProperties();
                realJavaEncoding = this.getEncoding();
                try {
                    if (this.props != null && this.props.getProperty("com.mysql.jdbc.faultInjection.serverCharsetIndex") != null) {
                        this.io.serverCharsetIndex = Integer.parseInt(this.props.getProperty("com.mysql.jdbc.faultInjection.serverCharsetIndex"));
                    }
                    String serverEncodingToSet = CharsetMapping.INDEX_TO_CHARSET[this.io.serverCharsetIndex];
                    if (serverEncodingToSet == null || serverEncodingToSet.length() == 0) {
                        if (realJavaEncoding == null) {
                            throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000");
                        }
                        this.setEncoding(realJavaEncoding);
                    }
                    if (this.versionMeetsMinimum(4, 1, 0) && "ISO8859_1".equalsIgnoreCase(serverEncodingToSet)) {
                        serverEncodingToSet = "Cp1252";
                    }
                    this.setEncoding(serverEncodingToSet);
                }
                catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
                    if (realJavaEncoding == null) {
                        throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000");
                    }
                    this.setEncoding(realJavaEncoding);
                }
                if (this.getEncoding() == null) {
                    this.setEncoding("ISO8859_1");
                }
                if (this.getUseUnicode()) {
                    if (realJavaEncoding != null) {
                        if (realJavaEncoding.equalsIgnoreCase("UTF-8") || realJavaEncoding.equalsIgnoreCase("UTF8")) {
                            if (!this.getUseOldUTF8Behavior() && !this.characterSetNamesMatches("utf8")) {
                                this.execSQL(null, "SET NAMES utf8", -1, null, 1003, 1007, false, this.database, true, false);
                            }
                            this.setEncoding(realJavaEncoding);
                        }
                        else {
                            final String mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(realJavaEncoding.toUpperCase(Locale.ENGLISH), this);
                            if (mysqlEncodingName != null && !this.characterSetNamesMatches(mysqlEncodingName)) {
                                this.execSQL(null, "SET NAMES " + mysqlEncodingName, -1, null, 1003, 1007, false, this.database, true, false);
                            }
                            this.setEncoding(realJavaEncoding);
                        }
                    }
                    else if (this.getEncoding() != null) {
                        final String mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(this.getEncoding().toUpperCase(Locale.ENGLISH), this);
                        if (!this.characterSetNamesMatches(mysqlEncodingName)) {
                            this.execSQL(null, "SET NAMES " + mysqlEncodingName, -1, null, 1003, 1007, false, this.database, true, false);
                        }
                        realJavaEncoding = this.getEncoding();
                    }
                }
                String onServer = null;
                boolean isNullOnServer = false;
                if (this.serverVariables != null) {
                    onServer = this.serverVariables.get("character_set_results");
                    isNullOnServer = (onServer == null || "NULL".equalsIgnoreCase(onServer) || onServer.length() == 0);
                }
                if (this.getCharacterSetResults() == null) {
                    if (!isNullOnServer) {
                        this.execSQL(null, "SET character_set_results = NULL", -1, null, 1003, 1007, false, this.database, true, false);
                        if (!this.usingCachedConfig) {
                            this.serverVariables.put("jdbc.local.character_set_results", null);
                        }
                    }
                    else if (!this.usingCachedConfig) {
                        this.serverVariables.put("jdbc.local.character_set_results", onServer);
                    }
                }
                else {
                    final String charsetResults = this.getCharacterSetResults();
                    String mysqlEncodingName2 = null;
                    if ("UTF-8".equalsIgnoreCase(charsetResults) || "UTF8".equalsIgnoreCase(charsetResults)) {
                        mysqlEncodingName2 = "utf8";
                    }
                    else {
                        mysqlEncodingName2 = CharsetMapping.getMysqlEncodingForJavaEncoding(charsetResults.toUpperCase(Locale.ENGLISH), this);
                    }
                    if (!mysqlEncodingName2.equalsIgnoreCase(this.serverVariables.get("character_set_results"))) {
                        final StringBuffer setBuf = new StringBuffer("SET character_set_results = ".length() + mysqlEncodingName2.length());
                        setBuf.append("SET character_set_results = ").append(mysqlEncodingName2);
                        this.execSQL(null, setBuf.toString(), -1, null, 1003, 1007, false, this.database, true, false);
                        if (!this.usingCachedConfig) {
                            this.serverVariables.put("jdbc.local.character_set_results", mysqlEncodingName2);
                        }
                    }
                    else if (!this.usingCachedConfig) {
                        this.serverVariables.put("jdbc.local.character_set_results", onServer);
                    }
                }
                if (this.getConnectionCollation() != null) {
                    final StringBuffer setBuf2 = new StringBuffer("SET collation_connection = ".length() + this.getConnectionCollation().length());
                    setBuf2.append("SET collation_connection = ").append(this.getConnectionCollation());
                    this.execSQL(null, setBuf2.toString(), -1, null, 1003, 1007, false, this.database, true, false);
                }
            }
            else {
                realJavaEncoding = this.getEncoding();
            }
        }
        finally {
            this.setEncoding(realJavaEncoding);
        }
        return characterSetAlreadyConfigured;
    }
    
    private boolean characterSetNamesMatches(final String mysqlEncodingName) {
        return mysqlEncodingName != null && mysqlEncodingName.equalsIgnoreCase(this.serverVariables.get("character_set_client")) && mysqlEncodingName.equalsIgnoreCase(this.serverVariables.get("character_set_connection"));
    }
    
    private void configureTimezone() throws SQLException {
        String configuredTimeZoneOnServer = this.serverVariables.get("timezone");
        if (configuredTimeZoneOnServer == null) {
            configuredTimeZoneOnServer = this.serverVariables.get("time_zone");
            if ("SYSTEM".equalsIgnoreCase(configuredTimeZoneOnServer)) {
                configuredTimeZoneOnServer = this.serverVariables.get("system_time_zone");
            }
        }
        if (this.getUseTimezone() && configuredTimeZoneOnServer != null) {
            String canoncicalTimezone = this.getServerTimezone();
            if (canoncicalTimezone == null || canoncicalTimezone.length() == 0) {
                final String serverTimezoneStr = configuredTimeZoneOnServer;
                try {
                    canoncicalTimezone = TimeUtil.getCanoncialTimezone(serverTimezoneStr);
                    if (canoncicalTimezone == null) {
                        throw SQLError.createSQLException("Can't map timezone '" + serverTimezoneStr + "' to " + " canonical timezone.", "S1009");
                    }
                }
                catch (IllegalArgumentException iae) {
                    throw SQLError.createSQLException(iae.getMessage(), "S1000");
                }
            }
            this.serverTimezoneTZ = TimeZone.getTimeZone(canoncicalTimezone);
            if (!canoncicalTimezone.equalsIgnoreCase("GMT") && this.serverTimezoneTZ.getID().equals("GMT")) {
                throw SQLError.createSQLException("No timezone mapping entry for '" + canoncicalTimezone + "'", "S1009");
            }
            if ("GMT".equalsIgnoreCase(this.serverTimezoneTZ.getID())) {
                this.isServerTzUTC = true;
            }
            else {
                this.isServerTzUTC = false;
            }
        }
    }
    
    private void createInitialHistogram(final long[] breakpoints, long lowerBound, final long upperBound) {
        double bucketSize = (upperBound - (double)lowerBound) / 20.0 * 1.25;
        if (bucketSize < 1.0) {
            bucketSize = 1.0;
        }
        for (int i = 0; i < 20; ++i) {
            breakpoints[i] = lowerBound;
            lowerBound += (long)bucketSize;
        }
    }
    
    protected MysqlIO createNewIO(final boolean isForReconnect) throws SQLException {
        final MysqlIO newIo = null;
        Properties mergedProps = new Properties();
        mergedProps = this.exposeAsProperties(this.props);
        long queriesIssuedFailedOverCopy = this.queriesIssuedFailedOver;
        this.queriesIssuedFailedOver = 0L;
        try {
            if (!this.getHighAvailability() && !this.failedOver) {
                boolean connectionGood = false;
                Exception connectionNotEstablishedBecause = null;
                int hostIndex = 0;
                if (this.getRoundRobinLoadBalance()) {
                    hostIndex = getNextRoundRobinHostIndex(this.getURL(), this.hostList);
                }
                while (hostIndex < this.hostListSize) {
                    if (hostIndex == 0) {
                        this.hasTriedMasterFlag = true;
                    }
                    try {
                        final String newHostPortPair = this.hostList.get(hostIndex);
                        int newPort = 3306;
                        final String[] hostPortPair = NonRegisteringDriver.parseHostPortPair(newHostPortPair);
                        String newHost = hostPortPair[0];
                        if (newHost == null || newHost.trim().length() == 0) {
                            newHost = "localhost";
                        }
                        if (hostPortPair[1] != null) {
                            try {
                                newPort = Integer.parseInt(hostPortPair[1]);
                            }
                            catch (NumberFormatException nfe) {
                                throw SQLError.createSQLException("Illegal connection port value '" + hostPortPair[1] + "'", "01S00");
                            }
                        }
                        (this.io = new MysqlIO(newHost, newPort, mergedProps, this.getSocketFactoryClassName(), this, this.getSocketTimeout())).doHandshake(this.user, this.password, this.database);
                        this.connectionId = this.io.getThreadId();
                        this.isClosed = false;
                        final boolean oldAutoCommit = this.getAutoCommit();
                        final int oldIsolationLevel = this.isolationLevel;
                        final boolean oldReadOnly = this.isReadOnly();
                        final String oldCatalog = this.getCatalog();
                        this.initializePropsFromServer();
                        if (isForReconnect) {
                            this.setAutoCommit(oldAutoCommit);
                            if (this.hasIsolationLevels) {
                                this.setTransactionIsolation(oldIsolationLevel);
                            }
                            this.setCatalog(oldCatalog);
                        }
                        if (hostIndex != 0) {
                            this.setFailedOverState();
                            queriesIssuedFailedOverCopy = 0L;
                        }
                        else {
                            this.failedOver = false;
                            queriesIssuedFailedOverCopy = 0L;
                            if (this.hostListSize > 1) {
                                this.setReadOnlyInternal(false);
                            }
                            else {
                                this.setReadOnlyInternal(oldReadOnly);
                            }
                        }
                        connectionGood = true;
                    }
                    catch (Exception EEE) {
                        if (this.io != null) {
                            this.io.forceClose();
                        }
                        connectionNotEstablishedBecause = EEE;
                        connectionGood = false;
                        if (EEE instanceof SQLException) {
                            final SQLException sqlEx = (SQLException)EEE;
                            final String sqlState = sqlEx.getSQLState();
                            if (sqlState == null || !sqlState.equals("08S01")) {
                                throw sqlEx;
                            }
                        }
                        if (this.getRoundRobinLoadBalance()) {
                            hostIndex = getNextRoundRobinHostIndex(this.getURL(), this.hostList) - 1;
                        }
                        else if (this.hostListSize - 1 == hostIndex) {
                            throw new CommunicationsException(this, (this.io != null) ? this.io.getLastPacketSentTimeMs() : 0L, EEE);
                        }
                        ++hostIndex;
                        continue;
                    }
                    break;
                }
                if (!connectionGood) {
                    throw SQLError.createSQLException("Could not create connection to database server due to underlying exception: '" + connectionNotEstablishedBecause + "'." + (this.getParanoid() ? "" : Util.stackTraceToString(connectionNotEstablishedBecause)), "08001");
                }
            }
            else {
                final double timeout = this.getInitialTimeout();
                boolean connectionGood2 = false;
                Exception connectionException = null;
                int hostIndex2 = 0;
                if (this.getRoundRobinLoadBalance()) {
                    hostIndex2 = getNextRoundRobinHostIndex(this.getURL(), this.hostList);
                }
                while (hostIndex2 < this.hostListSize && !connectionGood2) {
                    if (hostIndex2 == 0) {
                        this.hasTriedMasterFlag = true;
                    }
                    if (this.preferSlaveDuringFailover && hostIndex2 == 0) {
                        ++hostIndex2;
                    }
                    int attemptCount = 0;
                    while (attemptCount < this.getMaxReconnects() && !connectionGood2) {
                        try {
                            if (this.io != null) {
                                this.io.forceClose();
                            }
                            final String newHostPortPair2 = this.hostList.get(hostIndex2);
                            int newPort2 = 3306;
                            final String[] hostPortPair2 = NonRegisteringDriver.parseHostPortPair(newHostPortPair2);
                            String newHost2 = hostPortPair2[0];
                            if (newHost2 == null || newHost2.trim().length() == 0) {
                                newHost2 = "localhost";
                            }
                            if (hostPortPair2[1] != null) {
                                try {
                                    newPort2 = Integer.parseInt(hostPortPair2[1]);
                                }
                                catch (NumberFormatException nfe2) {
                                    throw SQLError.createSQLException("Illegal connection port value '" + hostPortPair2[1] + "'", "01S00");
                                }
                            }
                            (this.io = new MysqlIO(newHost2, newPort2, mergedProps, this.getSocketFactoryClassName(), this, this.getSocketTimeout())).doHandshake(this.user, this.password, this.database);
                            this.pingInternal(false);
                            this.connectionId = this.io.getThreadId();
                            this.isClosed = false;
                            final boolean oldAutoCommit2 = this.getAutoCommit();
                            final int oldIsolationLevel2 = this.isolationLevel;
                            final boolean oldReadOnly2 = this.isReadOnly();
                            final String oldCatalog2 = this.getCatalog();
                            this.initializePropsFromServer();
                            if (isForReconnect) {
                                this.setAutoCommit(oldAutoCommit2);
                                if (this.hasIsolationLevels) {
                                    this.setTransactionIsolation(oldIsolationLevel2);
                                }
                                this.setCatalog(oldCatalog2);
                            }
                            connectionGood2 = true;
                            if (hostIndex2 != 0) {
                                this.setFailedOverState();
                                queriesIssuedFailedOverCopy = 0L;
                            }
                            else {
                                this.failedOver = false;
                                queriesIssuedFailedOverCopy = 0L;
                                if (this.hostListSize > 1) {
                                    this.setReadOnlyInternal(false);
                                }
                                else {
                                    this.setReadOnlyInternal(oldReadOnly2);
                                }
                            }
                        }
                        catch (Exception EEE2) {
                            connectionException = EEE2;
                            connectionGood2 = false;
                            if (this.getRoundRobinLoadBalance()) {
                                hostIndex2 = getNextRoundRobinHostIndex(this.getURL(), this.hostList) - 1;
                            }
                            if (!connectionGood2) {
                                if (attemptCount > 0) {
                                    try {
                                        Thread.sleep((long)timeout * 1000L);
                                    }
                                    catch (InterruptedException ex) {}
                                }
                                ++attemptCount;
                                continue;
                            }
                        }
                        break;
                    }
                    ++hostIndex2;
                }
                if (!connectionGood2) {
                    throw SQLError.createSQLException("Server connection failure during transaction. Due to underlying exception: '" + connectionException + "'." + (this.getParanoid() ? "" : Util.stackTraceToString(connectionException)) + "\nAttempted reconnect " + this.getMaxReconnects() + " times. Giving up.", "08001");
                }
            }
            if (this.getParanoid() && !this.getHighAvailability() && this.hostListSize <= 1) {
                this.password = null;
                this.user = null;
            }
            if (isForReconnect) {
                final Iterator statementIter = this.openStatements.values().iterator();
                Stack serverPreparedStatements = null;
                while (statementIter.hasNext()) {
                    final Object statementObj = statementIter.next();
                    if (statementObj instanceof ServerPreparedStatement) {
                        if (serverPreparedStatements == null) {
                            serverPreparedStatements = new Stack();
                        }
                        serverPreparedStatements.add(statementObj);
                    }
                }
                if (serverPreparedStatements != null) {
                    while (!serverPreparedStatements.isEmpty()) {
                        serverPreparedStatements.pop().rePrepare();
                    }
                }
            }
            return newIo;
        }
        finally {
            this.queriesIssuedFailedOver = queriesIssuedFailedOverCopy;
        }
    }
    
    private void createPreparedStatementCaches() {
        final int cacheSize = this.getPreparedStatementCacheSize();
        this.cachedPreparedStatementParams = new HashMap(cacheSize);
        this.serverSideStatementCheckCache = new LRUCache(cacheSize);
        this.serverSideStatementCache = new LRUCache(cacheSize) {
            protected boolean removeEldestEntry(final Map.Entry eldest) {
                if (this.maxElements <= 1) {
                    return false;
                }
                final boolean removeIt = super.removeEldestEntry(eldest);
                if (removeIt) {
                    final ServerPreparedStatement ps = eldest.getValue();
                    ps.setClosed(ps.isCached = false);
                    try {
                        ps.close();
                    }
                    catch (SQLException ex) {}
                }
                return removeIt;
            }
        };
    }
    
    public java.sql.Statement createStatement() throws SQLException {
        return this.createStatement(1003, 1007);
    }
    
    public java.sql.Statement createStatement(final int resultSetType, final int resultSetConcurrency) throws SQLException {
        this.checkClosed();
        final Statement stmt = new Statement(this, this.database);
        stmt.setResultSetType(resultSetType);
        stmt.setResultSetConcurrency(resultSetConcurrency);
        return stmt;
    }
    
    public java.sql.Statement createStatement(final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        if (this.getPedantic() && resultSetHoldability != 1) {
            throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009");
        }
        return this.createStatement(resultSetType, resultSetConcurrency);
    }
    
    protected void dumpTestcaseQuery(final String query) {
        System.err.println(query);
    }
    
    protected Connection duplicate() throws SQLException {
        return new Connection(this.origHostToConnectTo, this.origPortToConnectTo, this.props, this.origDatabaseToConnectTo, this.myURL);
    }
    
    ResultSet execSQL(final Statement callingStatement, final String sql, final int maxRows, final Buffer packet, final int resultSetType, final int resultSetConcurrency, final boolean streamResults, final String catalog, final boolean unpackFields) throws SQLException {
        return this.execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, unpackFields, false);
    }
    
    ResultSet execSQL(final Statement callingStatement, final String sql, final int maxRows, final Buffer packet, final int resultSetType, final int resultSetConcurrency, final boolean streamResults, final String catalog, final boolean unpackFields, final boolean isBatch) throws SQLException {
        synchronized (this.mutex) {
            long queryStartTime = 0L;
            int endOfQueryPacketPosition = 0;
            if (packet != null) {
                endOfQueryPacketPosition = packet.getPosition();
            }
            if (this.getGatherPerformanceMetrics()) {
                queryStartTime = System.currentTimeMillis();
            }
            this.lastQueryFinishedTime = 0L;
            if (this.failedOver && this.autoCommit && !isBatch && this.shouldFallBack() && !this.executingFailoverReconnect) {
                try {
                    this.createNewIO(this.executingFailoverReconnect = true);
                    final String connectedHost = this.io.getHost();
                    if (connectedHost != null && this.hostList.get(0).equals(connectedHost)) {
                        this.failedOver = false;
                        this.queriesIssuedFailedOver = 0L;
                        this.setReadOnlyInternal(false);
                    }
                }
                finally {
                    this.executingFailoverReconnect = false;
                }
            }
            Label_0213: {
                if ((!this.getHighAvailability() && !this.failedOver) || (!this.autoCommit && !this.getAutoReconnectForPools()) || !this.needsPing || isBatch) {
                    break Label_0213;
                }
                try {
                    this.pingInternal(false);
                    this.needsPing = false;
                }
                catch (Exception Ex) {
                    this.createNewIO(true);
                }
                try {
                    if (packet == null) {
                        String encoding = null;
                        if (this.getUseUnicode()) {
                            encoding = this.getEncoding();
                        }
                        return this.io.sqlQueryDirect(callingStatement, sql, encoding, null, maxRows, this, resultSetType, resultSetConcurrency, streamResults, catalog, unpackFields);
                    }
                    return this.io.sqlQueryDirect(callingStatement, null, null, packet, maxRows, this, resultSetType, resultSetConcurrency, streamResults, catalog, unpackFields);
                }
                catch (SQLException sqlE) {
                    if (this.getDumpQueriesOnException()) {
                        final String extractedSql = this.extractSqlFromPacket(sql, packet, endOfQueryPacketPosition);
                        final StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);
                        messageBuf.append("\n\nQuery being executed when exception was thrown:\n\n");
                        messageBuf.append(extractedSql);
                        sqlE = appendMessageToException(sqlE, messageBuf.toString());
                    }
                    if (this.getHighAvailability() || this.failedOver) {
                        this.needsPing = true;
                    }
                    else {
                        final String sqlState = sqlE.getSQLState();
                        if (sqlState != null && sqlState.equals("08S01")) {
                            this.cleanup(sqlE);
                        }
                    }
                    throw sqlE;
                }
                catch (Exception ex) {
                    if (this.getHighAvailability() || this.failedOver) {
                        this.needsPing = true;
                    }
                    else if (ex instanceof IOException) {
                        this.cleanup(ex);
                    }
                    final String exceptionType = ex.getClass().getName();
                    String exceptionMessage = ex.getMessage();
                    if (!this.getParanoid()) {
                        exceptionMessage += "\n\nNested Stack Trace:\n";
                        exceptionMessage += Util.stackTraceToString(ex);
                    }
                    throw new SQLException("Error during query: Unexpected Exception: " + exceptionType + " message given: " + exceptionMessage, "S1000");
                }
                finally {
                    if (this.getMaintainTimeStats()) {
                        this.lastQueryFinishedTime = System.currentTimeMillis();
                    }
                    if (this.failedOver) {
                        ++this.queriesIssuedFailedOver;
                    }
                    if (this.getGatherPerformanceMetrics()) {
                        final long queryTime = System.currentTimeMillis() - queryStartTime;
                        this.registerQueryExecutionTime(queryTime);
                    }
                }
            }
        }
    }
    
    protected String extractSqlFromPacket(final String possibleSqlQuery, final Buffer queryPacket, final int endOfQueryPacketPosition) throws SQLException {
        String extractedSql = null;
        if (possibleSqlQuery != null) {
            if (possibleSqlQuery.length() > this.getMaxQuerySizeToLog()) {
                final StringBuffer truncatedQueryBuf = new StringBuffer(possibleSqlQuery.substring(0, this.getMaxQuerySizeToLog()));
                truncatedQueryBuf.append(Messages.getString("MysqlIO.25"));
                extractedSql = truncatedQueryBuf.toString();
            }
            else {
                extractedSql = possibleSqlQuery;
            }
        }
        if (extractedSql == null) {
            int extractPosition = endOfQueryPacketPosition;
            boolean truncated = false;
            if (endOfQueryPacketPosition > this.getMaxQuerySizeToLog()) {
                extractPosition = this.getMaxQuerySizeToLog();
                truncated = true;
            }
            extractedSql = new String(queryPacket.getByteBuffer(), 5, extractPosition - 5);
            if (truncated) {
                extractedSql += Messages.getString("MysqlIO.25");
            }
        }
        return extractedSql;
    }
    
    protected void finalize() throws Throwable {
        this.cleanup(null);
    }
    
    protected StringBuffer generateConnectionCommentBlock(final StringBuffer buf) {
        buf.append("/* conn id ");
        buf.append(this.getId());
        buf.append(" */ ");
        return buf;
    }
    
    public int getActiveStatementCount() {
        if (this.openStatements != null) {
            synchronized (this.openStatements) {
                return this.openStatements.size();
            }
        }
        return 0;
    }
    
    public boolean getAutoCommit() throws SQLException {
        return this.autoCommit;
    }
    
    protected Calendar getCalendarInstanceForSessionOrNew() {
        if (this.getDynamicCalendars()) {
            return Calendar.getInstance();
        }
        return this.getSessionLockedCalendar();
    }
    
    public String getCatalog() throws SQLException {
        return this.database;
    }
    
    protected String getCharacterSetMetadata() {
        return this.characterSetMetadata;
    }
    
    SingleByteCharsetConverter getCharsetConverter(final String javaEncodingName) throws SQLException {
        if (javaEncodingName == null) {
            return null;
        }
        if (this.usePlatformCharsetConverters) {
            return null;
        }
        SingleByteCharsetConverter converter = null;
        synchronized (this.charsetConverterMap) {
            final Object asObject = this.charsetConverterMap.get(javaEncodingName);
            if (asObject == Connection.CHARSET_CONVERTER_NOT_AVAILABLE_MARKER) {
                return null;
            }
            converter = (SingleByteCharsetConverter)asObject;
            if (converter == null) {
                try {
                    converter = SingleByteCharsetConverter.getInstance(javaEncodingName, this);
                    if (converter == null) {
                        this.charsetConverterMap.put(javaEncodingName, Connection.CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
                    }
                    else {
                        this.charsetConverterMap.put(javaEncodingName, converter);
                    }
                }
                catch (UnsupportedEncodingException unsupEncEx) {
                    this.charsetConverterMap.put(javaEncodingName, Connection.CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
                    converter = null;
                }
            }
        }
        return converter;
    }
    
    protected String getCharsetNameForIndex(final int charsetIndex) throws SQLException {
        String charsetName = null;
        if (this.getUseOldUTF8Behavior()) {
            return this.getEncoding();
        }
        if (charsetIndex != -1) {
            try {
                charsetName = this.indexToCharsetMapping[charsetIndex];
                if (("sjis".equalsIgnoreCase(charsetName) || "MS932".equalsIgnoreCase(charsetName)) && CharsetMapping.isAliasForSjis(this.getEncoding())) {
                    charsetName = this.getEncoding();
                }
            }
            catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
                throw SQLError.createSQLException("Unknown character set index for field '" + charsetIndex + "' received from server.", "S1000");
            }
            if (charsetName == null) {
                charsetName = this.getEncoding();
            }
        }
        else {
            charsetName = this.getEncoding();
        }
        return charsetName;
    }
    
    protected TimeZone getDefaultTimeZone() {
        return this.defaultTimeZone;
    }
    
    public int getHoldability() throws SQLException {
        return 2;
    }
    
    long getId() {
        return this.connectionId;
    }
    
    public long getIdleFor() {
        if (this.lastQueryFinishedTime == 0L) {
            return 0L;
        }
        final long now = System.currentTimeMillis();
        final long idleTime = now - this.lastQueryFinishedTime;
        return idleTime;
    }
    
    protected MysqlIO getIO() throws SQLException {
        if (this.io == null || this.isClosed) {
            throw SQLError.createSQLException("Operation not allowed on closed connection", "08003");
        }
        return this.io;
    }
    
    public Log getLog() throws SQLException {
        return this.log;
    }
    
    int getMaxAllowedPacket() {
        return this.maxAllowedPacket;
    }
    
    protected int getMaxBytesPerChar(final String javaCharsetName) throws SQLException {
        final String charset = CharsetMapping.getMysqlEncodingForJavaEncoding(javaCharsetName, this);
        if (!this.versionMeetsMinimum(4, 1, 0)) {
            return 1;
        }
        Map mapToCheck = null;
        if (!this.getUseDynamicCharsetInfo()) {
            mapToCheck = CharsetMapping.STATIC_CHARSET_TO_NUM_BYTES_MAP;
        }
        else {
            mapToCheck = this.charsetToNumBytesMap;
            synchronized (this.charsetToNumBytesMap) {
                if (this.charsetToNumBytesMap.isEmpty()) {
                    java.sql.Statement stmt = null;
                    java.sql.ResultSet rs = null;
                    try {
                        stmt = this.getMetadataSafeStatement();
                        rs = stmt.executeQuery("SHOW CHARACTER SET");
                        while (rs.next()) {
                            this.charsetToNumBytesMap.put(rs.getString("Charset"), new Integer(rs.getInt("Maxlen")));
                        }
                        rs.close();
                        rs = null;
                        stmt.close();
                        stmt = null;
                    }
                    finally {
                        if (rs != null) {
                            rs.close();
                            rs = null;
                        }
                        if (stmt != null) {
                            stmt.close();
                            stmt = null;
                        }
                    }
                }
            }
        }
        final Integer mbPerChar = mapToCheck.get(charset);
        if (mbPerChar != null) {
            return mbPerChar;
        }
        return 1;
    }
    
    public java.sql.DatabaseMetaData getMetaData() throws SQLException {
        this.checkClosed();
        if (this.getUseInformationSchema() && this.versionMeetsMinimum(5, 0, 7)) {
            return new DatabaseMetaDataUsingInfoSchema(this, this.database);
        }
        return new DatabaseMetaData(this, this.database);
    }
    
    protected java.sql.Statement getMetadataSafeStatement() throws SQLException {
        final java.sql.Statement stmt = this.createStatement();
        if (stmt.getMaxRows() != 0) {
            stmt.setMaxRows(0);
        }
        stmt.setEscapeProcessing(false);
        return stmt;
    }
    
    Object getMutex() throws SQLException {
        if (this.io == null) {
            throw SQLError.createSQLException("Connection.close() has already been called. Invalid operation in this state.", "08003");
        }
        this.reportMetricsIfNeeded();
        return this.mutex;
    }
    
    int getNetBufferLength() {
        return this.netBufferLength;
    }
    
    protected String getServerCharacterEncoding() {
        if (this.io.versionMeetsMinimum(4, 1, 0)) {
            return this.serverVariables.get("character_set_server");
        }
        return this.serverVariables.get("character_set");
    }
    
    int getServerMajorVersion() {
        return this.io.getServerMajorVersion();
    }
    
    int getServerMinorVersion() {
        return this.io.getServerMinorVersion();
    }
    
    int getServerSubMinorVersion() {
        return this.io.getServerSubMinorVersion();
    }
    
    public TimeZone getServerTimezoneTZ() {
        return this.serverTimezoneTZ;
    }
    
    String getServerVariable(final String variableName) {
        if (this.serverVariables != null) {
            return this.serverVariables.get(variableName);
        }
        return null;
    }
    
    String getServerVersion() {
        return this.io.getServerVersion();
    }
    
    protected Calendar getSessionLockedCalendar() {
        return this.sessionCalendar;
    }
    
    public int getTransactionIsolation() throws SQLException {
        if (this.hasIsolationLevels && !this.getUseLocalSessionState()) {
            java.sql.Statement stmt = null;
            java.sql.ResultSet rs = null;
            try {
                stmt = this.getMetadataSafeStatement();
                String query = null;
                int offset = 0;
                if (this.versionMeetsMinimum(4, 0, 3)) {
                    query = "SELECT @@session.tx_isolation";
                    offset = 1;
                }
                else {
                    query = "SHOW VARIABLES LIKE 'transaction_isolation'";
                    offset = 2;
                }
                rs = stmt.executeQuery(query);
                if (rs.next()) {
                    final String s = rs.getString(offset);
                    if (s != null) {
                        final Integer intTI = Connection.mapTransIsolationNameToValue.get(s);
                        if (intTI != null) {
                            return intTI;
                        }
                    }
                    throw SQLError.createSQLException("Could not map transaction isolation '" + s + " to a valid JDBC level.", "S1000");
                }
                throw SQLError.createSQLException("Could not retrieve transaction isolation level from server", "S1000");
            }
            finally {
                if (rs != null) {
                    try {
                        rs.close();
                    }
                    catch (Exception ex) {}
                    rs = null;
                }
                if (stmt != null) {
                    try {
                        stmt.close();
                    }
                    catch (Exception ex2) {}
                    stmt = null;
                }
            }
        }
        return this.isolationLevel;
    }
    
    public synchronized Map getTypeMap() throws SQLException {
        if (this.typeMap == null) {
            this.typeMap = new HashMap();
        }
        return this.typeMap;
    }
    
    String getURL() {
        return this.myURL;
    }
    
    String getUser() {
        return this.user;
    }
    
    protected Calendar getUtcCalendar() {
        return this.utcCalendar;
    }
    
    public SQLWarning getWarnings() throws SQLException {
        return null;
    }
    
    public boolean hasSameProperties(final Connection c) {
        return this.props.equals(c.props);
    }
    
    protected void incrementNumberOfPreparedExecutes() {
        if (this.getGatherPerformanceMetrics()) {
            ++this.numberOfPreparedExecutes;
            ++this.numberOfQueriesIssued;
        }
    }
    
    protected void incrementNumberOfPrepares() {
        if (this.getGatherPerformanceMetrics()) {
            ++this.numberOfPrepares;
        }
    }
    
    protected void incrementNumberOfResultSetsCreated() {
        if (this.getGatherPerformanceMetrics()) {
            ++this.numberOfResultSetsCreated;
        }
    }
    
    private void initializeDriverProperties(final Properties info) throws SQLException {
        this.initializeProperties(info);
        this.usePlatformCharsetConverters = this.getUseJvmCharsetConverters();
        this.log = LogFactory.getLogger(this.getLogger(), "MySQL");
        if (this.getProfileSql() || this.getUseUsageAdvisor()) {
            this.eventSink = ProfileEventSink.getInstance(this);
        }
        if (this.getCachePreparedStatements()) {
            this.createPreparedStatementCaches();
        }
        if (this.getNoDatetimeStringSync() && this.getUseTimezone()) {
            throw SQLError.createSQLException("Can't enable noDatetimeSync and useTimezone configuration properties at the same time", "01S00");
        }
        if (this.getCacheCallableStatements()) {
            this.parsedCallableStatementCache = new LRUCache(this.getCallableStatementCacheSize());
        }
        if (this.getAllowMultiQueries()) {
            this.setCacheResultSetMetadata(false);
        }
        if (this.getCacheResultSetMetadata()) {
            this.resultSetMetadataCache = new LRUCache(this.getMetadataCacheSize());
        }
    }
    
    private void initializePropsFromServer() throws SQLException {
        this.setSessionVariables();
        if (!this.versionMeetsMinimum(4, 1, 0)) {
            this.setTransformedBitIsBoolean(false);
        }
        this.parserKnowsUnicode = this.versionMeetsMinimum(4, 1, 0);
        if (this.getUseServerPreparedStmts() && this.versionMeetsMinimum(4, 1, 0)) {
            this.useServerPreparedStmts = true;
            if (this.versionMeetsMinimum(5, 0, 0) && !this.versionMeetsMinimum(5, 0, 3)) {
                this.useServerPreparedStmts = false;
            }
        }
        this.serverVariables.clear();
        if (this.versionMeetsMinimum(3, 21, 22)) {
            this.loadServerVariables();
            this.buildCollationMapping();
            LicenseConfiguration.checkLicenseType(this.serverVariables);
            final String lowerCaseTables = this.serverVariables.get("lower_case_table_names");
            this.lowerCaseTableNames = ("on".equalsIgnoreCase(lowerCaseTables) || "1".equalsIgnoreCase(lowerCaseTables) || "2".equalsIgnoreCase(lowerCaseTables));
            this.configureTimezone();
            if (this.serverVariables.containsKey("max_allowed_packet")) {
                this.maxAllowedPacket = this.getServerVariableAsInt("max_allowed_packet", 1048576);
                final int preferredBlobSendChunkSize = this.getBlobSendChunkSize();
                final int allowedBlobSendChunkSize = Math.min(preferredBlobSendChunkSize, this.maxAllowedPacket) - 8192 - 11;
                this.setBlobSendChunkSize(String.valueOf(allowedBlobSendChunkSize));
            }
            if (this.serverVariables.containsKey("net_buffer_length")) {
                this.netBufferLength = this.getServerVariableAsInt("net_buffer_length", 16384);
            }
            this.checkTransactionIsolationLevel();
            if (!this.versionMeetsMinimum(4, 1, 0)) {
                this.checkServerEncoding();
            }
            this.io.checkForCharsetMismatch();
            if (this.serverVariables.containsKey("sql_mode")) {
                int sqlMode = 0;
                final String sqlModeAsString = this.serverVariables.get("sql_mode");
                try {
                    sqlMode = Integer.parseInt(sqlModeAsString);
                }
                catch (NumberFormatException nfe) {
                    sqlMode = 0;
                    if (sqlModeAsString != null) {
                        if (sqlModeAsString.indexOf("ANSI_QUOTES") != -1) {
                            sqlMode |= 0x4;
                        }
                        if (sqlModeAsString.indexOf("NO_BACKSLASH_ESCAPES") != -1) {
                            this.noBackslashEscapes = true;
                        }
                    }
                }
                if ((sqlMode & 0x4) > 0) {
                    this.useAnsiQuotes = true;
                }
                else {
                    this.useAnsiQuotes = false;
                }
            }
        }
        this.errorMessageEncoding = CharsetMapping.getCharacterEncodingForErrorMessages(this);
        final boolean overrideDefaultAutocommit = this.isAutoCommitNonDefaultOnServer();
        this.configureClientCharacterSet();
        if (this.versionMeetsMinimum(3, 23, 15)) {
            this.transactionsSupported = true;
            if (!overrideDefaultAutocommit) {
                this.setAutoCommit(true);
            }
        }
        else {
            this.transactionsSupported = false;
        }
        if (this.versionMeetsMinimum(3, 23, 36)) {
            this.hasIsolationLevels = true;
        }
        else {
            this.hasIsolationLevels = false;
        }
        this.hasQuotedIdentifiers = this.versionMeetsMinimum(3, 23, 6);
        this.io.resetMaxBuf();
        if (this.io.versionMeetsMinimum(4, 1, 0)) {
            final String characterSetResultsOnServerMysql = this.serverVariables.get("jdbc.local.character_set_results");
            if (characterSetResultsOnServerMysql == null || StringUtils.startsWithIgnoreCaseAndWs(characterSetResultsOnServerMysql, "NULL") || characterSetResultsOnServerMysql.length() == 0) {
                final String defaultMetadataCharsetMysql = this.serverVariables.get("character_set_system");
                String defaultMetadataCharset = null;
                if (defaultMetadataCharsetMysql != null) {
                    defaultMetadataCharset = CharsetMapping.getJavaEncodingForMysqlEncoding(defaultMetadataCharsetMysql, this);
                }
                else {
                    defaultMetadataCharset = "UTF-8";
                }
                this.characterSetMetadata = defaultMetadataCharset;
            }
            else {
                this.characterSetResultsOnServer = CharsetMapping.getJavaEncodingForMysqlEncoding(characterSetResultsOnServerMysql, this);
                this.characterSetMetadata = this.characterSetResultsOnServer;
            }
        }
        if (this.versionMeetsMinimum(4, 1, 0) && !this.versionMeetsMinimum(4, 1, 10) && this.getAllowMultiQueries() && "ON".equalsIgnoreCase(this.serverVariables.get("query_cache_type")) && !"0".equalsIgnoreCase(this.serverVariables.get("query_cache_size"))) {
            this.setAllowMultiQueries(false);
        }
        this.setupServerForTruncationChecks();
    }
    
    private int getServerVariableAsInt(final String variableName, final int fallbackValue) throws SQLException {
        try {
            return Integer.parseInt(this.serverVariables.get(variableName));
        }
        catch (NumberFormatException nfe) {
            this.getLog().logWarn(Messages.getString("Connection.BadValueInServerVariables", new Object[] { variableName, this.serverVariables.get(variableName), new Integer(fallbackValue) }));
            return fallbackValue;
        }
    }
    
    private boolean isAutoCommitNonDefaultOnServer() throws SQLException {
        boolean overrideDefaultAutocommit = false;
        final String initConnectValue = this.serverVariables.get("init_connect");
        if (this.versionMeetsMinimum(4, 1, 2) && initConnectValue != null && initConnectValue.length() > 0) {
            if (!this.getElideSetAutoCommits()) {
                java.sql.ResultSet rs = null;
                java.sql.Statement stmt = null;
                try {
                    stmt = this.getMetadataSafeStatement();
                    rs = stmt.executeQuery("SELECT @@session.autocommit");
                    if (rs.next()) {
                        this.autoCommit = rs.getBoolean(1);
                        if (!this.autoCommit) {
                            overrideDefaultAutocommit = true;
                        }
                    }
                }
                finally {
                    if (rs != null) {
                        try {
                            rs.close();
                        }
                        catch (SQLException ex) {}
                    }
                    if (stmt != null) {
                        try {
                            stmt.close();
                        }
                        catch (SQLException ex2) {}
                    }
                }
            }
            else if (this.getIO().isSetNeededForAutoCommitMode(true)) {
                this.autoCommit = false;
                overrideDefaultAutocommit = true;
            }
        }
        return overrideDefaultAutocommit;
    }
    
    private void setupServerForTruncationChecks() throws SQLException {
        if (this.getJdbcCompliantTruncation() && this.versionMeetsMinimum(5, 0, 2)) {
            final String currentSqlMode = this.serverVariables.get("sql_mode");
            final boolean strictTransTablesIsSet = StringUtils.indexOfIgnoreCase(currentSqlMode, "STRICT_TRANS_TABLES") != -1;
            if (currentSqlMode == null || currentSqlMode.length() == 0 || !strictTransTablesIsSet) {
                final StringBuffer commandBuf = new StringBuffer("SET sql_mode='");
                if (currentSqlMode != null && currentSqlMode.length() > 0) {
                    commandBuf.append(currentSqlMode);
                    commandBuf.append(",");
                }
                commandBuf.append("STRICT_TRANS_TABLES'");
                this.execSQL(null, commandBuf.toString(), -1, null, 1003, 1007, false, this.database, true, false);
                this.setJdbcCompliantTruncation(false);
            }
            else if (strictTransTablesIsSet) {
                this.setJdbcCompliantTruncation(false);
            }
        }
    }
    
    protected boolean isClientTzUTC() {
        return this.isClientTzUTC;
    }
    
    public boolean isClosed() {
        return this.isClosed;
    }
    
    protected boolean isCursorFetchEnabled() throws SQLException {
        return this.versionMeetsMinimum(5, 0, 2) && this.getUseCursorFetch();
    }
    
    public boolean isInGlobalTx() {
        return this.isInGlobalTx;
    }
    
    public synchronized boolean isMasterConnection() {
        return !this.failedOver;
    }
    
    public boolean isNoBackslashEscapesSet() {
        return this.noBackslashEscapes;
    }
    
    boolean isReadInfoMsgEnabled() {
        return this.readInfoMsg;
    }
    
    public boolean isReadOnly() throws SQLException {
        return this.readOnly;
    }
    
    protected boolean isRunningOnJDK13() {
        return this.isRunningOnJDK13;
    }
    
    public synchronized boolean isSameResource(final Connection otherConnection) {
        if (otherConnection == null) {
            return false;
        }
        boolean directCompare = true;
        final String otherHost = otherConnection.origHostToConnectTo;
        final String otherOrigDatabase = otherConnection.origDatabaseToConnectTo;
        final String otherCurrentCatalog = otherConnection.database;
        if (!nullSafeCompare(otherHost, this.origHostToConnectTo)) {
            directCompare = false;
        }
        else if (otherHost != null && otherHost.indexOf(",") == -1 && otherHost.indexOf(":") == -1) {
            directCompare = (otherConnection.origPortToConnectTo == this.origPortToConnectTo);
        }
        if (directCompare) {
            if (!nullSafeCompare(otherOrigDatabase, this.origDatabaseToConnectTo)) {
                directCompare = false;
                directCompare = false;
            }
            else if (!nullSafeCompare(otherCurrentCatalog, this.database)) {
                directCompare = false;
            }
        }
        if (directCompare) {
            return true;
        }
        final String otherResourceId = otherConnection.getResourceId();
        final String myResourceId = this.getResourceId();
        if (otherResourceId != null || myResourceId != null) {
            directCompare = nullSafeCompare(otherResourceId, myResourceId);
            if (directCompare) {
                return true;
            }
        }
        return false;
    }
    
    protected boolean isServerTzUTC() {
        return this.isServerTzUTC;
    }
    
    private void loadServerVariables() throws SQLException {
        if (this.getCacheServerConfiguration()) {
            synchronized (Connection.serverConfigByUrl) {
                final Map cachedVariableMap = Connection.serverConfigByUrl.get(this.getURL());
                if (cachedVariableMap != null) {
                    this.serverVariables = cachedVariableMap;
                    this.usingCachedConfig = true;
                    return;
                }
            }
        }
        Statement stmt = null;
        ResultSet results = null;
        try {
            stmt = (Statement)this.createStatement();
            stmt.setEscapeProcessing(false);
            results = (ResultSet)stmt.executeQuery("SHOW SESSION VARIABLES");
            while (results.next()) {
                this.serverVariables.put(results.getString(1), results.getString(2));
            }
            if (this.getCacheServerConfiguration()) {
                synchronized (Connection.serverConfigByUrl) {
                    Connection.serverConfigByUrl.put(this.getURL(), this.serverVariables);
                }
            }
        }
        catch (SQLException e) {
            throw e;
        }
        finally {
            if (results != null) {
                try {
                    results.close();
                }
                catch (SQLException ex) {}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                }
                catch (SQLException ex2) {}
            }
        }
    }
    
    public boolean lowerCaseTableNames() {
        return this.lowerCaseTableNames;
    }
    
    void maxRowsChanged(final Statement stmt) {
        synchronized (this.mutex) {
            if (this.statementsUsingMaxRows == null) {
                this.statementsUsingMaxRows = new HashMap();
            }
            this.statementsUsingMaxRows.put(stmt, stmt);
            this.maxRowsChanged = true;
        }
    }
    
    public String nativeSQL(final String sql) throws SQLException {
        if (sql == null) {
            return null;
        }
        final Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.serverSupportsConvertFn(), this);
        if (escapedSqlResult instanceof String) {
            return (String)escapedSqlResult;
        }
        return ((EscapeProcessorResult)escapedSqlResult).escapedSql;
    }
    
    private CallableStatement parseCallableStatement(final String sql) throws SQLException {
        final Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.serverSupportsConvertFn(), this);
        boolean isFunctionCall = false;
        String parsedSql = null;
        if (escapedSqlResult instanceof EscapeProcessorResult) {
            parsedSql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
            isFunctionCall = ((EscapeProcessorResult)escapedSqlResult).callingStoredFunction;
        }
        else {
            parsedSql = (String)escapedSqlResult;
            isFunctionCall = false;
        }
        return new CallableStatement(this, parsedSql, this.database, isFunctionCall);
    }
    
    public boolean parserKnowsUnicode() {
        return this.parserKnowsUnicode;
    }
    
    public void ping() throws SQLException {
        this.pingInternal(true);
    }
    
    private void pingInternal(final boolean checkForClosedConnection) throws SQLException {
        if (checkForClosedConnection) {
            this.checkClosed();
        }
        this.io.sendCommand(14, null, null, false, null);
    }
    
    public java.sql.CallableStatement prepareCall(final String sql) throws SQLException {
        if (this.getUseUltraDevWorkAround()) {
            return new UltraDevWorkAround(this.prepareStatement(sql));
        }
        return this.prepareCall(sql, 1003, 1007);
    }
    
    public java.sql.CallableStatement prepareCall(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        if (this.versionMeetsMinimum(5, 0, 0)) {
            CallableStatement cStmt = null;
            if (!this.getCacheCallableStatements()) {
                cStmt = this.parseCallableStatement(sql);
            }
            else {
                synchronized (this.parsedCallableStatementCache) {
                    final CompoundCacheKey key = new CompoundCacheKey(this.getCatalog(), sql);
                    CallableStatement.CallableStatementParamInfo cachedParamInfo = this.parsedCallableStatementCache.get(key);
                    if (cachedParamInfo != null) {
                        cStmt = new CallableStatement(this, cachedParamInfo);
                    }
                    else {
                        cStmt = this.parseCallableStatement(sql);
                        cachedParamInfo = cStmt.paramInfo;
                        this.parsedCallableStatementCache.put(key, cachedParamInfo);
                    }
                }
            }
            cStmt.setResultSetType(resultSetType);
            cStmt.setResultSetConcurrency(resultSetConcurrency);
            return cStmt;
        }
        throw SQLError.createSQLException("Callable statements not supported.", "S1C00");
    }
    
    public java.sql.CallableStatement prepareCall(final String sql, final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        if (this.getPedantic() && resultSetHoldability != 1) {
            throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009");
        }
        final CallableStatement cStmt = (CallableStatement)this.prepareCall(sql, resultSetType, resultSetConcurrency);
        return cStmt;
    }
    
    public java.sql.PreparedStatement prepareStatement(final String sql) throws SQLException {
        return this.prepareStatement(sql, 1003, 1007);
    }
    
    public java.sql.PreparedStatement prepareStatement(final String sql, final int autoGenKeyIndex) throws SQLException {
        final java.sql.PreparedStatement pStmt = this.prepareStatement(sql);
        ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
        return pStmt;
    }
    
    public java.sql.PreparedStatement prepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        this.checkClosed();
        PreparedStatement pStmt = null;
        boolean canServerPrepare = true;
        final String nativeSql = this.getProcessEscapeCodesForPrepStmts() ? this.nativeSQL(sql) : sql;
        if (this.getEmulateUnsupportedPstmts()) {
            canServerPrepare = this.canHandleAsServerPreparedStatement(nativeSql);
        }
        if (this.useServerPreparedStmts && canServerPrepare) {
            if (this.getCachePreparedStatements()) {
                synchronized (this.serverSideStatementCache) {
                    pStmt = this.serverSideStatementCache.remove(sql);
                    if (pStmt != null) {
                        ((ServerPreparedStatement)pStmt).setClosed(false);
                        pStmt.clearParameters();
                    }
                    if (pStmt == null) {
                        try {
                            pStmt = new ServerPreparedStatement(this, nativeSql, this.database, resultSetType, resultSetConcurrency);
                            if (sql.length() < this.getPreparedStatementCacheSqlLimit()) {
                                ((ServerPreparedStatement)pStmt).isCached = true;
                            }
                        }
                        catch (SQLException sqlEx) {
                            if (!this.getEmulateUnsupportedPstmts()) {
                                throw sqlEx;
                            }
                            pStmt = this.clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
                            if (sql.length() < this.getPreparedStatementCacheSqlLimit()) {
                                this.serverSideStatementCheckCache.put(sql, Boolean.FALSE);
                            }
                        }
                    }
                    return pStmt;
                }
            }
            try {
                pStmt = new ServerPreparedStatement(this, nativeSql, this.database, resultSetType, resultSetConcurrency);
            }
            catch (SQLException sqlEx2) {
                if (!this.getEmulateUnsupportedPstmts()) {
                    throw sqlEx2;
                }
                pStmt = this.clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
            }
        }
        else {
            pStmt = this.clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
        }
        return pStmt;
    }
    
    public java.sql.PreparedStatement prepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        if (this.getPedantic() && resultSetHoldability != 1) {
            throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009");
        }
        return this.prepareStatement(sql, resultSetType, resultSetConcurrency);
    }
    
    public java.sql.PreparedStatement prepareStatement(final String sql, final int[] autoGenKeyIndexes) throws SQLException {
        final java.sql.PreparedStatement pStmt = this.prepareStatement(sql);
        ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyIndexes != null && autoGenKeyIndexes.length > 0);
        return pStmt;
    }
    
    public java.sql.PreparedStatement prepareStatement(final String sql, final String[] autoGenKeyColNames) throws SQLException {
        final java.sql.PreparedStatement pStmt = this.prepareStatement(sql);
        ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyColNames != null && autoGenKeyColNames.length > 0);
        return pStmt;
    }
    
    protected void realClose(final boolean calledExplicitly, final boolean issueRollback, final boolean skipLocalTeardown, final Throwable reason) throws SQLException {
        SQLException sqlEx = null;
        if (this.isClosed()) {
            return;
        }
        this.forceClosedReason = reason;
        try {
            if (!skipLocalTeardown) {
                if (!this.getAutoCommit() && issueRollback) {
                    try {
                        this.rollback();
                    }
                    catch (SQLException ex) {
                        sqlEx = ex;
                    }
                }
                this.reportMetrics();
                if (this.getUseUsageAdvisor()) {
                    if (!calledExplicitly) {
                        final String message = "Connection implicitly closed by Driver. You should call Connection.close() from your code to free resources more efficiently and avoid resource leaks.";
                        this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.getCatalog(), this.getId(), -1, -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
                    }
                    final long connectionLifeTime = System.currentTimeMillis() - this.connectionCreationTimeMillis;
                    if (connectionLifeTime < 500L) {
                        final String message2 = "Connection lifetime of < .5 seconds. You might be un-necessarily creating short-lived connections and should investigate connection pooling to be more efficient.";
                        this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.getCatalog(), this.getId(), -1, -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message2));
                    }
                }
                try {
                    this.closeAllOpenStatements();
                }
                catch (SQLException ex) {
                    sqlEx = ex;
                }
                if (this.io != null) {
                    try {
                        this.io.quit();
                    }
                    catch (Exception e) {}
                }
            }
            else {
                this.io.forceClose();
            }
        }
        finally {
            this.openStatements = null;
            this.io = null;
            ProfileEventSink.removeInstance(this);
            this.isClosed = true;
        }
        if (sqlEx != null) {
            throw sqlEx;
        }
    }
    
    protected void recachePreparedStatement(final ServerPreparedStatement pstmt) {
        synchronized (this.serverSideStatementCache) {
            this.serverSideStatementCache.put(pstmt.originalSql, pstmt);
        }
    }
    
    protected void registerQueryExecutionTime(final long queryTimeMs) {
        if (queryTimeMs > this.longestQueryTimeMs) {
            this.longestQueryTimeMs = queryTimeMs;
            this.repartitionPerformanceHistogram();
        }
        this.addToPerformanceHistogram(queryTimeMs, 1);
        if (queryTimeMs < this.shortestQueryTimeMs) {
            this.shortestQueryTimeMs = ((queryTimeMs == 0L) ? 1L : queryTimeMs);
        }
        ++this.numberOfQueriesIssued;
        this.totalQueryTimeMs += queryTimeMs;
    }
    
    void registerStatement(final Statement stmt) {
        synchronized (this.openStatements) {
            this.openStatements.put(stmt, stmt);
        }
    }
    
    public void releaseSavepoint(final Savepoint arg0) throws SQLException {
    }
    
    private void repartitionHistogram(final int[] histCounts, final long[] histBreakpoints, final long currentLowerBound, final long currentUpperBound) {
        if (this.oldHistCounts == null) {
            this.oldHistCounts = new int[histCounts.length];
            this.oldHistBreakpoints = new long[histBreakpoints.length];
        }
        for (int i = 0; i < histCounts.length; ++i) {
            this.oldHistCounts[i] = histCounts[i];
        }
        for (int i = 0; i < this.oldHistBreakpoints.length; ++i) {
            this.oldHistBreakpoints[i] = histBreakpoints[i];
        }
        this.createInitialHistogram(histBreakpoints, currentLowerBound, currentUpperBound);
        for (int i = 0; i < 20; ++i) {
            this.addToHistogram(histCounts, histBreakpoints, this.oldHistBreakpoints[i], this.oldHistCounts[i], currentLowerBound, currentUpperBound);
        }
    }
    
    private void repartitionPerformanceHistogram() {
        this.checkAndCreatePerformanceHistogram();
        this.repartitionHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, (this.shortestQueryTimeMs == Long.MAX_VALUE) ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
    }
    
    private void repartitionTablesAccessedHistogram() {
        this.checkAndCreateTablesAccessedHistogram();
        this.repartitionHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, (this.minimumNumberTablesAccessed == Long.MAX_VALUE) ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
    }
    
    private void reportMetrics() {
        if (this.getGatherPerformanceMetrics()) {
            final StringBuffer logMessage = new StringBuffer(256);
            logMessage.append("** Performance Metrics Report **\n");
            logMessage.append("\nLongest reported query: " + this.longestQueryTimeMs + " ms");
            logMessage.append("\nShortest reported query: " + this.shortestQueryTimeMs + " ms");
            logMessage.append("\nAverage query execution time: " + this.totalQueryTimeMs / this.numberOfQueriesIssued + " ms");
            logMessage.append("\nNumber of statements executed: " + this.numberOfQueriesIssued);
            logMessage.append("\nNumber of result sets created: " + this.numberOfResultSetsCreated);
            logMessage.append("\nNumber of statements prepared: " + this.numberOfPrepares);
            logMessage.append("\nNumber of prepared statement executions: " + this.numberOfPreparedExecutes);
            if (this.perfMetricsHistBreakpoints != null) {
                logMessage.append("\n\n\tTiming Histogram:\n");
                final int maxNumPoints = 20;
                int highestCount = Integer.MIN_VALUE;
                for (int i = 0; i < 20; ++i) {
                    if (this.perfMetricsHistCounts[i] > highestCount) {
                        highestCount = this.perfMetricsHistCounts[i];
                    }
                }
                if (highestCount == 0) {
                    highestCount = 1;
                }
                for (int i = 0; i < 19; ++i) {
                    if (i == 0) {
                        logMessage.append("\n\tless than " + this.perfMetricsHistBreakpoints[i + 1] + " ms: \t" + this.perfMetricsHistCounts[i]);
                    }
                    else {
                        logMessage.append("\n\tbetween " + this.perfMetricsHistBreakpoints[i] + " and " + this.perfMetricsHistBreakpoints[i + 1] + " ms: \t" + this.perfMetricsHistCounts[i]);
                    }
                    logMessage.append("\t");
                    for (int numPointsToGraph = (int)(maxNumPoints * (this.perfMetricsHistCounts[i] / (double)highestCount)), j = 0; j < numPointsToGraph; ++j) {
                        logMessage.append("*");
                    }
                    if (this.longestQueryTimeMs < this.perfMetricsHistCounts[i + 1]) {
                        break;
                    }
                }
                if (this.perfMetricsHistBreakpoints[18] < this.longestQueryTimeMs) {
                    logMessage.append("\n\tbetween ");
                    logMessage.append(this.perfMetricsHistBreakpoints[18]);
                    logMessage.append(" and ");
                    logMessage.append(this.perfMetricsHistBreakpoints[19]);
                    logMessage.append(" ms: \t");
                    logMessage.append(this.perfMetricsHistCounts[19]);
                }
            }
            if (this.numTablesMetricsHistBreakpoints != null) {
                logMessage.append("\n\n\tTable Join Histogram:\n");
                final int maxNumPoints = 20;
                int highestCount = Integer.MIN_VALUE;
                for (int i = 0; i < 20; ++i) {
                    if (this.numTablesMetricsHistCounts[i] > highestCount) {
                        highestCount = this.numTablesMetricsHistCounts[i];
                    }
                }
                if (highestCount == 0) {
                    highestCount = 1;
                }
                for (int i = 0; i < 19; ++i) {
                    if (i == 0) {
                        logMessage.append("\n\t" + this.numTablesMetricsHistBreakpoints[i + 1] + " tables or less: \t\t" + this.numTablesMetricsHistCounts[i]);
                    }
                    else {
                        logMessage.append("\n\tbetween " + this.numTablesMetricsHistBreakpoints[i] + " and " + this.numTablesMetricsHistBreakpoints[i + 1] + " tables: \t" + this.numTablesMetricsHistCounts[i]);
                    }
                    logMessage.append("\t");
                    for (int numPointsToGraph = (int)(maxNumPoints * (this.numTablesMetricsHistCounts[i] / (double)highestCount)), j = 0; j < numPointsToGraph; ++j) {
                        logMessage.append("*");
                    }
                    if (this.maximumNumberTablesAccessed < this.numTablesMetricsHistBreakpoints[i + 1]) {
                        break;
                    }
                }
                if (this.numTablesMetricsHistBreakpoints[18] < this.maximumNumberTablesAccessed) {
                    logMessage.append("\n\tbetween ");
                    logMessage.append(this.numTablesMetricsHistBreakpoints[18]);
                    logMessage.append(" and ");
                    logMessage.append(this.numTablesMetricsHistBreakpoints[19]);
                    logMessage.append(" tables: ");
                    logMessage.append(this.numTablesMetricsHistCounts[19]);
                }
            }
            this.log.logInfo(logMessage);
            this.metricsLastReportedMs = System.currentTimeMillis();
        }
    }
    
    private void reportMetricsIfNeeded() {
        if (this.getGatherPerformanceMetrics() && System.currentTimeMillis() - this.metricsLastReportedMs > this.getReportMetricsIntervalMillis()) {
            this.reportMetrics();
        }
    }
    
    protected void reportNumberOfTablesAccessed(final int numTablesAccessed) {
        if (numTablesAccessed < this.minimumNumberTablesAccessed) {
            this.minimumNumberTablesAccessed = numTablesAccessed;
        }
        if (numTablesAccessed > this.maximumNumberTablesAccessed) {
            this.maximumNumberTablesAccessed = numTablesAccessed;
            this.repartitionTablesAccessedHistogram();
        }
        this.addToTablesAccessedHistogram(numTablesAccessed, 1);
    }
    
    public void resetServerState() throws SQLException {
        if (!this.getParanoid() && this.io != null && this.versionMeetsMinimum(4, 0, 6)) {
            this.changeUser(this.user, this.password);
        }
    }
    
    public void rollback() throws SQLException {
        synchronized (this.getMutex()) {
            this.checkClosed();
            try {
                if (this.autoCommit && !this.getRelaxAutoCommit()) {
                    throw SQLError.createSQLException("Can't call rollback when autocommit=true", "08003");
                }
                if (this.transactionsSupported) {
                    try {
                        this.rollbackNoChecks();
                    }
                    catch (SQLException sqlEx) {
                        if (this.getIgnoreNonTxTables() && sqlEx.getErrorCode() != 1196) {
                            throw sqlEx;
                        }
                    }
                }
            }
            catch (SQLException sqlException) {
                if ("08S01".equals(sqlException.getSQLState())) {
                    throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007");
                }
                throw sqlException;
            }
            finally {
                this.needsPing = this.getReconnectAtTxEnd();
            }
        }
    }
    
    public void rollback(final Savepoint savepoint) throws SQLException {
        if (this.versionMeetsMinimum(4, 0, 14) || this.versionMeetsMinimum(4, 1, 1)) {
            synchronized (this.getMutex()) {
                this.checkClosed();
                try {
                    final StringBuffer rollbackQuery = new StringBuffer("ROLLBACK TO SAVEPOINT ");
                    rollbackQuery.append('`');
                    rollbackQuery.append(savepoint.getSavepointName());
                    rollbackQuery.append('`');
                    java.sql.Statement stmt = null;
                    try {
                        stmt = this.createStatement();
                        stmt.executeUpdate(rollbackQuery.toString());
                    }
                    catch (SQLException sqlEx) {
                        final int errno = sqlEx.getErrorCode();
                        if (errno == 1181) {
                            final String msg = sqlEx.getMessage();
                            if (msg != null) {
                                final int indexOfError153 = msg.indexOf("153");
                                if (indexOfError153 != -1) {
                                    throw SQLError.createSQLException("Savepoint '" + savepoint.getSavepointName() + "' does not exist", "S1009", errno);
                                }
                            }
                        }
                        if (this.getIgnoreNonTxTables() && sqlEx.getErrorCode() != 1196) {
                            throw sqlEx;
                        }
                        if ("08S01".equals(sqlEx.getSQLState())) {
                            throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007");
                        }
                        throw sqlEx;
                    }
                    finally {
                        this.closeStatement(stmt);
                    }
                }
                finally {
                    this.needsPing = this.getReconnectAtTxEnd();
                }
                return;
            }
            throw new NotImplemented();
        }
        throw new NotImplemented();
    }
    
    private void rollbackNoChecks() throws SQLException {
        if (this.getUseLocalSessionState() && this.versionMeetsMinimum(5, 0, 0) && !this.io.inTransactionOnServer()) {
            return;
        }
        this.execSQL(null, "rollback", -1, null, 1003, 1007, false, this.database, true, false);
    }
    
    public ServerPreparedStatement serverPrepare(final String sql) throws SQLException {
        final String nativeSql = this.getProcessEscapeCodesForPrepStmts() ? this.nativeSQL(sql) : sql;
        return new ServerPreparedStatement(this, nativeSql, this.getCatalog(), 1005, 1007);
    }
    
    protected boolean serverSupportsConvertFn() throws SQLException {
        return this.versionMeetsMinimum(4, 0, 2);
    }
    
    public void setAutoCommit(final boolean autoCommitFlag) throws SQLException {
        synchronized (this.getMutex()) {
            this.checkClosed();
            if (this.getAutoReconnectForPools()) {
                this.setHighAvailability(true);
            }
            try {
                if (this.transactionsSupported) {
                    boolean needsSetOnServer = true;
                    if (this.getUseLocalSessionState() && this.autoCommit == autoCommitFlag) {
                        needsSetOnServer = false;
                    }
                    else if (!this.getHighAvailability()) {
                        needsSetOnServer = this.getIO().isSetNeededForAutoCommitMode(autoCommitFlag);
                    }
                    this.autoCommit = autoCommitFlag;
                    if (needsSetOnServer) {
                        this.execSQL(null, autoCommitFlag ? "SET autocommit=1" : "SET autocommit=0", -1, null, 1003, 1007, false, this.database, true, false);
                    }
                }
                else {
                    if (!autoCommitFlag && !this.getRelaxAutoCommit()) {
                        throw SQLError.createSQLException("MySQL Versions Older than 3.23.15 do not support transactions", "08003");
                    }
                    this.autoCommit = autoCommitFlag;
                }
            }
            finally {
                if (this.getAutoReconnectForPools()) {
                    this.setHighAvailability(false);
                }
            }
        }
    }
    
    public void setCatalog(final String catalog) throws SQLException {
        synchronized (this.getMutex()) {
            this.checkClosed();
            if (catalog == null) {
                throw SQLError.createSQLException("Catalog can not be null", "S1009");
            }
            if (this.getUseLocalSessionState()) {
                if (this.lowerCaseTableNames) {
                    if (this.database.equalsIgnoreCase(catalog)) {
                        return;
                    }
                }
                else if (this.database.equals(catalog)) {
                    return;
                }
            }
            String quotedId = this.dbmd.getIdentifierQuoteString();
            if (quotedId == null || quotedId.equals(" ")) {
                quotedId = "";
            }
            final StringBuffer query = new StringBuffer("USE ");
            query.append(quotedId);
            query.append(catalog);
            query.append(quotedId);
            this.execSQL(null, query.toString(), -1, null, 1003, 1007, false, this.database, true, false);
            this.database = catalog;
        }
    }
    
    public synchronized void setFailedOver(final boolean flag) {
        this.failedOver = flag;
    }
    
    private void setFailedOverState() throws SQLException {
        if (this.getFailOverReadOnly()) {
            this.setReadOnlyInternal(true);
        }
        this.queriesIssuedFailedOver = 0L;
        this.failedOver = true;
        this.masterFailTimeMillis = System.currentTimeMillis();
    }
    
    public void setHoldability(final int arg0) throws SQLException {
    }
    
    public void setInGlobalTx(final boolean flag) {
        this.isInGlobalTx = flag;
    }
    
    public void setPreferSlaveDuringFailover(final boolean flag) {
        this.preferSlaveDuringFailover = flag;
    }
    
    void setReadInfoMsgEnabled(final boolean flag) {
        this.readInfoMsg = flag;
    }
    
    public void setReadOnly(final boolean readOnlyFlag) throws SQLException {
        this.checkClosed();
        if (this.failedOver && this.getFailOverReadOnly() && !readOnlyFlag) {
            return;
        }
        this.setReadOnlyInternal(readOnlyFlag);
    }
    
    protected void setReadOnlyInternal(final boolean readOnlyFlag) throws SQLException {
        this.readOnly = readOnlyFlag;
    }
    
    public Savepoint setSavepoint() throws SQLException {
        final MysqlSavepoint savepoint = new MysqlSavepoint();
        this.setSavepoint(savepoint);
        return savepoint;
    }
    
    private void setSavepoint(final MysqlSavepoint savepoint) throws SQLException {
        if (this.versionMeetsMinimum(4, 0, 14) || this.versionMeetsMinimum(4, 1, 1)) {
            synchronized (this.getMutex()) {
                this.checkClosed();
                final StringBuffer savePointQuery = new StringBuffer("SAVEPOINT ");
                savePointQuery.append('`');
                savePointQuery.append(savepoint.getSavepointName());
                savePointQuery.append('`');
                java.sql.Statement stmt = null;
                try {
                    stmt = this.createStatement();
                    stmt.executeUpdate(savePointQuery.toString());
                }
                finally {
                    this.closeStatement(stmt);
                }
                return;
            }
            throw new NotImplemented();
        }
        throw new NotImplemented();
    }
    
    public synchronized Savepoint setSavepoint(final String name) throws SQLException {
        final MysqlSavepoint savepoint = new MysqlSavepoint(name);
        this.setSavepoint(savepoint);
        return savepoint;
    }
    
    private void setSessionVariables() throws SQLException {
        if (this.versionMeetsMinimum(4, 0, 0) && this.getSessionVariables() != null) {
            final List variablesToSet = StringUtils.split(this.getSessionVariables(), ",", "\"'", "\"'", false);
            final int numVariablesToSet = variablesToSet.size();
            java.sql.Statement stmt = null;
            try {
                stmt = this.getMetadataSafeStatement();
                for (int i = 0; i < numVariablesToSet; ++i) {
                    final String variableValuePair = variablesToSet.get(i);
                    if (variableValuePair.startsWith("@")) {
                        stmt.executeUpdate("SET " + variableValuePair);
                    }
                    else {
                        stmt.executeUpdate("SET SESSION " + variableValuePair);
                    }
                }
            }
            finally {
                if (stmt != null) {
                    stmt.close();
                }
            }
        }
    }
    
    public synchronized void setTransactionIsolation(final int level) throws SQLException {
        this.checkClosed();
        if (this.hasIsolationLevels) {
            String sql = null;
            boolean shouldSendSet = false;
            if (this.getAlwaysSendSetIsolation()) {
                shouldSendSet = true;
            }
            else if (level != this.isolationLevel) {
                shouldSendSet = true;
            }
            if (this.getUseLocalSessionState()) {
                shouldSendSet = (this.isolationLevel != level);
            }
            if (shouldSendSet) {
                switch (level) {
                    case 0: {
                        throw SQLError.createSQLException("Transaction isolation level NONE not supported by MySQL");
                    }
                    case 2: {
                        sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED";
                        break;
                    }
                    case 1: {
                        sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED";
                        break;
                    }
                    case 4: {
                        sql = "SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ";
                        break;
                    }
                    case 8: {
                        sql = "SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE";
                        break;
                    }
                    default: {
                        throw SQLError.createSQLException("Unsupported transaction isolation level '" + level + "'", "S1C00");
                    }
                }
                this.execSQL(null, sql, -1, null, 1003, 1007, false, this.database, true, false);
                this.isolationLevel = level;
            }
            return;
        }
        throw SQLError.createSQLException("Transaction Isolation Levels are not supported on MySQL versions older than 3.23.36.", "S1C00");
    }
    
    public synchronized void setTypeMap(final Map map) throws SQLException {
        this.typeMap = map;
    }
    
    private boolean shouldFallBack() {
        final long secondsSinceFailedOver = (System.currentTimeMillis() - this.masterFailTimeMillis) / 1000L;
        final boolean tryFallback = secondsSinceFailedOver >= this.getSecondsBeforeRetryMaster() || this.queriesIssuedFailedOver >= this.getQueriesBeforeRetryMaster();
        return tryFallback;
    }
    
    public void shutdownServer() throws SQLException {
        try {
            this.io.sendCommand(8, null, null, false, null);
        }
        catch (Exception ex) {
            throw SQLError.createSQLException("Unhandled exception '" + ex.toString() + "'", "S1000");
        }
    }
    
    public boolean supportsIsolationLevel() {
        return this.hasIsolationLevels;
    }
    
    public boolean supportsQuotedIdentifiers() {
        return this.hasQuotedIdentifiers;
    }
    
    public boolean supportsTransactions() {
        return this.transactionsSupported;
    }
    
    void unregisterStatement(final Statement stmt) {
        if (this.openStatements != null) {
            synchronized (this.openStatements) {
                this.openStatements.remove(stmt);
            }
        }
    }
    
    void unsetMaxRows(final Statement stmt) throws SQLException {
        synchronized (this.mutex) {
            if (this.statementsUsingMaxRows != null) {
                final Object found = this.statementsUsingMaxRows.remove(stmt);
                if (found != null && this.statementsUsingMaxRows.size() == 0) {
                    this.execSQL(null, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.database, true, false);
                    this.maxRowsChanged = false;
                }
            }
        }
    }
    
    boolean useAnsiQuotedIdentifiers() {
        return this.useAnsiQuotes;
    }
    
    boolean useMaxRows() {
        synchronized (this.mutex) {
            return this.maxRowsChanged;
        }
    }
    
    public boolean versionMeetsMinimum(final int major, final int minor, final int subminor) throws SQLException {
        this.checkClosed();
        return this.io.versionMeetsMinimum(major, minor, subminor);
    }
    
    protected String getErrorMessageEncoding() {
        return this.errorMessageEncoding;
    }
    
    public void clearHasTriedMaster() {
        this.hasTriedMasterFlag = false;
    }
    
    public boolean hasTriedMaster() {
        return this.hasTriedMasterFlag;
    }
    
    protected CachedResultSetMetaData getCachedMetaData(final String sql) {
        if (this.resultSetMetadataCache != null) {
            synchronized (this.resultSetMetadataCache) {
                return this.resultSetMetadataCache.get(sql);
            }
        }
        return null;
    }
    
    protected void initializeResultsMetadataFromCache(final String sql, CachedResultSetMetaData cachedMetaData, final ResultSet resultSet) throws SQLException {
        if (cachedMetaData == null) {
            cachedMetaData = new CachedResultSetMetaData();
            cachedMetaData.fields = resultSet.fields;
            resultSet.buildIndexMapping();
            resultSet.initializeWithMetadata();
            if (resultSet instanceof UpdatableResultSet) {
                ((UpdatableResultSet)resultSet).checkUpdatability();
            }
            cachedMetaData.columnNameToIndex = resultSet.columnNameToIndex;
            cachedMetaData.fullColumnNameToIndex = resultSet.fullColumnNameToIndex;
            cachedMetaData.metadata = resultSet.getMetaData();
            this.resultSetMetadataCache.put(sql, cachedMetaData);
        }
        else {
            resultSet.fields = cachedMetaData.fields;
            resultSet.columnNameToIndex = cachedMetaData.columnNameToIndex;
            resultSet.fullColumnNameToIndex = cachedMetaData.fullColumnNameToIndex;
            resultSet.hasBuiltIndexMapping = true;
            resultSet.initializeWithMetadata();
            if (resultSet instanceof UpdatableResultSet) {
                ((UpdatableResultSet)resultSet).checkUpdatability();
            }
        }
    }
    
    static {
        CHARSET_CONVERTER_NOT_AVAILABLE_MARKER = new Object();
        Connection.mapTransIsolationNameToValue = null;
        NULL_LOGGER = new NullLogger("MySQL");
        serverCollationByUrl = new HashMap();
        serverConfigByUrl = new HashMap();
        (Connection.mapTransIsolationNameToValue = new HashMap(8)).put("READ-UNCOMMITED", new Integer(1));
        Connection.mapTransIsolationNameToValue.put("READ-UNCOMMITTED", new Integer(1));
        Connection.mapTransIsolationNameToValue.put("READ-COMMITTED", new Integer(2));
        Connection.mapTransIsolationNameToValue.put("REPEATABLE-READ", new Integer(4));
        Connection.mapTransIsolationNameToValue.put("SERIALIZABLE", new Integer(8));
        boolean createdNamedTimer = false;
        try {
            final Constructor ctr = Timer.class.getConstructor(String.class, Boolean.TYPE);
            Connection.cancelTimer = ctr.newInstance("MySQL Statement Cancellation Timer", Boolean.TRUE);
            createdNamedTimer = true;
        }
        catch (Throwable t) {
            createdNamedTimer = false;
        }
        if (!createdNamedTimer) {
            Connection.cancelTimer = new Timer(true);
        }
    }
    
    class CompoundCacheKey
    {
        String componentOne;
        String componentTwo;
        int hashCode;
        
        CompoundCacheKey(final String partOne, final String partTwo) {
            this.componentOne = partOne;
            this.componentTwo = partTwo;
            this.hashCode = (((this.componentOne != null) ? this.componentOne : "") + this.componentTwo).hashCode();
        }
        
        public boolean equals(final Object obj) {
            if (obj instanceof CompoundCacheKey) {
                final CompoundCacheKey another = (CompoundCacheKey)obj;
                boolean firstPartEqual = false;
                if (this.componentOne == null) {
                    firstPartEqual = (another.componentOne == null);
                }
                else {
                    firstPartEqual = this.componentOne.equals(another.componentOne);
                }
                return firstPartEqual && this.componentTwo.equals(another.componentTwo);
            }
            return false;
        }
        
        public int hashCode() {
            return this.hashCode;
        }
    }
    
    class UltraDevWorkAround implements CallableStatement
    {
        private PreparedStatement delegate;
        
        UltraDevWorkAround(final PreparedStatement pstmt) {
            this.delegate = null;
            this.delegate = pstmt;
        }
        
        public void addBatch() throws SQLException {
            this.delegate.addBatch();
        }
        
        public void addBatch(final String p1) throws SQLException {
            this.delegate.addBatch(p1);
        }
        
        public void cancel() throws SQLException {
            this.delegate.cancel();
        }
        
        public void clearBatch() throws SQLException {
            this.delegate.clearBatch();
        }
        
        public void clearParameters() throws SQLException {
            this.delegate.clearParameters();
        }
        
        public void clearWarnings() throws SQLException {
            this.delegate.clearWarnings();
        }
        
        public void close() throws SQLException {
            this.delegate.close();
        }
        
        public boolean execute() throws SQLException {
            return this.delegate.execute();
        }
        
        public boolean execute(final String p1) throws SQLException {
            return this.delegate.execute(p1);
        }
        
        public boolean execute(final String arg0, final int arg1) throws SQLException {
            return this.delegate.execute(arg0, arg1);
        }
        
        public boolean execute(final String arg0, final int[] arg1) throws SQLException {
            return this.delegate.execute(arg0, arg1);
        }
        
        public boolean execute(final String arg0, final String[] arg1) throws SQLException {
            return this.delegate.execute(arg0, arg1);
        }
        
        public int[] executeBatch() throws SQLException {
            return this.delegate.executeBatch();
        }
        
        public java.sql.ResultSet executeQuery() throws SQLException {
            return this.delegate.executeQuery();
        }
        
        public java.sql.ResultSet executeQuery(final String p1) throws SQLException {
            return this.delegate.executeQuery(p1);
        }
        
        public int executeUpdate() throws SQLException {
            return this.delegate.executeUpdate();
        }
        
        public int executeUpdate(final String p1) throws SQLException {
            return this.delegate.executeUpdate(p1);
        }
        
        public int executeUpdate(final String arg0, final int arg1) throws SQLException {
            return this.delegate.executeUpdate(arg0, arg1);
        }
        
        public int executeUpdate(final String arg0, final int[] arg1) throws SQLException {
            return this.delegate.executeUpdate(arg0, arg1);
        }
        
        public int executeUpdate(final String arg0, final String[] arg1) throws SQLException {
            return this.delegate.executeUpdate(arg0, arg1);
        }
        
        public java.sql.Array getArray(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public java.sql.Array getArray(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public BigDecimal getBigDecimal(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public BigDecimal getBigDecimal(final int p1, final int p2) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public BigDecimal getBigDecimal(final String arg0) throws SQLException {
            return null;
        }
        
        public Blob getBlob(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Blob getBlob(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public boolean getBoolean(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public boolean getBoolean(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public byte getByte(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public byte getByte(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public byte[] getBytes(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public byte[] getBytes(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public Clob getClob(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Clob getClob(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public java.sql.Connection getConnection() throws SQLException {
            return this.delegate.getConnection();
        }
        
        public Date getDate(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Date getDate(final int p1, final Calendar p2) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Date getDate(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public Date getDate(final String arg0, final Calendar arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public double getDouble(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public double getDouble(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public int getFetchDirection() throws SQLException {
            return this.delegate.getFetchDirection();
        }
        
        public int getFetchSize() throws SQLException {
            return this.delegate.getFetchSize();
        }
        
        public float getFloat(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public float getFloat(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public java.sql.ResultSet getGeneratedKeys() throws SQLException {
            return this.delegate.getGeneratedKeys();
        }
        
        public int getInt(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public int getInt(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public long getLong(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public long getLong(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public int getMaxFieldSize() throws SQLException {
            return this.delegate.getMaxFieldSize();
        }
        
        public int getMaxRows() throws SQLException {
            return this.delegate.getMaxRows();
        }
        
        public ResultSetMetaData getMetaData() throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public boolean getMoreResults() throws SQLException {
            return this.delegate.getMoreResults();
        }
        
        public boolean getMoreResults(final int arg0) throws SQLException {
            return this.delegate.getMoreResults();
        }
        
        public Object getObject(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Object getObject(final int p1, final Map p2) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Object getObject(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public Object getObject(final String arg0, final Map arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public ParameterMetaData getParameterMetaData() throws SQLException {
            return this.delegate.getParameterMetaData();
        }
        
        public int getQueryTimeout() throws SQLException {
            return this.delegate.getQueryTimeout();
        }
        
        public Ref getRef(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Ref getRef(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public java.sql.ResultSet getResultSet() throws SQLException {
            return this.delegate.getResultSet();
        }
        
        public int getResultSetConcurrency() throws SQLException {
            return this.delegate.getResultSetConcurrency();
        }
        
        public int getResultSetHoldability() throws SQLException {
            return this.delegate.getResultSetHoldability();
        }
        
        public int getResultSetType() throws SQLException {
            return this.delegate.getResultSetType();
        }
        
        public short getShort(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public short getShort(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public String getString(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public String getString(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public Time getTime(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Time getTime(final int p1, final Calendar p2) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Time getTime(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public Time getTime(final String arg0, final Calendar arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public Timestamp getTimestamp(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Timestamp getTimestamp(final int p1, final Calendar p2) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public Timestamp getTimestamp(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public Timestamp getTimestamp(final String arg0, final Calendar arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public int getUpdateCount() throws SQLException {
            return this.delegate.getUpdateCount();
        }
        
        public URL getURL(final int arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public URL getURL(final String arg0) throws SQLException {
            throw new NotImplemented();
        }
        
        public SQLWarning getWarnings() throws SQLException {
            return this.delegate.getWarnings();
        }
        
        public void registerOutParameter(final int p1, final int p2) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public void registerOutParameter(final int p1, final int p2, final int p3) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public void registerOutParameter(final int p1, final int p2, final String p3) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public void registerOutParameter(final String arg0, final int arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void registerOutParameter(final String arg0, final int arg1, final int arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void registerOutParameter(final String arg0, final int arg1, final String arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setArray(final int p1, final java.sql.Array p2) throws SQLException {
            this.delegate.setArray(p1, p2);
        }
        
        public void setAsciiStream(final int p1, final InputStream p2, final int p3) throws SQLException {
            this.delegate.setAsciiStream(p1, p2, p3);
        }
        
        public void setAsciiStream(final String arg0, final InputStream arg1, final int arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setBigDecimal(final int p1, final BigDecimal p2) throws SQLException {
            this.delegate.setBigDecimal(p1, p2);
        }
        
        public void setBigDecimal(final String arg0, final BigDecimal arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setBinaryStream(final int p1, final InputStream p2, final int p3) throws SQLException {
            this.delegate.setBinaryStream(p1, p2, p3);
        }
        
        public void setBinaryStream(final String arg0, final InputStream arg1, final int arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setBlob(final int p1, final Blob p2) throws SQLException {
            this.delegate.setBlob(p1, p2);
        }
        
        public void setBoolean(final int p1, final boolean p2) throws SQLException {
            this.delegate.setBoolean(p1, p2);
        }
        
        public void setBoolean(final String arg0, final boolean arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setByte(final int p1, final byte p2) throws SQLException {
            this.delegate.setByte(p1, p2);
        }
        
        public void setByte(final String arg0, final byte arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setBytes(final int p1, final byte[] p2) throws SQLException {
            this.delegate.setBytes(p1, p2);
        }
        
        public void setBytes(final String arg0, final byte[] arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setCharacterStream(final int p1, final Reader p2, final int p3) throws SQLException {
            this.delegate.setCharacterStream(p1, p2, p3);
        }
        
        public void setCharacterStream(final String arg0, final Reader arg1, final int arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setClob(final int p1, final Clob p2) throws SQLException {
            this.delegate.setClob(p1, p2);
        }
        
        public void setCursorName(final String p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public void setDate(final int p1, final Date p2) throws SQLException {
            this.delegate.setDate(p1, p2);
        }
        
        public void setDate(final int p1, final Date p2, final Calendar p3) throws SQLException {
            this.delegate.setDate(p1, p2, p3);
        }
        
        public void setDate(final String arg0, final Date arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setDate(final String arg0, final Date arg1, final Calendar arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setDouble(final int p1, final double p2) throws SQLException {
            this.delegate.setDouble(p1, p2);
        }
        
        public void setDouble(final String arg0, final double arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setEscapeProcessing(final boolean p1) throws SQLException {
            this.delegate.setEscapeProcessing(p1);
        }
        
        public void setFetchDirection(final int p1) throws SQLException {
            this.delegate.setFetchDirection(p1);
        }
        
        public void setFetchSize(final int p1) throws SQLException {
            this.delegate.setFetchSize(p1);
        }
        
        public void setFloat(final int p1, final float p2) throws SQLException {
            this.delegate.setFloat(p1, p2);
        }
        
        public void setFloat(final String arg0, final float arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setInt(final int p1, final int p2) throws SQLException {
            this.delegate.setInt(p1, p2);
        }
        
        public void setInt(final String arg0, final int arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setLong(final int p1, final long p2) throws SQLException {
            this.delegate.setLong(p1, p2);
        }
        
        public void setLong(final String arg0, final long arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setMaxFieldSize(final int p1) throws SQLException {
            this.delegate.setMaxFieldSize(p1);
        }
        
        public void setMaxRows(final int p1) throws SQLException {
            this.delegate.setMaxRows(p1);
        }
        
        public void setNull(final int p1, final int p2) throws SQLException {
            this.delegate.setNull(p1, p2);
        }
        
        public void setNull(final int p1, final int p2, final String p3) throws SQLException {
            this.delegate.setNull(p1, p2, p3);
        }
        
        public void setNull(final String arg0, final int arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setNull(final String arg0, final int arg1, final String arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setObject(final int p1, final Object p2) throws SQLException {
            this.delegate.setObject(p1, p2);
        }
        
        public void setObject(final int p1, final Object p2, final int p3) throws SQLException {
            this.delegate.setObject(p1, p2, p3);
        }
        
        public void setObject(final int p1, final Object p2, final int p3, final int p4) throws SQLException {
            this.delegate.setObject(p1, p2, p3, p4);
        }
        
        public void setObject(final String arg0, final Object arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setObject(final String arg0, final Object arg1, final int arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setObject(final String arg0, final Object arg1, final int arg2, final int arg3) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setQueryTimeout(final int p1) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public void setRef(final int p1, final Ref p2) throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
        
        public void setShort(final int p1, final short p2) throws SQLException {
            this.delegate.setShort(p1, p2);
        }
        
        public void setShort(final String arg0, final short arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setString(final int p1, final String p2) throws SQLException {
            this.delegate.setString(p1, p2);
        }
        
        public void setString(final String arg0, final String arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setTime(final int p1, final Time p2) throws SQLException {
            this.delegate.setTime(p1, p2);
        }
        
        public void setTime(final int p1, final Time p2, final Calendar p3) throws SQLException {
            this.delegate.setTime(p1, p2, p3);
        }
        
        public void setTime(final String arg0, final Time arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setTime(final String arg0, final Time arg1, final Calendar arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setTimestamp(final int p1, final Timestamp p2) throws SQLException {
            this.delegate.setTimestamp(p1, p2);
        }
        
        public void setTimestamp(final int p1, final Timestamp p2, final Calendar p3) throws SQLException {
            this.delegate.setTimestamp(p1, p2, p3);
        }
        
        public void setTimestamp(final String arg0, final Timestamp arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setTimestamp(final String arg0, final Timestamp arg1, final Calendar arg2) throws SQLException {
            throw new NotImplemented();
        }
        
        public void setUnicodeStream(final int p1, final InputStream p2, final int p3) throws SQLException {
            this.delegate.setUnicodeStream(p1, p2, p3);
        }
        
        public void setURL(final int arg0, final URL arg1) throws SQLException {
            this.delegate.setURL(arg0, arg1);
        }
        
        public void setURL(final String arg0, final URL arg1) throws SQLException {
            throw new NotImplemented();
        }
        
        public boolean wasNull() throws SQLException {
            throw SQLError.createSQLException("Not supported");
        }
    }
}
