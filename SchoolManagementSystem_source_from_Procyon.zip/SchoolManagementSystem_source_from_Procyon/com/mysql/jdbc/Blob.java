// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class Blob implements java.sql.Blob, OutputStreamWatcher
{
    private byte[] binaryData;
    
    Blob(final byte[] data) {
        this.binaryData = null;
        this.setBinaryData(data);
    }
    
    Blob(final byte[] data, final ResultSet creatorResultSetToSet, final int columnIndexToSet) {
        this.binaryData = null;
        this.setBinaryData(data);
    }
    
    private byte[] getBinaryData() {
        return this.binaryData;
    }
    
    public InputStream getBinaryStream() throws SQLException {
        return new ByteArrayInputStream(this.getBinaryData());
    }
    
    public byte[] getBytes(final long pos, final int length) throws SQLException {
        if (pos < 1L) {
            throw SQLError.createSQLException(Messages.getString("Blob.2"), "S1009");
        }
        final byte[] newData = new byte[length];
        System.arraycopy(this.getBinaryData(), (int)(pos - 1L), newData, 0, length);
        return newData;
    }
    
    public long length() throws SQLException {
        return this.getBinaryData().length;
    }
    
    public long position(final byte[] pattern, final long start) throws SQLException {
        throw SQLError.createSQLException("Not implemented");
    }
    
    public long position(final java.sql.Blob pattern, final long start) throws SQLException {
        return this.position(pattern.getBytes(0L, (int)pattern.length()), start);
    }
    
    private void setBinaryData(final byte[] newBinaryData) {
        this.binaryData = newBinaryData;
    }
    
    public OutputStream setBinaryStream(final long indexToWriteAt) throws SQLException {
        if (indexToWriteAt < 1L) {
            throw SQLError.createSQLException(Messages.getString("Blob.0"), "S1009");
        }
        final WatchableOutputStream bytesOut = new WatchableOutputStream();
        bytesOut.setWatcher(this);
        if (indexToWriteAt > 0L) {
            bytesOut.write(this.binaryData, 0, (int)(indexToWriteAt - 1L));
        }
        return bytesOut;
    }
    
    public int setBytes(final long writeAt, final byte[] bytes) throws SQLException {
        return this.setBytes(writeAt, bytes, 0, bytes.length);
    }
    
    public int setBytes(final long writeAt, final byte[] bytes, final int offset, final int length) throws SQLException {
        final OutputStream bytesOut = this.setBinaryStream(writeAt);
        try {
            bytesOut.write(bytes, offset, length);
        }
        catch (IOException ioEx) {
            throw SQLError.createSQLException(Messages.getString("Blob.1"), "S1000");
        }
        finally {
            try {
                bytesOut.close();
            }
            catch (IOException ex) {}
        }
        return length;
    }
    
    public void streamClosed(final byte[] byteData) {
        this.binaryData = byteData;
    }
    
    public void streamClosed(final WatchableOutputStream out) {
        final int streamSize = out.size();
        if (streamSize < this.binaryData.length) {
            out.write(this.binaryData, streamSize, this.binaryData.length - streamSize);
        }
        this.binaryData = out.toByteArray();
    }
    
    public void truncate(final long arg0) throws SQLException {
        throw new NotImplemented();
    }
}
