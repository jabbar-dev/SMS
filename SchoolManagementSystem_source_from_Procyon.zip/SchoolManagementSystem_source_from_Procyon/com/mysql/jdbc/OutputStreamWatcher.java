// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

interface OutputStreamWatcher
{
    void streamClosed(final WatchableOutputStream p0);
}
