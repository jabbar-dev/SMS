// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

class Constants
{
    public static final byte[] EMPTY_BYTE_ARRAY;
    public static final String MILLIS_I18N;
    
    private Constants() {
    }
    
    static {
        EMPTY_BYTE_ARRAY = new byte[0];
        MILLIS_I18N = Messages.getString("Milliseconds");
    }
}
