// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.sql.Savepoint;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.SQLWarning;
import java.util.Map;
import java.sql.DatabaseMetaData;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.Properties;
import java.sql.Connection;

public class ReplicationConnection implements Connection, PingTarget
{
    private com.mysql.jdbc.Connection currentConnection;
    private com.mysql.jdbc.Connection masterConnection;
    private com.mysql.jdbc.Connection slavesConnection;
    
    public ReplicationConnection(final Properties masterProperties, final Properties slaveProperties) throws SQLException {
        final Driver driver = new Driver();
        final StringBuffer masterUrl = new StringBuffer("jdbc:mysql://");
        final StringBuffer slaveUrl = new StringBuffer("jdbc:mysql://");
        final String masterHost = masterProperties.getProperty("HOST");
        if (masterHost != null) {
            masterUrl.append(masterHost);
        }
        final String slaveHost = slaveProperties.getProperty("HOST");
        if (slaveHost != null) {
            slaveUrl.append(slaveHost);
        }
        final String masterDb = masterProperties.getProperty("DBNAME");
        masterUrl.append("/");
        if (masterDb != null) {
            masterUrl.append(masterDb);
        }
        final String slaveDb = slaveProperties.getProperty("DBNAME");
        slaveUrl.append("/");
        if (slaveDb != null) {
            slaveUrl.append(slaveDb);
        }
        this.masterConnection = (com.mysql.jdbc.Connection)driver.connect(masterUrl.toString(), masterProperties);
        this.slavesConnection = (com.mysql.jdbc.Connection)driver.connect(slaveUrl.toString(), slaveProperties);
        this.currentConnection = this.masterConnection;
    }
    
    public synchronized void clearWarnings() throws SQLException {
        this.currentConnection.clearWarnings();
    }
    
    public synchronized void close() throws SQLException {
        this.masterConnection.close();
        this.slavesConnection.close();
    }
    
    public synchronized void commit() throws SQLException {
        this.currentConnection.commit();
    }
    
    public Statement createStatement() throws SQLException {
        final Statement stmt = this.currentConnection.createStatement();
        ((com.mysql.jdbc.Statement)stmt).setPingTarget(this);
        return stmt;
    }
    
    public synchronized Statement createStatement(final int resultSetType, final int resultSetConcurrency) throws SQLException {
        final Statement stmt = this.currentConnection.createStatement(resultSetType, resultSetConcurrency);
        ((com.mysql.jdbc.Statement)stmt).setPingTarget(this);
        return stmt;
    }
    
    public synchronized Statement createStatement(final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        final Statement stmt = this.currentConnection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
        ((com.mysql.jdbc.Statement)stmt).setPingTarget(this);
        return stmt;
    }
    
    public synchronized boolean getAutoCommit() throws SQLException {
        return this.currentConnection.getAutoCommit();
    }
    
    public synchronized String getCatalog() throws SQLException {
        return this.currentConnection.getCatalog();
    }
    
    public synchronized com.mysql.jdbc.Connection getCurrentConnection() {
        return this.currentConnection;
    }
    
    public synchronized int getHoldability() throws SQLException {
        return this.currentConnection.getHoldability();
    }
    
    public synchronized com.mysql.jdbc.Connection getMasterConnection() {
        return this.masterConnection;
    }
    
    public synchronized DatabaseMetaData getMetaData() throws SQLException {
        return this.currentConnection.getMetaData();
    }
    
    public synchronized com.mysql.jdbc.Connection getSlavesConnection() {
        return this.slavesConnection;
    }
    
    public synchronized int getTransactionIsolation() throws SQLException {
        return this.currentConnection.getTransactionIsolation();
    }
    
    public synchronized Map getTypeMap() throws SQLException {
        return this.currentConnection.getTypeMap();
    }
    
    public synchronized SQLWarning getWarnings() throws SQLException {
        return this.currentConnection.getWarnings();
    }
    
    public synchronized boolean isClosed() throws SQLException {
        return this.currentConnection.isClosed();
    }
    
    public synchronized boolean isReadOnly() throws SQLException {
        return this.currentConnection == this.slavesConnection;
    }
    
    public synchronized String nativeSQL(final String sql) throws SQLException {
        return this.currentConnection.nativeSQL(sql);
    }
    
    public CallableStatement prepareCall(final String sql) throws SQLException {
        return this.currentConnection.prepareCall(sql);
    }
    
    public synchronized CallableStatement prepareCall(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        return this.currentConnection.prepareCall(sql, resultSetType, resultSetConcurrency);
    }
    
    public synchronized CallableStatement prepareCall(final String sql, final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        return this.currentConnection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
    }
    
    public PreparedStatement prepareStatement(final String sql) throws SQLException {
        final PreparedStatement pstmt = this.currentConnection.prepareStatement(sql);
        ((com.mysql.jdbc.Statement)pstmt).setPingTarget(this);
        return pstmt;
    }
    
    public synchronized PreparedStatement prepareStatement(final String sql, final int autoGeneratedKeys) throws SQLException {
        final PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, autoGeneratedKeys);
        ((com.mysql.jdbc.Statement)pstmt).setPingTarget(this);
        return pstmt;
    }
    
    public synchronized PreparedStatement prepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        final PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency);
        ((com.mysql.jdbc.Statement)pstmt).setPingTarget(this);
        return pstmt;
    }
    
    public synchronized PreparedStatement prepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        final PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
        ((com.mysql.jdbc.Statement)pstmt).setPingTarget(this);
        return pstmt;
    }
    
    public synchronized PreparedStatement prepareStatement(final String sql, final int[] columnIndexes) throws SQLException {
        final PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, columnIndexes);
        ((com.mysql.jdbc.Statement)pstmt).setPingTarget(this);
        return pstmt;
    }
    
    public synchronized PreparedStatement prepareStatement(final String sql, final String[] columnNames) throws SQLException {
        final PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, columnNames);
        ((com.mysql.jdbc.Statement)pstmt).setPingTarget(this);
        return pstmt;
    }
    
    public synchronized void releaseSavepoint(final Savepoint savepoint) throws SQLException {
        this.currentConnection.releaseSavepoint(savepoint);
    }
    
    public synchronized void rollback() throws SQLException {
        this.currentConnection.rollback();
    }
    
    public synchronized void rollback(final Savepoint savepoint) throws SQLException {
        this.currentConnection.rollback(savepoint);
    }
    
    public synchronized void setAutoCommit(final boolean autoCommit) throws SQLException {
        this.currentConnection.setAutoCommit(autoCommit);
    }
    
    public synchronized void setCatalog(final String catalog) throws SQLException {
        this.currentConnection.setCatalog(catalog);
    }
    
    public synchronized void setHoldability(final int holdability) throws SQLException {
        this.currentConnection.setHoldability(holdability);
    }
    
    public synchronized void setReadOnly(final boolean readOnly) throws SQLException {
        if (readOnly) {
            if (this.currentConnection != this.slavesConnection) {
                this.switchToSlavesConnection();
            }
        }
        else if (this.currentConnection != this.masterConnection) {
            this.switchToMasterConnection();
        }
    }
    
    public synchronized Savepoint setSavepoint() throws SQLException {
        return this.currentConnection.setSavepoint();
    }
    
    public synchronized Savepoint setSavepoint(final String name) throws SQLException {
        return this.currentConnection.setSavepoint(name);
    }
    
    public synchronized void setTransactionIsolation(final int level) throws SQLException {
        this.currentConnection.setTransactionIsolation(level);
    }
    
    public synchronized void setTypeMap(final Map arg0) throws SQLException {
        this.currentConnection.setTypeMap(arg0);
    }
    
    private synchronized void switchToMasterConnection() throws SQLException {
        this.swapConnections(this.masterConnection, this.slavesConnection);
    }
    
    private synchronized void switchToSlavesConnection() throws SQLException {
        this.swapConnections(this.slavesConnection, this.masterConnection);
    }
    
    private synchronized void swapConnections(final com.mysql.jdbc.Connection switchToConnection, final com.mysql.jdbc.Connection switchFromConnection) throws SQLException {
        final String switchFromCatalog = switchFromConnection.getCatalog();
        final String switchToCatalog = switchToConnection.getCatalog();
        if (switchToCatalog != null && !switchToCatalog.equals(switchFromCatalog)) {
            switchToConnection.setCatalog(switchFromCatalog);
        }
        else if (switchFromCatalog != null) {
            switchToConnection.setCatalog(switchFromCatalog);
        }
        final boolean switchToAutoCommit = switchToConnection.getAutoCommit();
        final boolean switchFromConnectionAutoCommit = switchFromConnection.getAutoCommit();
        if (switchFromConnectionAutoCommit != switchToAutoCommit) {
            switchToConnection.setAutoCommit(switchFromConnectionAutoCommit);
        }
        final int switchToIsolation = switchToConnection.getTransactionIsolation();
        final int switchFromIsolation = switchFromConnection.getTransactionIsolation();
        if (switchFromIsolation != switchToIsolation) {
            switchToConnection.setTransactionIsolation(switchFromIsolation);
        }
        this.currentConnection = switchToConnection;
    }
    
    public synchronized void doPing() throws SQLException {
        if (this.masterConnection != null) {
            this.masterConnection.ping();
        }
        if (this.slavesConnection != null) {
            this.slavesConnection.ping();
        }
    }
}
