// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.integration.jboss;

import java.sql.Statement;
import com.mysql.jdbc.jdbc2.optional.ConnectionWrapper;
import com.mysql.jdbc.SQLError;
import java.sql.SQLException;
import java.sql.Connection;
import java.lang.reflect.Method;
import java.io.Serializable;
import org.jboss.resource.adapter.jdbc.ValidConnectionChecker;

public final class MysqlValidConnectionChecker implements ValidConnectionChecker, Serializable
{
    private static final long serialVersionUID = 3258689922776119348L;
    private Method pingMethod;
    private Method pingMethodWrapped;
    private static final Object[] NO_ARGS_OBJECT_ARRAY;
    
    public MysqlValidConnectionChecker() {
        try {
            final Class mysqlConnection = Thread.currentThread().getContextClassLoader().loadClass("com.mysql.jdbc.Connection");
            this.pingMethod = mysqlConnection.getMethod("ping", (Class[])null);
            final Class mysqlConnectionWrapper = Thread.currentThread().getContextClassLoader().loadClass("com.mysql.jdbc.jdbc2.optional.ConnectionWrapper");
            this.pingMethodWrapped = mysqlConnectionWrapper.getMethod("ping", (Class[])null);
        }
        catch (Exception ex) {}
    }
    
    public SQLException isValidConnection(final Connection conn) {
        Label_0130: {
            if (conn instanceof com.mysql.jdbc.Connection) {
                if (this.pingMethod == null) {
                    break Label_0130;
                }
                try {
                    this.pingMethod.invoke(conn, (Object[])null);
                    return null;
                }
                catch (Exception ex) {
                    if (ex instanceof SQLException) {
                        return (SQLException)ex;
                    }
                    return SQLError.createSQLException("Ping failed: " + ex.toString());
                }
            }
            if (conn instanceof ConnectionWrapper && this.pingMethodWrapped != null) {
                try {
                    this.pingMethodWrapped.invoke(conn, (Object[])null);
                    return null;
                }
                catch (Exception ex) {
                    if (ex instanceof SQLException) {
                        return (SQLException)ex;
                    }
                    return SQLError.createSQLException("Ping failed: " + ex.toString());
                }
            }
        }
        Statement pingStatement = null;
        try {
            pingStatement = conn.createStatement();
            pingStatement.executeQuery("SELECT 1").close();
            return null;
        }
        catch (SQLException sqlEx) {
            return sqlEx;
        }
        finally {
            if (pingStatement != null) {
                try {
                    pingStatement.close();
                }
                catch (SQLException ex2) {}
            }
        }
    }
    
    static {
        NO_ARGS_OBJECT_ARRAY = new Object[0];
    }
}
