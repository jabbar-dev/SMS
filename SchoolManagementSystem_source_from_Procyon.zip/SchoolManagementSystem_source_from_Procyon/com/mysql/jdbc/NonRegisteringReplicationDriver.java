// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.util.StringTokenizer;
import java.sql.Connection;
import java.util.Properties;
import java.sql.SQLException;

public class NonRegisteringReplicationDriver extends NonRegisteringDriver
{
    public NonRegisteringReplicationDriver() throws SQLException {
    }
    
    public Connection connect(final String url, final Properties info) throws SQLException {
        final Properties parsedProps = this.parseURL(url, info);
        if (parsedProps == null) {
            return null;
        }
        final Properties masterProps = (Properties)parsedProps.clone();
        final Properties slavesProps = (Properties)parsedProps.clone();
        slavesProps.setProperty("com.mysql.jdbc.ReplicationConnection.isSlave", "true");
        final String hostValues = parsedProps.getProperty("HOST");
        if (hostValues != null) {
            final StringTokenizer st = new StringTokenizer(hostValues, ",");
            final StringBuffer masterHost = new StringBuffer();
            final StringBuffer slaveHosts = new StringBuffer();
            if (st.hasMoreTokens()) {
                final String[] hostPortPair = NonRegisteringDriver.parseHostPortPair(st.nextToken());
                if (hostPortPair[0] != null) {
                    masterHost.append(hostPortPair[0]);
                }
                if (hostPortPair[1] != null) {
                    masterHost.append(":");
                    masterHost.append(hostPortPair[1]);
                }
            }
            boolean firstSlaveHost = true;
            while (st.hasMoreTokens()) {
                final String[] hostPortPair2 = NonRegisteringDriver.parseHostPortPair(st.nextToken());
                if (!firstSlaveHost) {
                    slaveHosts.append(",");
                }
                else {
                    firstSlaveHost = false;
                }
                if (hostPortPair2[0] != null) {
                    slaveHosts.append(hostPortPair2[0]);
                }
                if (hostPortPair2[1] != null) {
                    slaveHosts.append(":");
                    slaveHosts.append(hostPortPair2[1]);
                }
            }
            if (slaveHosts.length() == 0) {
                throw SQLError.createSQLException("Must specify at least one slave host to connect to for master/slave replication load-balancing functionality", "01S00");
            }
            masterProps.setProperty("HOST", masterHost.toString());
            slavesProps.setProperty("HOST", slaveHosts.toString());
        }
        return new ReplicationConnection(masterProps, slavesProps);
    }
}
