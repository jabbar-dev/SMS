// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.net.URL;
import java.util.TimeZone;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.sql.Ref;
import java.text.DateFormat;
import java.text.ParsePosition;
import java.sql.Timestamp;
import java.sql.Time;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Locale;
import java.sql.Date;
import java.sql.Clob;
import java.sql.Blob;
import java.math.BigDecimal;
import java.sql.Array;
import com.mysql.jdbc.profiler.ProfilerEvent;
import java.sql.ParameterMetaData;
import java.io.StringReader;
import com.mysql.jdbc.exceptions.MySQLTimeoutException;
import java.util.TimerTask;
import java.sql.BatchUpdateException;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.sql.SQLException;
import java.io.IOException;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.sql.ResultSetMetaData;
import java.io.InputStream;
import java.sql.DatabaseMetaData;

public class PreparedStatement extends Statement implements java.sql.PreparedStatement
{
    private static final byte[] HEX_DIGITS;
    protected boolean batchHasPlainStatements;
    private DatabaseMetaData dbmd;
    protected char firstCharOfStmt;
    protected boolean hasLimitClause;
    protected boolean isLoadDataQuery;
    private boolean[] isNull;
    private boolean[] isStream;
    protected int numberOfExecutions;
    protected String originalSql;
    protected int parameterCount;
    protected MysqlParameterMetadata parameterMetaData;
    private InputStream[] parameterStreams;
    private byte[][] parameterValues;
    private ParseInfo parseInfo;
    private ResultSetMetaData pstmtResultMetaData;
    private byte[][] staticSqlStrings;
    private byte[] streamConvertBuf;
    private int[] streamLengths;
    private SimpleDateFormat tsdf;
    protected boolean useTrueBoolean;
    private boolean usingAnsiMode;
    private String batchedValuesClause;
    private int statementAfterCommentsPos;
    private boolean hasCheckedForRewrite;
    private boolean canRewrite;
    private boolean doPingInstead;
    
    private static int readFully(final Reader reader, final char[] buf, final int length) throws IOException {
        int numCharsRead;
        int count;
        for (numCharsRead = 0; numCharsRead < length; numCharsRead += count) {
            count = reader.read(buf, numCharsRead, length - numCharsRead);
            if (count < 0) {
                break;
            }
        }
        return numCharsRead;
    }
    
    protected PreparedStatement(final Connection conn, final String catalog) throws SQLException {
        super(conn, catalog);
        this.batchHasPlainStatements = false;
        this.dbmd = null;
        this.firstCharOfStmt = '\0';
        this.hasLimitClause = false;
        this.isLoadDataQuery = false;
        this.isNull = null;
        this.isStream = null;
        this.numberOfExecutions = 0;
        this.originalSql = null;
        this.parameterStreams = null;
        this.parameterValues = null;
        this.staticSqlStrings = null;
        this.streamConvertBuf = new byte[4096];
        this.streamLengths = null;
        this.tsdf = null;
        this.useTrueBoolean = false;
        this.hasCheckedForRewrite = false;
        this.canRewrite = false;
    }
    
    public PreparedStatement(final Connection conn, final String sql, final String catalog) throws SQLException {
        super(conn, catalog);
        this.batchHasPlainStatements = false;
        this.dbmd = null;
        this.firstCharOfStmt = '\0';
        this.hasLimitClause = false;
        this.isLoadDataQuery = false;
        this.isNull = null;
        this.isStream = null;
        this.numberOfExecutions = 0;
        this.originalSql = null;
        this.parameterStreams = null;
        this.parameterValues = null;
        this.staticSqlStrings = null;
        this.streamConvertBuf = new byte[4096];
        this.streamLengths = null;
        this.tsdf = null;
        this.useTrueBoolean = false;
        this.hasCheckedForRewrite = false;
        this.canRewrite = false;
        if (sql == null) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.0"), "S1009");
        }
        this.originalSql = sql;
        if (this.originalSql.startsWith("/* ping */")) {
            this.doPingInstead = true;
        }
        else {
            this.doPingInstead = false;
        }
        this.dbmd = this.connection.getMetaData();
        this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
        this.parseInfo = new ParseInfo(sql, this.connection, this.dbmd, this.charEncoding, this.charConverter);
        this.initializeFromParseInfo();
    }
    
    public PreparedStatement(final Connection conn, final String sql, final String catalog, final ParseInfo cachedParseInfo) throws SQLException {
        super(conn, catalog);
        this.batchHasPlainStatements = false;
        this.dbmd = null;
        this.firstCharOfStmt = '\0';
        this.hasLimitClause = false;
        this.isLoadDataQuery = false;
        this.isNull = null;
        this.isStream = null;
        this.numberOfExecutions = 0;
        this.originalSql = null;
        this.parameterStreams = null;
        this.parameterValues = null;
        this.staticSqlStrings = null;
        this.streamConvertBuf = new byte[4096];
        this.streamLengths = null;
        this.tsdf = null;
        this.useTrueBoolean = false;
        this.hasCheckedForRewrite = false;
        this.canRewrite = false;
        if (sql == null) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.1"), "S1009");
        }
        this.originalSql = sql;
        this.dbmd = this.connection.getMetaData();
        this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
        this.parseInfo = cachedParseInfo;
        this.usingAnsiMode = !this.connection.useAnsiQuotedIdentifiers();
        this.initializeFromParseInfo();
    }
    
    public void addBatch() throws SQLException {
        if (this.batchedArgs == null) {
            this.batchedArgs = new ArrayList();
        }
        this.batchedArgs.add(new BatchParams(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull));
    }
    
    public synchronized void addBatch(final String sql) throws SQLException {
        this.batchHasPlainStatements = true;
        super.addBatch(sql);
    }
    
    protected String asSql() throws SQLException {
        return this.asSql(false);
    }
    
    protected String asSql(final boolean quoteStreamsAndUnknowns) throws SQLException {
        if (this.isClosed) {
            return "statement has been closed, no further internal information available";
        }
        final StringBuffer buf = new StringBuffer();
        try {
            for (int i = 0; i < this.parameterCount; ++i) {
                if (this.charEncoding != null) {
                    buf.append(new String(this.staticSqlStrings[i], this.charEncoding));
                }
                else {
                    buf.append(new String(this.staticSqlStrings[i]));
                }
                if (this.parameterValues[i] == null && !this.isStream[i]) {
                    if (quoteStreamsAndUnknowns) {
                        buf.append("'");
                    }
                    buf.append("** NOT SPECIFIED **");
                    if (quoteStreamsAndUnknowns) {
                        buf.append("'");
                    }
                }
                else if (this.isStream[i]) {
                    if (quoteStreamsAndUnknowns) {
                        buf.append("'");
                    }
                    buf.append("** STREAM DATA **");
                    if (quoteStreamsAndUnknowns) {
                        buf.append("'");
                    }
                }
                else if (this.charConverter != null) {
                    buf.append(this.charConverter.toString(this.parameterValues[i]));
                }
                else if (this.charEncoding != null) {
                    buf.append(new String(this.parameterValues[i], this.charEncoding));
                }
                else {
                    buf.append(StringUtils.toAsciiString(this.parameterValues[i]));
                }
            }
            if (this.charEncoding != null) {
                buf.append(new String(this.staticSqlStrings[this.parameterCount], this.charEncoding));
            }
            else {
                buf.append(StringUtils.toAsciiString(this.staticSqlStrings[this.parameterCount]));
            }
        }
        catch (UnsupportedEncodingException uue) {
            throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
        }
        return buf.toString();
    }
    
    public synchronized void clearBatch() throws SQLException {
        this.batchHasPlainStatements = false;
        super.clearBatch();
    }
    
    public synchronized void clearParameters() throws SQLException {
        this.checkClosed();
        for (int i = 0; i < this.parameterValues.length; ++i) {
            this.parameterValues[i] = null;
            this.parameterStreams[i] = null;
            this.isStream[i] = false;
            this.isNull[i] = false;
        }
    }
    
    public synchronized void close() throws SQLException {
        this.realClose(true, true);
    }
    
    private final void escapeblockFast(final byte[] buf, final Buffer packet, final int size) throws SQLException {
        int lastwritten = 0;
        for (int i = 0; i < size; ++i) {
            final byte b = buf[i];
            if (b == 0) {
                if (i > lastwritten) {
                    packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
                }
                packet.writeByte((byte)92);
                packet.writeByte((byte)48);
                lastwritten = i + 1;
            }
            else if (b == 92 || b == 39 || (!this.usingAnsiMode && b == 34)) {
                if (i > lastwritten) {
                    packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
                }
                packet.writeByte((byte)92);
                lastwritten = i;
            }
        }
        if (lastwritten < size) {
            packet.writeBytesNoNull(buf, lastwritten, size - lastwritten);
        }
    }
    
    private final void escapeblockFast(final byte[] buf, final ByteArrayOutputStream bytesOut, final int size) {
        int lastwritten = 0;
        for (int i = 0; i < size; ++i) {
            final byte b = buf[i];
            if (b == 0) {
                if (i > lastwritten) {
                    bytesOut.write(buf, lastwritten, i - lastwritten);
                }
                bytesOut.write(92);
                bytesOut.write(48);
                lastwritten = i + 1;
            }
            else if (b == 92 || b == 39 || (!this.usingAnsiMode && b == 34)) {
                if (i > lastwritten) {
                    bytesOut.write(buf, lastwritten, i - lastwritten);
                }
                bytesOut.write(92);
                lastwritten = i;
            }
        }
        if (lastwritten < size) {
            bytesOut.write(buf, lastwritten, size - lastwritten);
        }
    }
    
    public boolean execute() throws SQLException {
        this.checkClosed();
        final Connection locallyScopedConn = this.connection;
        if (locallyScopedConn.isReadOnly() && this.firstCharOfStmt != 'S') {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.20") + Messages.getString("PreparedStatement.21"), "S1009");
        }
        ResultSet rs = null;
        CachedResultSetMetaData cachedMetadata = null;
        synchronized (locallyScopedConn.getMutex()) {
            this.clearWarnings();
            this.batchedGeneratedKeys = null;
            final Buffer sendPacket = this.fillSendPacket();
            String oldCatalog = null;
            if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
                oldCatalog = locallyScopedConn.getCatalog();
                locallyScopedConn.setCatalog(this.currentCatalog);
            }
            if (locallyScopedConn.getCacheResultSetMetadata()) {
                cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);
            }
            Field[] metadataFromCache = null;
            if (cachedMetadata != null) {
                metadataFromCache = cachedMetadata.fields;
            }
            boolean oldInfoMsgState = false;
            if (this.retrieveGeneratedKeys) {
                oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
                locallyScopedConn.setReadInfoMsgEnabled(true);
            }
            if (locallyScopedConn.useMaxRows()) {
                int rowLimit = -1;
                if (this.firstCharOfStmt == 'S') {
                    if (this.hasLimitClause) {
                        rowLimit = this.maxRows;
                    }
                    else if (this.maxRows <= 0) {
                        locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
                    }
                    else {
                        locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows, -1, null, 1003, 1007, false, this.currentCatalog, true);
                    }
                }
                else {
                    locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
                }
                rs = this.executeInternal(rowLimit, sendPacket, this.createStreamingResultSet(), this.firstCharOfStmt == 'S', true, metadataFromCache, false);
            }
            else {
                rs = this.executeInternal(-1, sendPacket, this.createStreamingResultSet(), this.firstCharOfStmt == 'S', true, metadataFromCache, false);
            }
            if (cachedMetadata != null) {
                locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results);
            }
            else if (rs.reallyResult() && locallyScopedConn.getCacheResultSetMetadata()) {
                locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, null, rs);
            }
            if (this.retrieveGeneratedKeys) {
                locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
                rs.setFirstCharOfQuery(this.firstCharOfStmt);
            }
            if (oldCatalog != null) {
                locallyScopedConn.setCatalog(oldCatalog);
            }
            this.lastInsertId = rs.getUpdateID();
            if (rs != null) {
                this.results = rs;
            }
        }
        return rs != null && rs.reallyResult();
    }
    
    public int[] executeBatch() throws SQLException {
        this.checkClosed();
        if (this.connection.isReadOnly()) {
            throw new SQLException(Messages.getString("PreparedStatement.25") + Messages.getString("PreparedStatement.26"), "S1009");
        }
        synchronized (this.connection.getMutex()) {
            if (this.batchedArgs == null || this.batchedArgs.size() == 0) {
                return new int[0];
            }
            try {
                this.clearWarnings();
                if (!this.batchHasPlainStatements && this.connection.getRewriteBatchedStatements() && this.canRewriteAsMultivalueInsertStatement()) {
                    return this.executeBatchedInserts();
                }
                return this.executeBatchSerially();
            }
            catch (NullPointerException npe) {
                this.checkClosed();
                throw npe;
            }
            finally {
                this.clearBatch();
            }
        }
    }
    
    public synchronized boolean canRewriteAsMultivalueInsertStatement() {
        if (!this.hasCheckedForRewrite) {
            this.canRewrite = (StringUtils.startsWithIgnoreCaseAndWs(this.originalSql, "INSERT", this.statementAfterCommentsPos) && StringUtils.indexOfIgnoreCaseRespectMarker(this.statementAfterCommentsPos, this.originalSql, "SELECT", "\"'`", "\"'`", false) == -1 && StringUtils.indexOfIgnoreCaseRespectMarker(this.statementAfterCommentsPos, this.originalSql, "UPDATE", "\"'`", "\"'`", false) == -1);
            this.hasCheckedForRewrite = true;
        }
        return this.canRewrite;
    }
    
    protected int[] executeBatchedInserts() throws SQLException {
        final String valuesClause = this.extractValuesClause();
        final Connection locallyScopedConn = this.connection;
        if (valuesClause == null) {
            return this.executeBatchSerially();
        }
        final int numBatchedArgs = this.batchedArgs.size();
        if (this.retrieveGeneratedKeys) {
            this.batchedGeneratedKeys = new ArrayList(numBatchedArgs);
        }
        int numValuesPerBatch = this.computeBatchSize(numBatchedArgs);
        if (numBatchedArgs < numValuesPerBatch) {
            numValuesPerBatch = numBatchedArgs;
        }
        java.sql.PreparedStatement batchedStatement = null;
        int batchedParamIndex = 1;
        int updateCountRunningTotal = 0;
        int numberToExecuteAsMultiValue = 0;
        int batchCounter = 0;
        try {
            if (this.retrieveGeneratedKeys) {
                batchedStatement = locallyScopedConn.prepareStatement(this.generateBatchedInsertSQL(valuesClause, numValuesPerBatch), 1);
            }
            else {
                batchedStatement = locallyScopedConn.prepareStatement(this.generateBatchedInsertSQL(valuesClause, numValuesPerBatch));
            }
            if (numBatchedArgs < numValuesPerBatch) {
                numberToExecuteAsMultiValue = numBatchedArgs;
            }
            else {
                numberToExecuteAsMultiValue = numBatchedArgs / numValuesPerBatch;
            }
            for (int numberArgsToExecute = numberToExecuteAsMultiValue * numValuesPerBatch, i = 0; i < numberArgsToExecute; ++i) {
                if (i != 0 && i % numValuesPerBatch == 0) {
                    updateCountRunningTotal += batchedStatement.executeUpdate();
                    this.getBatchedGeneratedKeys(batchedStatement);
                    batchedStatement.clearParameters();
                    batchedParamIndex = 1;
                }
                batchedParamIndex = this.setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++));
            }
            updateCountRunningTotal += batchedStatement.executeUpdate();
            this.getBatchedGeneratedKeys(batchedStatement);
            numValuesPerBatch = numBatchedArgs - batchCounter;
        }
        finally {
            if (batchedStatement != null) {
                batchedStatement.close();
            }
        }
        try {
            if (numValuesPerBatch > 0) {
                if (this.retrieveGeneratedKeys) {
                    batchedStatement = locallyScopedConn.prepareStatement(this.generateBatchedInsertSQL(valuesClause, numValuesPerBatch), 1);
                }
                else {
                    batchedStatement = locallyScopedConn.prepareStatement(this.generateBatchedInsertSQL(valuesClause, numValuesPerBatch));
                }
                for (batchedParamIndex = 1; batchCounter < numBatchedArgs; batchedParamIndex = this.setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++))) {}
                updateCountRunningTotal += batchedStatement.executeUpdate();
                this.getBatchedGeneratedKeys(batchedStatement);
            }
            final int[] updateCounts = new int[this.batchedArgs.size()];
            for (int i = 0; i < this.batchedArgs.size(); ++i) {
                updateCounts[i] = 1;
            }
            return updateCounts;
        }
        finally {
            if (batchedStatement != null) {
                batchedStatement.close();
            }
        }
    }
    
    protected int computeBatchSize(final int numBatchedArgs) {
        final long[] combinedValues = this.computeMaxParameterSetSizeAndBatchSize(numBatchedArgs);
        final long maxSizeOfParameterSet = combinedValues[0];
        final long sizeOfEntireBatch = combinedValues[1];
        final int maxAllowedPacket = this.connection.getMaxAllowedPacket();
        if (sizeOfEntireBatch < maxAllowedPacket - this.originalSql.length()) {
            return numBatchedArgs;
        }
        return (int)Math.max(1L, (maxAllowedPacket - this.originalSql.length()) / maxSizeOfParameterSet);
    }
    
    protected long[] computeMaxParameterSetSizeAndBatchSize(final int numBatchedArgs) {
        long sizeOfEntireBatch = 0L;
        long maxSizeOfParameterSet = 0L;
        for (int i = 0; i < numBatchedArgs; ++i) {
            final BatchParams paramArg = this.batchedArgs.get(i);
            final boolean[] isNullBatch = paramArg.isNull;
            final boolean[] isStreamBatch = paramArg.isStream;
            long sizeOfParameterSet = 0L;
            for (int j = 0; j < isNullBatch.length; ++j) {
                if (!isNullBatch[j]) {
                    if (isStreamBatch[j]) {
                        final int streamLength = paramArg.streamLengths[j];
                        if (streamLength != -1) {
                            sizeOfParameterSet += streamLength * 2;
                        }
                    }
                    else {
                        sizeOfParameterSet += paramArg.parameterStrings[j].length;
                    }
                }
                else {
                    sizeOfParameterSet += 4L;
                }
            }
            sizeOfParameterSet += this.batchedValuesClause.length() + 1;
            sizeOfEntireBatch += sizeOfParameterSet;
            if (sizeOfParameterSet > maxSizeOfParameterSet) {
                maxSizeOfParameterSet = sizeOfParameterSet;
            }
        }
        return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
    }
    
    protected int[] executeBatchSerially() throws SQLException {
        final Connection locallyScopedConn = this.connection;
        if (locallyScopedConn == null) {
            this.checkClosed();
        }
        int[] updateCounts = null;
        if (this.batchedArgs != null) {
            final int nbrCommands = this.batchedArgs.size();
            updateCounts = new int[nbrCommands];
            for (int i = 0; i < nbrCommands; ++i) {
                updateCounts[i] = -3;
            }
            SQLException sqlEx = null;
            int commandIndex = 0;
            if (this.retrieveGeneratedKeys) {
                this.batchedGeneratedKeys = new ArrayList(nbrCommands);
            }
            for (commandIndex = 0; commandIndex < nbrCommands; ++commandIndex) {
                final Object arg = this.batchedArgs.get(commandIndex);
                if (arg instanceof String) {
                    updateCounts[commandIndex] = this.executeUpdate((String)arg);
                }
                else {
                    final BatchParams paramArg = (BatchParams)arg;
                    try {
                        updateCounts[commandIndex] = this.executeUpdate(paramArg.parameterStrings, paramArg.parameterStreams, paramArg.isStream, paramArg.streamLengths, paramArg.isNull, true);
                        if (this.retrieveGeneratedKeys) {
                            java.sql.ResultSet rs = null;
                            try {
                                rs = this.getGeneratedKeysInternal();
                                while (rs.next()) {
                                    this.batchedGeneratedKeys.add(new byte[][] { rs.getBytes(1) });
                                }
                            }
                            finally {
                                if (rs != null) {
                                    rs.close();
                                }
                            }
                        }
                    }
                    catch (SQLException ex) {
                        updateCounts[commandIndex] = -3;
                        if (!this.continueBatchOnError) {
                            final int[] newUpdateCounts = new int[commandIndex];
                            System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
                            throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
                        }
                        sqlEx = ex;
                    }
                }
            }
            if (sqlEx != null) {
                throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
            }
        }
        return (updateCounts != null) ? updateCounts : new int[0];
    }
    
    protected ResultSet executeInternal(final int maxRowsToRetrieve, final Buffer sendPacket, final boolean createStreamingResultSet, final boolean queryIsSelectOnly, final boolean unpackFields, final Field[] cachedFields, final boolean isBatch) throws SQLException {
        try {
            synchronized (this.cancelTimeoutMutex) {
                this.wasCancelled = false;
            }
            final Connection locallyScopedConnection = this.connection;
            ++this.numberOfExecutions;
            if (this.doPingInstead) {
                this.doPingInstead();
                return this.results;
            }
            CancelTask timeoutTask = null;
            try {
                if (locallyScopedConnection.getEnableQueryTimeouts() && this.timeoutInMillis != 0 && locallyScopedConnection.versionMeetsMinimum(5, 0, 0)) {
                    timeoutTask = new CancelTask();
                    Connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
                }
                final ResultSet rs = locallyScopedConnection.execSQL(this, null, maxRowsToRetrieve, sendPacket, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, unpackFields, isBatch);
                if (timeoutTask != null) {
                    timeoutTask.cancel();
                    if (timeoutTask.caughtWhileCancelling != null) {
                        throw timeoutTask.caughtWhileCancelling;
                    }
                    timeoutTask = null;
                }
                synchronized (this.cancelTimeoutMutex) {
                    if (this.wasCancelled) {
                        this.wasCancelled = false;
                        throw new MySQLTimeoutException();
                    }
                }
            }
            finally {
                if (timeoutTask != null) {
                    timeoutTask.cancel();
                }
            }
            return;
        }
        catch (NullPointerException npe) {
            this.checkClosed();
            throw npe;
        }
    }
    
    public java.sql.ResultSet executeQuery() throws SQLException {
        this.checkClosed();
        final Connection locallyScopedConn = this.connection;
        this.checkForDml(this.originalSql, this.firstCharOfStmt);
        CachedResultSetMetaData cachedMetadata = null;
        synchronized (locallyScopedConn.getMutex()) {
            this.clearWarnings();
            this.batchedGeneratedKeys = null;
            final Buffer sendPacket = this.fillSendPacket();
            if (this.results != null && !this.connection.getHoldResultsOpenOverStatementClose() && !this.holdResultsOpenOverClose) {
                this.results.realClose(false);
            }
            String oldCatalog = null;
            if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
                oldCatalog = locallyScopedConn.getCatalog();
                locallyScopedConn.setCatalog(this.currentCatalog);
            }
            if (locallyScopedConn.getCacheResultSetMetadata()) {
                cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);
            }
            Field[] metadataFromCache = null;
            if (cachedMetadata != null) {
                metadataFromCache = cachedMetadata.fields;
            }
            if (locallyScopedConn.useMaxRows()) {
                if (this.hasLimitClause) {
                    this.results = this.executeInternal(this.maxRows, sendPacket, this.createStreamingResultSet(), true, cachedMetadata == null, metadataFromCache, false);
                }
                else {
                    if (this.maxRows <= 0) {
                        locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
                    }
                    else {
                        locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows, -1, null, 1003, 1007, false, this.currentCatalog, true);
                    }
                    this.results = this.executeInternal(-1, sendPacket, this.createStreamingResultSet(), true, cachedMetadata == null, metadataFromCache, false);
                    if (oldCatalog != null) {
                        this.connection.setCatalog(oldCatalog);
                    }
                }
            }
            else {
                this.results = this.executeInternal(-1, sendPacket, this.createStreamingResultSet(), true, cachedMetadata == null, metadataFromCache, false);
            }
            if (oldCatalog != null) {
                locallyScopedConn.setCatalog(oldCatalog);
            }
            if (cachedMetadata != null) {
                locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results);
            }
            else if (locallyScopedConn.getCacheResultSetMetadata()) {
                locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, null, this.results);
            }
        }
        this.lastInsertId = this.results.getUpdateID();
        return this.results;
    }
    
    public int executeUpdate() throws SQLException {
        return this.executeUpdate(true, false);
    }
    
    protected int executeUpdate(final boolean clearBatchedGeneratedKeysAndWarnings, final boolean isBatch) throws SQLException {
        if (clearBatchedGeneratedKeysAndWarnings) {
            this.clearWarnings();
            this.batchedGeneratedKeys = null;
        }
        return this.executeUpdate(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull, isBatch);
    }
    
    protected int executeUpdate(final byte[][] batchedParameterStrings, final InputStream[] batchedParameterStreams, final boolean[] batchedIsStream, final int[] batchedStreamLengths, final boolean[] batchedIsNull, final boolean isReallyBatch) throws SQLException {
        this.checkClosed();
        final Connection locallyScopedConn = this.connection;
        if (locallyScopedConn.isReadOnly()) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.34") + Messages.getString("PreparedStatement.35"), "S1009");
        }
        if (this.firstCharOfStmt == 'S' && this.isSelectQuery()) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.37"), "01S03");
        }
        if (this.results != null && !locallyScopedConn.getHoldResultsOpenOverStatementClose()) {
            this.results.realClose(false);
        }
        ResultSet rs = null;
        synchronized (locallyScopedConn.getMutex()) {
            final Buffer sendPacket = this.fillSendPacket(batchedParameterStrings, batchedParameterStreams, batchedIsStream, batchedStreamLengths);
            String oldCatalog = null;
            if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
                oldCatalog = locallyScopedConn.getCatalog();
                locallyScopedConn.setCatalog(this.currentCatalog);
            }
            if (locallyScopedConn.useMaxRows()) {
                locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
            }
            boolean oldInfoMsgState = false;
            if (this.retrieveGeneratedKeys) {
                oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
                locallyScopedConn.setReadInfoMsgEnabled(true);
            }
            rs = this.executeInternal(-1, sendPacket, false, false, true, null, isReallyBatch);
            if (this.retrieveGeneratedKeys) {
                locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
                rs.setFirstCharOfQuery(this.firstCharOfStmt);
            }
            if (oldCatalog != null) {
                locallyScopedConn.setCatalog(oldCatalog);
            }
        }
        this.results = rs;
        this.updateCount = rs.getUpdateCount();
        int truncatedUpdateCount = 0;
        if (this.updateCount > 2147483647L) {
            truncatedUpdateCount = Integer.MAX_VALUE;
        }
        else {
            truncatedUpdateCount = (int)this.updateCount;
        }
        this.lastInsertId = rs.getUpdateID();
        return truncatedUpdateCount;
    }
    
    private String extractValuesClause() throws SQLException {
        if (this.batchedValuesClause == null) {
            final String quoteCharStr = this.connection.getMetaData().getIdentifierQuoteString();
            int indexOfValues = -1;
            if (quoteCharStr.length() > 0) {
                indexOfValues = StringUtils.indexOfIgnoreCaseRespectQuotes(this.statementAfterCommentsPos, this.originalSql, "VALUES ", quoteCharStr.charAt(0), false);
            }
            else {
                indexOfValues = StringUtils.indexOfIgnoreCase(this.statementAfterCommentsPos, this.originalSql, "VALUES ");
            }
            if (indexOfValues == -1) {
                return null;
            }
            final int indexOfFirstParen = this.originalSql.indexOf(40, indexOfValues + 7);
            if (indexOfFirstParen == -1) {
                return null;
            }
            final int indexOfLastParen = this.originalSql.lastIndexOf(41);
            if (indexOfLastParen == -1) {
                return null;
            }
            this.batchedValuesClause = this.originalSql.substring(indexOfFirstParen, indexOfLastParen + 1);
        }
        return this.batchedValuesClause;
    }
    
    protected Buffer fillSendPacket() throws SQLException {
        return this.fillSendPacket(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths);
    }
    
    protected Buffer fillSendPacket(final byte[][] batchedParameterStrings, final InputStream[] batchedParameterStreams, final boolean[] batchedIsStream, final int[] batchedStreamLengths) throws SQLException {
        final Buffer sendPacket = this.connection.getIO().getSharedSendPacket();
        sendPacket.clear();
        sendPacket.writeByte((byte)3);
        final boolean useStreamLengths = this.connection.getUseStreamLengthsInPrepStmts();
        int ensurePacketSize = 0;
        for (int i = 0; i < batchedParameterStrings.length; ++i) {
            if (batchedIsStream[i] && useStreamLengths) {
                ensurePacketSize += batchedStreamLengths[i];
            }
        }
        if (ensurePacketSize != 0) {
            sendPacket.ensureCapacity(ensurePacketSize);
        }
        for (int i = 0; i < batchedParameterStrings.length; ++i) {
            if (batchedParameterStrings[i] == null && batchedParameterStreams[i] == null) {
                throw SQLError.createSQLException(Messages.getString("PreparedStatement.40") + (i + 1), "07001");
            }
            sendPacket.writeBytesNoNull(this.staticSqlStrings[i]);
            if (batchedIsStream[i]) {
                this.streamToBytes(sendPacket, batchedParameterStreams[i], true, batchedStreamLengths[i], useStreamLengths);
            }
            else {
                sendPacket.writeBytesNoNull(batchedParameterStrings[i]);
            }
        }
        sendPacket.writeBytesNoNull(this.staticSqlStrings[batchedParameterStrings.length]);
        return sendPacket;
    }
    
    private String generateBatchedInsertSQL(final String valuesClause, final int numBatches) {
        final StringBuffer newStatementSql = new StringBuffer(this.originalSql.length() + numBatches * (valuesClause.length() + 1));
        newStatementSql.append(this.originalSql);
        for (int i = 0; i < numBatches - 1; ++i) {
            newStatementSql.append(',');
            newStatementSql.append(valuesClause);
        }
        return newStatementSql.toString();
    }
    
    public byte[] getBytesRepresentation(final int parameterIndex) throws SQLException {
        if (this.isStream[parameterIndex]) {
            return this.streamToBytes(this.parameterStreams[parameterIndex], false, this.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
        }
        final byte[] parameterVal = this.parameterValues[parameterIndex];
        if (parameterVal == null) {
            return null;
        }
        if (parameterVal[0] == 39 && parameterVal[parameterVal.length - 1] == 39) {
            final byte[] valNoQuotes = new byte[parameterVal.length - 2];
            System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
            return valNoQuotes;
        }
        return parameterVal;
    }
    
    private final String getDateTimePattern(final String dt, final boolean toTime) throws Exception {
        final int dtLength = (dt != null) ? dt.length() : 0;
        if (dtLength >= 8 && dtLength <= 10) {
            int dashCount = 0;
            boolean isDateOnly = true;
            for (int i = 0; i < dtLength; ++i) {
                final char c = dt.charAt(i);
                if (!Character.isDigit(c) && c != '-') {
                    isDateOnly = false;
                    break;
                }
                if (c == '-') {
                    ++dashCount;
                }
            }
            if (isDateOnly && dashCount == 2) {
                return "yyyy-MM-dd";
            }
        }
        boolean colonsOnly = true;
        for (int j = 0; j < dtLength; ++j) {
            final char c2 = dt.charAt(j);
            if (!Character.isDigit(c2) && c2 != ':') {
                colonsOnly = false;
                break;
            }
        }
        if (colonsOnly) {
            return "HH:mm:ss";
        }
        final StringReader reader = new StringReader(dt + " ");
        final ArrayList vec = new ArrayList();
        final ArrayList vecRemovelist = new ArrayList();
        Object[] nv = { new Character('y'), new StringBuffer(), new Integer(0) };
        vec.add(nv);
        if (toTime) {
            nv = new Object[] { new Character('h'), new StringBuffer(), new Integer(0) };
            vec.add(nv);
        }
        int z;
        while ((z = reader.read()) != -1) {
            final char separator = (char)z;
            for (int maxvecs = vec.size(), count = 0; count < maxvecs; ++count) {
                final Object[] v = vec.get(count);
                final int n = (int)v[2];
                char c3 = this.getSuccessor((char)v[0], n);
                if (!Character.isLetterOrDigit(separator)) {
                    if (c3 == (char)v[0] && c3 != 'S') {
                        vecRemovelist.add(v);
                    }
                    else {
                        ((StringBuffer)v[1]).append(separator);
                        if (c3 == 'X' || c3 == 'Y') {
                            v[2] = new Integer(4);
                        }
                    }
                }
                else {
                    if (c3 == 'X') {
                        c3 = 'y';
                        nv = new Object[] { new Character('M'), new StringBuffer(((StringBuffer)v[1]).toString()).append('M'), new Integer(1) };
                        vec.add(nv);
                    }
                    else if (c3 == 'Y') {
                        c3 = 'M';
                        nv = new Object[] { new Character('d'), new StringBuffer(((StringBuffer)v[1]).toString()).append('d'), new Integer(1) };
                        vec.add(nv);
                    }
                    ((StringBuffer)v[1]).append(c3);
                    if (c3 == (char)v[0]) {
                        v[2] = new Integer(n + 1);
                    }
                    else {
                        v[0] = new Character(c3);
                        v[2] = new Integer(1);
                    }
                }
            }
            for (int size = vecRemovelist.size(), k = 0; k < size; ++k) {
                final Object[] v = vecRemovelist.get(k);
                vec.remove(v);
            }
            vecRemovelist.clear();
        }
        for (int size = vec.size(), k = 0; k < size; ++k) {
            final Object[] v = vec.get(k);
            final char c3 = (char)v[0];
            final int n = (int)v[2];
            final boolean bk = this.getSuccessor(c3, n) != c3;
            final boolean atEnd = (c3 == 's' || c3 == 'm' || (c3 == 'h' && toTime)) && bk;
            final boolean finishesAtDate = bk && c3 == 'd' && !toTime;
            final boolean containsEnd = ((StringBuffer)v[1]).toString().indexOf(87) != -1;
            if ((!atEnd && !finishesAtDate) || containsEnd) {
                vecRemovelist.add(v);
            }
        }
        for (int size = vecRemovelist.size(), k = 0; k < size; ++k) {
            vec.remove(vecRemovelist.get(k));
        }
        vecRemovelist.clear();
        final Object[] v = vec.get(0);
        final StringBuffer format = (StringBuffer)v[1];
        format.setLength(format.length() - 1);
        return format.toString();
    }
    
    public ResultSetMetaData getMetaData() throws SQLException {
        if (!this.isSelectQuery()) {
            return null;
        }
        PreparedStatement mdStmt = null;
        java.sql.ResultSet mdRs = null;
        if (this.pstmtResultMetaData == null) {
            try {
                mdStmt = new PreparedStatement(this.connection, this.originalSql, this.currentCatalog, this.parseInfo);
                mdStmt.setMaxRows(0);
                for (int paramCount = this.parameterValues.length, i = 1; i <= paramCount; ++i) {
                    mdStmt.setString(i, "");
                }
                final boolean hadResults = mdStmt.execute();
                if (hadResults) {
                    mdRs = mdStmt.getResultSet();
                    this.pstmtResultMetaData = mdRs.getMetaData();
                }
                else {
                    this.pstmtResultMetaData = new com.mysql.jdbc.ResultSetMetaData(new Field[0], this.connection.getUseOldAliasMetadataBehavior());
                }
            }
            finally {
                SQLException sqlExRethrow = null;
                if (mdRs != null) {
                    try {
                        mdRs.close();
                    }
                    catch (SQLException sqlEx) {
                        sqlExRethrow = sqlEx;
                    }
                    mdRs = null;
                }
                if (mdStmt != null) {
                    try {
                        mdStmt.close();
                    }
                    catch (SQLException sqlEx) {
                        sqlExRethrow = sqlEx;
                    }
                    mdStmt = null;
                }
                if (sqlExRethrow != null) {
                    throw sqlExRethrow;
                }
            }
        }
        return this.pstmtResultMetaData;
    }
    
    protected boolean isSelectQuery() {
        return StringUtils.startsWithIgnoreCaseAndWs(StringUtils.stripComments(this.originalSql, "'\"", "'\"", true, false, true, true), "SELECT");
    }
    
    public ParameterMetaData getParameterMetaData() throws SQLException {
        if (this.parameterMetaData == null) {
            if (this.connection.getGenerateSimpleParameterMetadata()) {
                this.parameterMetaData = new MysqlParameterMetadata(this.parameterCount);
            }
            else {
                this.parameterMetaData = new MysqlParameterMetadata(null, this.parameterCount);
            }
        }
        return this.parameterMetaData;
    }
    
    ParseInfo getParseInfo() {
        return this.parseInfo;
    }
    
    private final char getSuccessor(final char c, final int n) {
        return (c == 'y' && n == 2) ? 'X' : ((c == 'y' && n < 4) ? 'y' : ((c == 'y') ? 'M' : ((c == 'M' && n == 2) ? 'Y' : ((c == 'M' && n < 3) ? 'M' : ((c == 'M') ? 'd' : ((c == 'd' && n < 2) ? 'd' : ((c == 'd') ? 'H' : ((c == 'H' && n < 2) ? 'H' : ((c == 'H') ? 'm' : ((c == 'm' && n < 2) ? 'm' : ((c == 'm') ? 's' : ((c == 's' && n < 2) ? 's' : 'W'))))))))))));
    }
    
    private final void hexEscapeBlock(final byte[] buf, final Buffer packet, final int size) throws SQLException {
        for (final byte b : buf) {
            final int lowBits = (b & 0xFF) / 16;
            final int highBits = (b & 0xFF) % 16;
            packet.writeByte(PreparedStatement.HEX_DIGITS[lowBits]);
            packet.writeByte(PreparedStatement.HEX_DIGITS[highBits]);
        }
    }
    
    private void initializeFromParseInfo() throws SQLException {
        this.staticSqlStrings = this.parseInfo.staticSql;
        this.hasLimitClause = this.parseInfo.foundLimitClause;
        this.isLoadDataQuery = this.parseInfo.foundLoadData;
        this.firstCharOfStmt = this.parseInfo.firstStmtChar;
        this.parameterCount = this.staticSqlStrings.length - 1;
        this.parameterValues = new byte[this.parameterCount][];
        this.parameterStreams = new InputStream[this.parameterCount];
        this.isStream = new boolean[this.parameterCount];
        this.streamLengths = new int[this.parameterCount];
        this.isNull = new boolean[this.parameterCount];
        this.clearParameters();
        for (int j = 0; j < this.parameterCount; ++j) {
            this.isStream[j] = false;
        }
        this.statementAfterCommentsPos = this.parseInfo.statementStartPos;
    }
    
    boolean isNull(final int paramIndex) {
        return this.isNull[paramIndex];
    }
    
    private final int readblock(final InputStream i, final byte[] b) throws SQLException {
        try {
            return i.read(b);
        }
        catch (Throwable E) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.56") + E.getClass().getName(), "S1000");
        }
    }
    
    private final int readblock(final InputStream i, final byte[] b, final int length) throws SQLException {
        try {
            int lengthToRead = length;
            if (lengthToRead > b.length) {
                lengthToRead = b.length;
            }
            return i.read(b, 0, lengthToRead);
        }
        catch (Throwable E) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.55") + E.getClass().getName(), "S1000");
        }
    }
    
    protected void realClose(final boolean calledExplicitly, final boolean closeOpenResults) throws SQLException {
        if (this.useUsageAdvisor && this.numberOfExecutions <= 1) {
            final String message = Messages.getString("PreparedStatement.43");
            this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.currentCatalog, this.connectionId, this.getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
        }
        super.realClose(calledExplicitly, closeOpenResults);
        this.dbmd = null;
        this.originalSql = null;
        this.staticSqlStrings = null;
        this.parameterValues = null;
        this.parameterStreams = null;
        this.isStream = null;
        this.streamLengths = null;
        this.isNull = null;
        this.streamConvertBuf = null;
    }
    
    public void setArray(final int i, final Array x) throws SQLException {
        throw new NotImplemented();
    }
    
    public void setAsciiStream(final int parameterIndex, final InputStream x, final int length) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 12);
        }
        else {
            this.setBinaryStream(parameterIndex, x, length);
        }
    }
    
    public void setBigDecimal(final int parameterIndex, final BigDecimal x) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 3);
        }
        else {
            this.setInternal(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString(x)));
        }
    }
    
    public void setBinaryStream(final int parameterIndex, final InputStream x, final int length) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, -2);
        }
        else {
            final int parameterIndexOffset = this.getParameterIndexOffset();
            if (parameterIndex < 1 || parameterIndex > this.staticSqlStrings.length) {
                throw SQLError.createSQLException(Messages.getString("PreparedStatement.2") + parameterIndex + Messages.getString("PreparedStatement.3") + this.staticSqlStrings.length + Messages.getString("PreparedStatement.4"), "S1009");
            }
            if (parameterIndexOffset == -1 && parameterIndex == 1) {
                throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009");
            }
            this.parameterStreams[parameterIndex - 1 + parameterIndexOffset] = x;
            this.isStream[parameterIndex - 1 + parameterIndexOffset] = true;
            this.streamLengths[parameterIndex - 1 + parameterIndexOffset] = length;
            this.isNull[parameterIndex - 1 + parameterIndexOffset] = false;
        }
    }
    
    public void setBlob(final int i, final Blob x) throws SQLException {
        if (x == null) {
            this.setNull(i, 2004);
        }
        else {
            final ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
            bytesOut.write(39);
            this.escapeblockFast(x.getBytes(1L, (int)x.length()), bytesOut, (int)x.length());
            bytesOut.write(39);
            this.setInternal(i, bytesOut.toByteArray());
        }
    }
    
    public void setBoolean(final int parameterIndex, final boolean x) throws SQLException {
        if (this.useTrueBoolean) {
            this.setInternal(parameterIndex, x ? "1" : "0");
        }
        else {
            this.setInternal(parameterIndex, x ? "'t'" : "'f'");
        }
    }
    
    public void setByte(final int parameterIndex, final byte x) throws SQLException {
        this.setInternal(parameterIndex, String.valueOf(x));
    }
    
    public void setBytes(final int parameterIndex, final byte[] x) throws SQLException {
        this.setBytes(parameterIndex, x, true, true);
    }
    
    protected void setBytes(final int parameterIndex, final byte[] x, final boolean checkForIntroducer, final boolean escapeForMBChars) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, -2);
        }
        else {
            final String connectionEncoding = this.connection.getEncoding();
            if (this.connection.isNoBackslashEscapesSet() || (escapeForMBChars && this.connection.getUseUnicode() && connectionEncoding != null && CharsetMapping.isMultibyteCharset(connectionEncoding))) {
                final ByteArrayOutputStream bOut = new ByteArrayOutputStream(x.length * 2 + 3);
                bOut.write(120);
                bOut.write(39);
                for (int i = 0; i < x.length; ++i) {
                    final int lowBits = (x[i] & 0xFF) / 16;
                    final int highBits = (x[i] & 0xFF) % 16;
                    bOut.write(PreparedStatement.HEX_DIGITS[lowBits]);
                    bOut.write(PreparedStatement.HEX_DIGITS[highBits]);
                }
                bOut.write(39);
                this.setInternal(parameterIndex, bOut.toByteArray());
                return;
            }
            final int numBytes = x.length;
            int pad = 2;
            final boolean needsIntroducer = checkForIntroducer && this.connection.versionMeetsMinimum(4, 1, 0);
            if (needsIntroducer) {
                pad += 7;
            }
            final ByteArrayOutputStream bOut2 = new ByteArrayOutputStream(numBytes + pad);
            if (needsIntroducer) {
                bOut2.write(95);
                bOut2.write(98);
                bOut2.write(105);
                bOut2.write(110);
                bOut2.write(97);
                bOut2.write(114);
                bOut2.write(121);
            }
            bOut2.write(39);
            for (final byte b : x) {
                switch (b) {
                    case 0: {
                        bOut2.write(92);
                        bOut2.write(48);
                        break;
                    }
                    case 10: {
                        bOut2.write(92);
                        bOut2.write(110);
                        break;
                    }
                    case 13: {
                        bOut2.write(92);
                        bOut2.write(114);
                        break;
                    }
                    case 92: {
                        bOut2.write(92);
                        bOut2.write(92);
                        break;
                    }
                    case 39: {
                        bOut2.write(92);
                        bOut2.write(39);
                        break;
                    }
                    case 34: {
                        bOut2.write(92);
                        bOut2.write(34);
                        break;
                    }
                    case 26: {
                        bOut2.write(92);
                        bOut2.write(90);
                        break;
                    }
                    default: {
                        bOut2.write(b);
                        break;
                    }
                }
            }
            bOut2.write(39);
            this.setInternal(parameterIndex, bOut2.toByteArray());
        }
    }
    
    protected void setBytesNoEscape(final int parameterIndex, final byte[] parameterAsBytes) throws SQLException {
        final byte[] parameterWithQuotes = new byte[parameterAsBytes.length + 2];
        parameterWithQuotes[0] = 39;
        System.arraycopy(parameterAsBytes, 0, parameterWithQuotes, 1, parameterAsBytes.length);
        parameterWithQuotes[parameterAsBytes.length + 1] = 39;
        this.setInternal(parameterIndex, parameterWithQuotes);
    }
    
    protected void setBytesNoEscapeNoQuotes(final int parameterIndex, final byte[] parameterAsBytes) throws SQLException {
        this.setInternal(parameterIndex, parameterAsBytes);
    }
    
    public void setCharacterStream(final int parameterIndex, final Reader reader, final int length) throws SQLException {
        try {
            if (reader == null) {
                this.setNull(parameterIndex, -1);
            }
            else {
                char[] c = null;
                int len = 0;
                final boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
                final String forcedEncoding = this.connection.getClobCharacterEncoding();
                if (useLength && length != -1) {
                    c = new char[length];
                    final int numCharsRead = readFully(reader, c, length);
                    if (forcedEncoding == null) {
                        this.setString(parameterIndex, new String(c, 0, numCharsRead));
                    }
                    else {
                        try {
                            this.setBytes(parameterIndex, new String(c, 0, numCharsRead).getBytes(forcedEncoding));
                        }
                        catch (UnsupportedEncodingException uee) {
                            throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009");
                        }
                    }
                }
                else {
                    c = new char[4096];
                    final StringBuffer buf = new StringBuffer();
                    while ((len = reader.read(c)) != -1) {
                        buf.append(c, 0, len);
                    }
                    if (forcedEncoding == null) {
                        this.setString(parameterIndex, buf.toString());
                    }
                    else {
                        try {
                            this.setBytes(parameterIndex, buf.toString().getBytes(forcedEncoding));
                        }
                        catch (UnsupportedEncodingException uee) {
                            throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009");
                        }
                    }
                }
            }
        }
        catch (IOException ioEx) {
            throw SQLError.createSQLException(ioEx.toString(), "S1000");
        }
    }
    
    public void setClob(final int i, final Clob x) throws SQLException {
        if (x == null) {
            this.setNull(i, 2005);
            return;
        }
        final String forcedEncoding = this.connection.getClobCharacterEncoding();
        if (forcedEncoding == null) {
            this.setString(i, x.getSubString(1L, (int)x.length()));
        }
        else {
            try {
                this.setBytes(i, x.getSubString(1L, (int)x.length()).getBytes(forcedEncoding));
            }
            catch (UnsupportedEncodingException uee) {
                throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009");
            }
        }
    }
    
    public void setDate(final int parameterIndex, final Date x) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 91);
        }
        else {
            final SimpleDateFormat dateFormatter = new SimpleDateFormat("''yyyy-MM-dd''", Locale.US);
            this.setInternal(parameterIndex, dateFormatter.format(x));
        }
    }
    
    public void setDate(final int parameterIndex, final Date x, final Calendar cal) throws SQLException {
        this.setDate(parameterIndex, x);
    }
    
    public void setDouble(final int parameterIndex, final double x) throws SQLException {
        if (!this.connection.getAllowNanAndInf() && (x == Double.POSITIVE_INFINITY || x == Double.NEGATIVE_INFINITY || Double.isNaN(x))) {
            throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009");
        }
        this.setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
    }
    
    public void setFloat(final int parameterIndex, final float x) throws SQLException {
        this.setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
    }
    
    public void setInt(final int parameterIndex, final int x) throws SQLException {
        this.setInternal(parameterIndex, String.valueOf(x));
    }
    
    private final void setInternal(final int paramIndex, final byte[] val) throws SQLException {
        if (this.isClosed) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.48"), "S1009");
        }
        final int parameterIndexOffset = this.getParameterIndexOffset();
        if (paramIndex < 1) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.49") + paramIndex + Messages.getString("PreparedStatement.50"), "S1009");
        }
        if (paramIndex > this.parameterCount) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.51") + paramIndex + Messages.getString("PreparedStatement.52") + this.parameterValues.length + Messages.getString("PreparedStatement.53"), "S1009");
        }
        if (parameterIndexOffset == -1 && paramIndex == 1) {
            throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009");
        }
        this.isStream[paramIndex - 1 + parameterIndexOffset] = false;
        this.isNull[paramIndex - 1 + parameterIndexOffset] = false;
        this.parameterStreams[paramIndex - 1 + parameterIndexOffset] = null;
        this.parameterValues[paramIndex - 1 + parameterIndexOffset] = val;
    }
    
    private final void setInternal(final int paramIndex, final String val) throws SQLException {
        this.checkClosed();
        byte[] parameterAsBytes = null;
        if (this.charConverter != null) {
            parameterAsBytes = this.charConverter.toBytes(val);
        }
        else {
            parameterAsBytes = StringUtils.getBytes(val, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
        }
        this.setInternal(paramIndex, parameterAsBytes);
    }
    
    public void setLong(final int parameterIndex, final long x) throws SQLException {
        this.setInternal(parameterIndex, String.valueOf(x));
    }
    
    public void setNull(final int parameterIndex, final int sqlType) throws SQLException {
        this.setInternal(parameterIndex, "null");
        this.isNull[parameterIndex - 1] = true;
    }
    
    public void setNull(final int parameterIndex, final int sqlType, final String arg) throws SQLException {
        this.setNull(parameterIndex, sqlType);
    }
    
    private void setNumericObject(final int parameterIndex, final Object parameterObj, final int targetSqlType, final int scale) throws SQLException {
        Number parameterAsNum;
        if (parameterObj instanceof Boolean) {
            parameterAsNum = (parameterObj ? new Integer(1) : new Integer(0));
        }
        else if (parameterObj instanceof String) {
            switch (targetSqlType) {
                case -7: {
                    final boolean parameterAsBoolean = "true".equalsIgnoreCase((String)parameterObj);
                    parameterAsNum = (parameterAsBoolean ? new Integer(1) : new Integer(0));
                    break;
                }
                case -6:
                case 4:
                case 5: {
                    parameterAsNum = Integer.valueOf((String)parameterObj);
                    break;
                }
                case -5: {
                    parameterAsNum = Long.valueOf((String)parameterObj);
                    break;
                }
                case 7: {
                    parameterAsNum = Float.valueOf((String)parameterObj);
                    break;
                }
                case 6:
                case 8: {
                    parameterAsNum = Double.valueOf((String)parameterObj);
                    break;
                }
                default: {
                    parameterAsNum = new BigDecimal((String)parameterObj);
                    break;
                }
            }
        }
        else {
            parameterAsNum = (Number)parameterObj;
        }
        switch (targetSqlType) {
            case -7:
            case -6:
            case 4:
            case 5: {
                this.setInt(parameterIndex, parameterAsNum.intValue());
                break;
            }
            case -5: {
                this.setLong(parameterIndex, parameterAsNum.longValue());
                break;
            }
            case 7: {
                this.setFloat(parameterIndex, parameterAsNum.floatValue());
                break;
            }
            case 6:
            case 8: {
                this.setDouble(parameterIndex, parameterAsNum.doubleValue());
                break;
            }
            case 2:
            case 3: {
                if (parameterAsNum instanceof BigDecimal) {
                    BigDecimal scaledBigDecimal = null;
                    try {
                        scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale);
                    }
                    catch (ArithmeticException ex) {
                        try {
                            scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale, 4);
                        }
                        catch (ArithmeticException arEx) {
                            throw SQLError.createSQLException("Can't set scale of '" + scale + "' for DECIMAL argument '" + parameterAsNum + "'", "S1009");
                        }
                    }
                    this.setBigDecimal(parameterIndex, scaledBigDecimal);
                    break;
                }
                if (parameterAsNum instanceof BigInteger) {
                    this.setBigDecimal(parameterIndex, new BigDecimal((BigInteger)parameterAsNum, scale));
                    break;
                }
                this.setBigDecimal(parameterIndex, new BigDecimal(parameterAsNum.doubleValue()));
                break;
            }
        }
    }
    
    public void setObject(final int parameterIndex, final Object parameterObj) throws SQLException {
        if (parameterObj == null) {
            this.setNull(parameterIndex, 1111);
        }
        else if (parameterObj instanceof Byte) {
            this.setInt(parameterIndex, (int)parameterObj);
        }
        else if (parameterObj instanceof String) {
            this.setString(parameterIndex, (String)parameterObj);
        }
        else if (parameterObj instanceof BigDecimal) {
            this.setBigDecimal(parameterIndex, (BigDecimal)parameterObj);
        }
        else if (parameterObj instanceof Short) {
            this.setShort(parameterIndex, (short)parameterObj);
        }
        else if (parameterObj instanceof Integer) {
            this.setInt(parameterIndex, (int)parameterObj);
        }
        else if (parameterObj instanceof Long) {
            this.setLong(parameterIndex, (long)parameterObj);
        }
        else if (parameterObj instanceof Float) {
            this.setFloat(parameterIndex, (float)parameterObj);
        }
        else if (parameterObj instanceof Double) {
            this.setDouble(parameterIndex, (double)parameterObj);
        }
        else if (parameterObj instanceof byte[]) {
            this.setBytes(parameterIndex, (byte[])parameterObj);
        }
        else if (parameterObj instanceof Date) {
            this.setDate(parameterIndex, (Date)parameterObj);
        }
        else if (parameterObj instanceof Time) {
            this.setTime(parameterIndex, (Time)parameterObj);
        }
        else if (parameterObj instanceof Timestamp) {
            this.setTimestamp(parameterIndex, (Timestamp)parameterObj);
        }
        else if (parameterObj instanceof Boolean) {
            this.setBoolean(parameterIndex, (boolean)parameterObj);
        }
        else if (parameterObj instanceof InputStream) {
            this.setBinaryStream(parameterIndex, (InputStream)parameterObj, -1);
        }
        else if (parameterObj instanceof Blob) {
            this.setBlob(parameterIndex, (Blob)parameterObj);
        }
        else if (parameterObj instanceof Clob) {
            this.setClob(parameterIndex, (Clob)parameterObj);
        }
        else if (this.connection.getTreatUtilDateAsTimestamp() && parameterObj instanceof java.util.Date) {
            this.setTimestamp(parameterIndex, new Timestamp(((java.util.Date)parameterObj).getTime()));
        }
        else if (parameterObj instanceof BigInteger) {
            this.setString(parameterIndex, parameterObj.toString());
        }
        else {
            this.setSerializableObject(parameterIndex, parameterObj);
        }
    }
    
    public void setObject(final int parameterIndex, final Object parameterObj, final int targetSqlType) throws SQLException {
        if (!(parameterObj instanceof BigDecimal)) {
            this.setObject(parameterIndex, parameterObj, targetSqlType, 0);
        }
        else {
            this.setObject(parameterIndex, parameterObj, targetSqlType, ((BigDecimal)parameterObj).scale());
        }
    }
    
    public void setObject(final int parameterIndex, final Object parameterObj, final int targetSqlType, final int scale) throws SQLException {
        if (parameterObj == null) {
            this.setNull(parameterIndex, 1111);
        }
        else {
            try {
                switch (targetSqlType) {
                    case 16: {
                        if (parameterObj instanceof Boolean) {
                            this.setBoolean(parameterIndex, (boolean)parameterObj);
                            break;
                        }
                        if (parameterObj instanceof String) {
                            this.setBoolean(parameterIndex, "true".equalsIgnoreCase((String)parameterObj) || !"0".equalsIgnoreCase((String)parameterObj));
                            break;
                        }
                        if (parameterObj instanceof Number) {
                            final int intValue = ((Number)parameterObj).intValue();
                            this.setBoolean(parameterIndex, intValue != 0);
                            break;
                        }
                        throw SQLError.createSQLException("No conversion from " + parameterObj.getClass().getName() + " to Types.BOOLEAN possible.", "S1009");
                    }
                    case -7:
                    case -6:
                    case -5:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8: {
                        this.setNumericObject(parameterIndex, parameterObj, targetSqlType, scale);
                        break;
                    }
                    case -1:
                    case 1:
                    case 12: {
                        if (parameterObj instanceof BigDecimal) {
                            this.setString(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString((BigDecimal)parameterObj)));
                            break;
                        }
                        this.setString(parameterIndex, parameterObj.toString());
                        break;
                    }
                    case 2005: {
                        if (parameterObj instanceof Clob) {
                            this.setClob(parameterIndex, (Clob)parameterObj);
                            break;
                        }
                        this.setString(parameterIndex, parameterObj.toString());
                        break;
                    }
                    case -4:
                    case -3:
                    case -2:
                    case 2004: {
                        if (parameterObj instanceof byte[]) {
                            this.setBytes(parameterIndex, (byte[])parameterObj);
                            break;
                        }
                        if (parameterObj instanceof Blob) {
                            this.setBlob(parameterIndex, (Blob)parameterObj);
                            break;
                        }
                        this.setBytes(parameterIndex, StringUtils.getBytes(parameterObj.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode()));
                        break;
                    }
                    case 91:
                    case 93: {
                        java.util.Date parameterAsDate;
                        if (parameterObj instanceof String) {
                            final ParsePosition pp = new ParsePosition(0);
                            final DateFormat sdf = new SimpleDateFormat(this.getDateTimePattern((String)parameterObj, false), Locale.US);
                            parameterAsDate = sdf.parse((String)parameterObj, pp);
                        }
                        else {
                            parameterAsDate = (java.util.Date)parameterObj;
                        }
                        switch (targetSqlType) {
                            case 91: {
                                if (parameterAsDate instanceof Date) {
                                    this.setDate(parameterIndex, (Date)parameterAsDate);
                                    break;
                                }
                                this.setDate(parameterIndex, new Date(parameterAsDate.getTime()));
                                break;
                            }
                            case 93: {
                                if (parameterAsDate instanceof Timestamp) {
                                    this.setTimestamp(parameterIndex, (Timestamp)parameterAsDate);
                                    break;
                                }
                                this.setTimestamp(parameterIndex, new Timestamp(parameterAsDate.getTime()));
                                break;
                            }
                        }
                        break;
                    }
                    case 92: {
                        if (parameterObj instanceof String) {
                            final DateFormat sdf2 = new SimpleDateFormat(this.getDateTimePattern((String)parameterObj, true), Locale.US);
                            this.setTime(parameterIndex, new Time(sdf2.parse((String)parameterObj).getTime()));
                            break;
                        }
                        if (parameterObj instanceof Timestamp) {
                            final Timestamp xT = (Timestamp)parameterObj;
                            this.setTime(parameterIndex, new Time(xT.getTime()));
                            break;
                        }
                        this.setTime(parameterIndex, (Time)parameterObj);
                        break;
                    }
                    case 1111: {
                        this.setSerializableObject(parameterIndex, parameterObj);
                        break;
                    }
                    default: {
                        throw SQLError.createSQLException(Messages.getString("PreparedStatement.16"), "S1000");
                    }
                }
            }
            catch (Exception ex) {
                if (ex instanceof SQLException) {
                    throw (SQLException)ex;
                }
                throw SQLError.createSQLException(Messages.getString("PreparedStatement.17") + parameterObj.getClass().toString() + Messages.getString("PreparedStatement.18") + ex.getClass().getName() + Messages.getString("PreparedStatement.19") + ex.getMessage(), "S1000");
            }
        }
    }
    
    protected int setOneBatchedParameterSet(final java.sql.PreparedStatement batchedStatement, int batchedParamIndex, final Object paramSet) throws SQLException {
        final BatchParams paramArg = (BatchParams)paramSet;
        final boolean[] isNullBatch = paramArg.isNull;
        final boolean[] isStreamBatch = paramArg.isStream;
        for (int j = 0; j < isNullBatch.length; ++j) {
            if (isNullBatch[j]) {
                batchedStatement.setNull(batchedParamIndex++, 0);
            }
            else if (isStreamBatch[j]) {
                batchedStatement.setBinaryStream(batchedParamIndex++, paramArg.parameterStreams[j], paramArg.streamLengths[j]);
            }
            else {
                ((PreparedStatement)batchedStatement).setBytesNoEscapeNoQuotes(batchedParamIndex++, paramArg.parameterStrings[j]);
            }
        }
        return batchedParamIndex;
    }
    
    public void setRef(final int i, final Ref x) throws SQLException {
        throw new NotImplemented();
    }
    
    void setResultSetConcurrency(final int concurrencyFlag) {
        this.resultSetConcurrency = concurrencyFlag;
    }
    
    void setResultSetType(final int typeFlag) {
        this.resultSetType = typeFlag;
    }
    
    protected void setRetrieveGeneratedKeys(final boolean retrieveGeneratedKeys) {
        this.retrieveGeneratedKeys = retrieveGeneratedKeys;
    }
    
    private final void setSerializableObject(final int parameterIndex, final Object parameterObj) throws SQLException {
        try {
            final ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
            final ObjectOutputStream objectOut = new ObjectOutputStream(bytesOut);
            objectOut.writeObject(parameterObj);
            objectOut.flush();
            objectOut.close();
            bytesOut.flush();
            bytesOut.close();
            final byte[] buf = bytesOut.toByteArray();
            final ByteArrayInputStream bytesIn = new ByteArrayInputStream(buf);
            this.setBinaryStream(parameterIndex, bytesIn, buf.length);
        }
        catch (Exception ex) {
            throw SQLError.createSQLException(Messages.getString("PreparedStatement.54") + ex.getClass().getName(), "S1009");
        }
    }
    
    public void setShort(final int parameterIndex, final short x) throws SQLException {
        this.setInternal(parameterIndex, String.valueOf(x));
    }
    
    public void setString(final int parameterIndex, final String x) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 1);
        }
        else {
            this.checkClosed();
            final int stringLength = x.length();
            if (this.connection.isNoBackslashEscapesSet()) {
                boolean needsHexEscape = false;
                for (int i = 0; i < stringLength; ++i) {
                    final char c = x.charAt(i);
                    switch (c) {
                        case '\0': {
                            needsHexEscape = true;
                            break;
                        }
                        case '\n': {
                            needsHexEscape = true;
                            break;
                        }
                        case '\r': {
                            needsHexEscape = true;
                            break;
                        }
                        case '\\': {
                            needsHexEscape = true;
                            break;
                        }
                        case '\'': {
                            needsHexEscape = true;
                            break;
                        }
                        case '\"': {
                            needsHexEscape = true;
                            break;
                        }
                        case '\u001a': {
                            needsHexEscape = true;
                            break;
                        }
                    }
                    if (needsHexEscape) {
                        break;
                    }
                }
                if (!needsHexEscape) {
                    byte[] parameterAsBytes = null;
                    final StringBuffer quotedString = new StringBuffer(x.length() + 2);
                    quotedString.append('\'');
                    quotedString.append(x);
                    quotedString.append('\'');
                    if (!this.isLoadDataQuery) {
                        parameterAsBytes = StringUtils.getBytes(quotedString.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
                    }
                    else {
                        parameterAsBytes = quotedString.toString().getBytes();
                    }
                    this.setInternal(parameterIndex, parameterAsBytes);
                }
                else {
                    byte[] parameterAsBytes = null;
                    if (!this.isLoadDataQuery) {
                        parameterAsBytes = StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
                    }
                    else {
                        parameterAsBytes = x.getBytes();
                    }
                    this.setBytes(parameterIndex, parameterAsBytes);
                }
                return;
            }
            final StringBuffer buf = new StringBuffer((int)(x.length() * 1.1));
            buf.append('\'');
            for (int i = 0; i < stringLength; ++i) {
                final char c = x.charAt(i);
                switch (c) {
                    case '\0': {
                        buf.append('\\');
                        buf.append('0');
                        break;
                    }
                    case '\n': {
                        buf.append('\\');
                        buf.append('n');
                        break;
                    }
                    case '\r': {
                        buf.append('\\');
                        buf.append('r');
                        break;
                    }
                    case '\\': {
                        buf.append('\\');
                        buf.append('\\');
                        break;
                    }
                    case '\'': {
                        buf.append('\\');
                        buf.append('\'');
                        break;
                    }
                    case '\"': {
                        if (this.usingAnsiMode) {
                            buf.append('\\');
                        }
                        buf.append('\"');
                        break;
                    }
                    case '\u001a': {
                        buf.append('\\');
                        buf.append('Z');
                        break;
                    }
                    default: {
                        buf.append(c);
                        break;
                    }
                }
            }
            buf.append('\'');
            final String parameterAsString = buf.toString();
            byte[] parameterAsBytes2 = null;
            if (!this.isLoadDataQuery) {
                parameterAsBytes2 = StringUtils.getBytes(parameterAsString, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
            }
            else {
                parameterAsBytes2 = parameterAsString.getBytes();
            }
            this.setInternal(parameterIndex, parameterAsBytes2);
        }
    }
    
    public void setTime(final int parameterIndex, final Time x, final Calendar cal) throws SQLException {
        this.setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
    }
    
    public void setTime(final int parameterIndex, final Time x) throws SQLException {
        this.setTimeInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
    }
    
    private void setTimeInternal(final int parameterIndex, Time x, final Calendar targetCalendar, final TimeZone tz, final boolean rollForward) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 92);
        }
        else {
            this.checkClosed();
            final Calendar sessionCalendar = this.getCalendarInstanceForSessionOrNew();
            synchronized (sessionCalendar) {
                x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
            }
            this.setInternal(parameterIndex, "'" + x.toString() + "'");
        }
    }
    
    public void setTimestamp(final int parameterIndex, final Timestamp x, final Calendar cal) throws SQLException {
        this.setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
    }
    
    public void setTimestamp(final int parameterIndex, final Timestamp x) throws SQLException {
        this.setTimestampInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
    }
    
    private void setTimestampInternal(final int parameterIndex, Timestamp x, final Calendar targetCalendar, final TimeZone tz, final boolean rollForward) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 93);
        }
        else {
            this.checkClosed();
            String timestampString = null;
            final Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : this.getCalendarInstanceForSessionOrNew();
            synchronized (sessionCalendar) {
                x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
            }
            if (this.connection.getUseSSPSCompatibleTimezoneShift()) {
                this.doSSPSCompatibleTimezoneShift(parameterIndex, x, sessionCalendar);
            }
            else {
                if (this.tsdf == null) {
                    this.tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss''", Locale.US);
                }
                timestampString = this.tsdf.format(x);
                this.setInternal(parameterIndex, timestampString);
            }
        }
    }
    
    private void doSSPSCompatibleTimezoneShift(final int parameterIndex, final Timestamp x, final Calendar sessionCalendar) throws SQLException {
        final Calendar sessionCalendar2 = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : this.getCalendarInstanceForSessionOrNew();
        synchronized (sessionCalendar2) {
            final java.util.Date oldTime = sessionCalendar2.getTime();
            try {
                sessionCalendar2.setTime(x);
                final int year = sessionCalendar2.get(1);
                final int month = sessionCalendar2.get(2) + 1;
                final int date = sessionCalendar2.get(5);
                final int hour = sessionCalendar2.get(11);
                final int minute = sessionCalendar2.get(12);
                final int seconds = sessionCalendar2.get(13);
                final StringBuffer tsBuf = new StringBuffer();
                tsBuf.append('\'');
                tsBuf.append(year);
                tsBuf.append("-");
                if (month < 10) {
                    tsBuf.append('0');
                }
                tsBuf.append(month);
                tsBuf.append('-');
                if (date < 10) {
                    tsBuf.append('0');
                }
                tsBuf.append(date);
                tsBuf.append(' ');
                if (hour < 10) {
                    tsBuf.append('0');
                }
                tsBuf.append(hour);
                tsBuf.append(':');
                if (minute < 10) {
                    tsBuf.append('0');
                }
                tsBuf.append(minute);
                tsBuf.append(':');
                if (seconds < 10) {
                    tsBuf.append('0');
                }
                tsBuf.append(seconds);
                tsBuf.append('\'');
                this.setInternal(parameterIndex, tsBuf.toString());
            }
            finally {
                sessionCalendar.setTime(oldTime);
            }
        }
    }
    
    public void setUnicodeStream(final int parameterIndex, final InputStream x, final int length) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 12);
        }
        else {
            this.setBinaryStream(parameterIndex, x, length);
        }
    }
    
    public void setURL(final int parameterIndex, final URL arg) throws SQLException {
        if (arg != null) {
            this.setString(parameterIndex, arg.toString());
        }
        else {
            this.setNull(parameterIndex, 1);
        }
    }
    
    private final void streamToBytes(final Buffer packet, InputStream in, final boolean escape, final int streamLength, boolean useLength) throws SQLException {
        try {
            final String connectionEncoding = this.connection.getEncoding();
            boolean hexEscape = false;
            if (this.connection.isNoBackslashEscapesSet() || (this.connection.getUseUnicode() && connectionEncoding != null && CharsetMapping.isMultibyteCharset(connectionEncoding) && !this.connection.parserKnowsUnicode())) {
                hexEscape = true;
            }
            if (streamLength == -1) {
                useLength = false;
            }
            int bc = -1;
            if (useLength) {
                bc = this.readblock(in, this.streamConvertBuf, streamLength);
            }
            else {
                bc = this.readblock(in, this.streamConvertBuf);
            }
            int lengthLeftToRead = streamLength - bc;
            if (hexEscape) {
                packet.writeStringNoNull("x");
            }
            else if (this.connection.getIO().versionMeetsMinimum(4, 1, 0)) {
                packet.writeStringNoNull("_binary");
            }
            if (escape) {
                packet.writeByte((byte)39);
            }
            while (bc > 0) {
                if (hexEscape) {
                    this.hexEscapeBlock(this.streamConvertBuf, packet, bc);
                }
                else if (escape) {
                    this.escapeblockFast(this.streamConvertBuf, packet, bc);
                }
                else {
                    packet.writeBytesNoNull(this.streamConvertBuf, 0, bc);
                }
                if (useLength) {
                    bc = this.readblock(in, this.streamConvertBuf, lengthLeftToRead);
                    if (bc <= 0) {
                        continue;
                    }
                    lengthLeftToRead -= bc;
                }
                else {
                    bc = this.readblock(in, this.streamConvertBuf);
                }
            }
            if (escape) {
                packet.writeByte((byte)39);
            }
        }
        finally {
            if (this.connection.getAutoClosePStmtStreams()) {
                try {
                    in.close();
                }
                catch (IOException ex) {}
                in = null;
            }
        }
    }
    
    private final byte[] streamToBytes(InputStream in, final boolean escape, final int streamLength, boolean useLength) throws SQLException {
        try {
            if (streamLength == -1) {
                useLength = false;
            }
            final ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
            int bc = -1;
            if (useLength) {
                bc = this.readblock(in, this.streamConvertBuf, streamLength);
            }
            else {
                bc = this.readblock(in, this.streamConvertBuf);
            }
            int lengthLeftToRead = streamLength - bc;
            if (escape) {
                if (this.connection.versionMeetsMinimum(4, 1, 0)) {
                    bytesOut.write(95);
                    bytesOut.write(98);
                    bytesOut.write(105);
                    bytesOut.write(110);
                    bytesOut.write(97);
                    bytesOut.write(114);
                    bytesOut.write(121);
                }
                bytesOut.write(39);
            }
            while (bc > 0) {
                if (escape) {
                    this.escapeblockFast(this.streamConvertBuf, bytesOut, bc);
                }
                else {
                    bytesOut.write(this.streamConvertBuf, 0, bc);
                }
                if (useLength) {
                    bc = this.readblock(in, this.streamConvertBuf, lengthLeftToRead);
                    if (bc <= 0) {
                        continue;
                    }
                    lengthLeftToRead -= bc;
                }
                else {
                    bc = this.readblock(in, this.streamConvertBuf);
                }
            }
            if (escape) {
                bytesOut.write(39);
            }
            return bytesOut.toByteArray();
        }
        finally {
            if (this.connection.getAutoClosePStmtStreams()) {
                try {
                    in.close();
                }
                catch (IOException ex) {}
                in = null;
            }
        }
    }
    
    public String toString() {
        final StringBuffer buf = new StringBuffer();
        buf.append(super.toString());
        buf.append(": ");
        try {
            buf.append(this.asSql());
        }
        catch (SQLException sqlEx) {
            buf.append("EXCEPTION: " + sqlEx.toString());
        }
        return buf.toString();
    }
    
    protected int getParameterIndexOffset() {
        return 0;
    }
    
    static {
        HEX_DIGITS = new byte[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
    }
    
    class BatchParams
    {
        boolean[] isNull;
        boolean[] isStream;
        InputStream[] parameterStreams;
        byte[][] parameterStrings;
        int[] streamLengths;
        
        BatchParams(final byte[][] strings, final InputStream[] streams, final boolean[] isStreamFlags, final int[] lengths, final boolean[] isNullFlags) {
            this.isNull = null;
            this.isStream = null;
            this.parameterStreams = null;
            this.parameterStrings = null;
            this.streamLengths = null;
            this.parameterStrings = new byte[strings.length][];
            this.parameterStreams = new InputStream[streams.length];
            this.isStream = new boolean[isStreamFlags.length];
            this.streamLengths = new int[lengths.length];
            this.isNull = new boolean[isNullFlags.length];
            System.arraycopy(strings, 0, this.parameterStrings, 0, strings.length);
            System.arraycopy(streams, 0, this.parameterStreams, 0, streams.length);
            System.arraycopy(isStreamFlags, 0, this.isStream, 0, isStreamFlags.length);
            System.arraycopy(lengths, 0, this.streamLengths, 0, lengths.length);
            System.arraycopy(isNullFlags, 0, this.isNull, 0, isNullFlags.length);
        }
    }
    
    class EndPoint
    {
        int begin;
        int end;
        
        EndPoint(final int b, final int e) {
            this.begin = b;
            this.end = e;
        }
    }
    
    class ParseInfo
    {
        char firstStmtChar;
        boolean foundLimitClause;
        boolean foundLoadData;
        long lastUsed;
        int statementLength;
        int statementStartPos;
        byte[][] staticSql;
        
        public ParseInfo(final String sql, final Connection conn, final DatabaseMetaData dbmd, final String encoding, final SingleByteCharsetConverter converter) throws SQLException {
            this.firstStmtChar = '\0';
            this.foundLimitClause = false;
            this.foundLoadData = false;
            this.lastUsed = 0L;
            this.statementLength = 0;
            this.statementStartPos = 0;
            this.staticSql = null;
            if (sql == null) {
                throw SQLError.createSQLException(Messages.getString("PreparedStatement.61"), "S1009");
            }
            this.lastUsed = System.currentTimeMillis();
            final String quotedIdentifierString = dbmd.getIdentifierQuoteString();
            char quotedIdentifierChar = '\0';
            if (quotedIdentifierString != null && !quotedIdentifierString.equals(" ") && quotedIdentifierString.length() > 0) {
                quotedIdentifierChar = quotedIdentifierString.charAt(0);
            }
            this.statementLength = sql.length();
            final ArrayList endpointList = new ArrayList();
            boolean inQuotes = false;
            char quoteChar = '\0';
            boolean inQuotedId = false;
            int lastParmEnd = 0;
            final int stopLookingForLimitClause = this.statementLength - 5;
            this.foundLimitClause = false;
            final boolean noBackslashEscapes = PreparedStatement.this.connection.isNoBackslashEscapesSet();
            this.statementStartPos = PreparedStatement.this.findStartOfStatement(sql);
            for (int i = this.statementStartPos; i < this.statementLength; ++i) {
                char c = sql.charAt(i);
                if (this.firstStmtChar == '\0' && !Character.isWhitespace(c)) {
                    this.firstStmtChar = Character.toUpperCase(c);
                }
                if (!noBackslashEscapes && c == '\\' && i < this.statementLength - 1) {
                    ++i;
                }
                else {
                    if (!inQuotes && quotedIdentifierChar != '\0' && c == quotedIdentifierChar) {
                        inQuotedId = !inQuotedId;
                    }
                    else if (!inQuotedId) {
                        if (inQuotes) {
                            if ((c == '\'' || c == '\"') && c == quoteChar) {
                                if (i < this.statementLength - 1 && sql.charAt(i + 1) == quoteChar) {
                                    ++i;
                                    continue;
                                }
                                inQuotes = !inQuotes;
                                quoteChar = '\0';
                            }
                            else if ((c == '\'' || c == '\"') && c == quoteChar) {
                                inQuotes = !inQuotes;
                                quoteChar = '\0';
                            }
                        }
                        else {
                            if (c == '#' || (c == '-' && i + 1 < this.statementLength && sql.charAt(i + 1) == '-')) {
                                for (int endOfStmt = this.statementLength - 1; i < endOfStmt; ++i) {
                                    c = sql.charAt(i);
                                    if (c == '\r') {
                                        break;
                                    }
                                    if (c == '\n') {
                                        break;
                                    }
                                }
                                continue;
                            }
                            if (c == '/' && i + 1 < this.statementLength) {
                                char cNext = sql.charAt(i + 1);
                                if (cNext == '*') {
                                    i += 2;
                                    int j = i;
                                    while (j < this.statementLength) {
                                        ++i;
                                        cNext = sql.charAt(j);
                                        if (cNext == '*' && j + 1 < this.statementLength && sql.charAt(j + 1) == '/') {
                                            if (++i < this.statementLength) {
                                                c = sql.charAt(i);
                                                break;
                                            }
                                            break;
                                        }
                                        else {
                                            ++j;
                                        }
                                    }
                                }
                            }
                            else if (c == '\'' || c == '\"') {
                                inQuotes = true;
                                quoteChar = c;
                            }
                        }
                    }
                    if (c == '?' && !inQuotes && !inQuotedId) {
                        endpointList.add(new int[] { lastParmEnd, i });
                        lastParmEnd = i + 1;
                    }
                    if (!inQuotes && i < stopLookingForLimitClause && (c == 'L' || c == 'l')) {
                        final char posI1 = sql.charAt(i + 1);
                        if (posI1 == 'I' || posI1 == 'i') {
                            final char posM = sql.charAt(i + 2);
                            if (posM == 'M' || posM == 'm') {
                                final char posI2 = sql.charAt(i + 3);
                                if (posI2 == 'I' || posI2 == 'i') {
                                    final char posT = sql.charAt(i + 4);
                                    if (posT == 'T' || posT == 't') {
                                        this.foundLimitClause = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (this.firstStmtChar == 'L') {
                if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA")) {
                    this.foundLoadData = true;
                }
                else {
                    this.foundLoadData = false;
                }
            }
            else {
                this.foundLoadData = false;
            }
            endpointList.add(new int[] { lastParmEnd, this.statementLength });
            this.staticSql = new byte[endpointList.size()][];
            final char[] asCharArray = sql.toCharArray();
            for (int i = 0; i < this.staticSql.length; ++i) {
                final int[] ep = endpointList.get(i);
                final int end = ep[1];
                final int begin = ep[0];
                final int len = end - begin;
                if (this.foundLoadData) {
                    final String temp = new String(asCharArray, begin, len);
                    this.staticSql[i] = temp.getBytes();
                }
                else if (encoding == null) {
                    final byte[] buf = new byte[len];
                    for (int k = 0; k < len; ++k) {
                        buf[k] = (byte)sql.charAt(begin + k);
                    }
                    this.staticSql[i] = buf;
                }
                else if (converter != null) {
                    this.staticSql[i] = StringUtils.getBytes(sql, converter, encoding, PreparedStatement.this.connection.getServerCharacterEncoding(), begin, len, PreparedStatement.this.connection.parserKnowsUnicode());
                }
                else {
                    final String temp = new String(asCharArray, begin, len);
                    this.staticSql[i] = StringUtils.getBytes(temp, encoding, PreparedStatement.this.connection.getServerCharacterEncoding(), PreparedStatement.this.connection.parserKnowsUnicode(), conn);
                }
            }
        }
    }
}
