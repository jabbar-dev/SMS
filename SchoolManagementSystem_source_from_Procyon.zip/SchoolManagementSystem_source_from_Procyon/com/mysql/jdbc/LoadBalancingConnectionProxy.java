// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.lang.reflect.Proxy;
import java.util.Iterator;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Map;
import java.util.List;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationHandler;

public class LoadBalancingConnectionProxy implements InvocationHandler, PingTarget
{
    private static Method getLocalTimeMethod;
    private Connection currentConn;
    private List hostList;
    private Map liveConnections;
    private Map connectionsToHostsMap;
    private long[] responseTimes;
    private Map hostsToListIndexMap;
    boolean inTransaction;
    long transactionStartTime;
    Properties localProps;
    boolean isClosed;
    BalanceStrategy balancer;
    
    LoadBalancingConnectionProxy(final List hosts, final Properties props) throws SQLException {
        this.inTransaction = false;
        this.transactionStartTime = 0L;
        this.isClosed = false;
        this.hostList = hosts;
        final int numHosts = this.hostList.size();
        this.liveConnections = new HashMap(numHosts);
        this.connectionsToHostsMap = new HashMap(numHosts);
        this.responseTimes = new long[numHosts];
        this.hostsToListIndexMap = new HashMap(numHosts);
        for (int i = 0; i < numHosts; ++i) {
            this.hostsToListIndexMap.put(this.hostList.get(i), new Integer(i));
        }
        (this.localProps = (Properties)props.clone()).remove("HOST");
        this.localProps.remove("PORT");
        this.localProps.setProperty("useLocalSessionState", "true");
        final String strategy = this.localProps.getProperty("loadBalanceStrategy", "random");
        if ("random".equals(strategy)) {
            this.balancer = new RandomBalanceStrategy();
        }
        else {
            if (!"bestResponseTime".equals(strategy)) {
                throw SQLError.createSQLException(Messages.getString("InvalidLoadBalanceStrategy", new Object[] { strategy }), "S1009");
            }
            this.balancer = new BestResponseTimeBalanceStrategy();
        }
        this.pickNewConnection();
    }
    
    private synchronized Connection createConnectionForHost(final String hostPortSpec) throws SQLException {
        final Properties connProps = (Properties)this.localProps.clone();
        final String[] hostPortPair = NonRegisteringDriver.parseHostPortPair(hostPortSpec);
        if (hostPortPair[1] == null) {
            hostPortPair[1] = "3306";
        }
        connProps.setProperty("HOST", hostPortSpec);
        connProps.setProperty("PORT", hostPortPair[1]);
        final Connection conn = new Connection(hostPortSpec, Integer.parseInt(hostPortPair[1]), connProps, connProps.getProperty("DBNAME"), "jdbc:mysql://" + hostPortPair[0] + ":" + hostPortPair[1] + "/");
        this.liveConnections.put(hostPortSpec, conn);
        this.connectionsToHostsMap.put(conn, hostPortSpec);
        return conn;
    }
    
    void dealWithInvocationException(final InvocationTargetException e) throws SQLException, Throwable, InvocationTargetException {
        final Throwable t = e.getTargetException();
        if (t != null) {
            if (t instanceof SQLException) {
                final String sqlState = ((SQLException)t).getSQLState();
                if (sqlState != null && sqlState.startsWith("08")) {
                    this.invalidateCurrentConnection();
                }
            }
            throw t;
        }
        throw e;
    }
    
    synchronized void invalidateCurrentConnection() throws SQLException {
        try {
            if (!this.currentConn.isClosed()) {
                this.currentConn.close();
            }
        }
        finally {
            this.liveConnections.remove(this.connectionsToHostsMap.get(this.currentConn));
            this.connectionsToHostsMap.remove(this.currentConn);
        }
    }
    
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        final String methodName = method.getName();
        if ("close".equals(methodName)) {
            synchronized (this.liveConnections) {
                final Iterator allConnections = this.liveConnections.values().iterator();
                while (allConnections.hasNext()) {
                    allConnections.next().close();
                }
                this.liveConnections.clear();
                this.connectionsToHostsMap.clear();
            }
            return null;
        }
        if ("isClosed".equals(methodName)) {
            return this.isClosed;
        }
        if (this.isClosed) {
            throw SQLError.createSQLException("No operations allowed after connection closed.", "08003");
        }
        if (!this.inTransaction) {
            this.inTransaction = true;
            this.transactionStartTime = getLocalTimeBestResolution();
        }
        Object result = null;
        try {
            result = method.invoke(this.currentConn, args);
            if (result != null) {
                if (result instanceof Statement) {
                    ((Statement)result).setPingTarget(this);
                }
                result = this.proxyIfInterfaceIsJdbc(result, result.getClass());
            }
        }
        catch (InvocationTargetException e) {
            this.dealWithInvocationException(e);
        }
        finally {
            if ("commit".equals(methodName) || "rollback".equals(methodName)) {
                this.inTransaction = false;
                final int hostIndex = this.hostsToListIndexMap.get(this.connectionsToHostsMap.get(this.currentConn));
                synchronized (this.responseTimes) {
                    this.responseTimes[hostIndex] = getLocalTimeBestResolution() - this.transactionStartTime;
                }
                this.pickNewConnection();
            }
        }
        return result;
    }
    
    private synchronized void pickNewConnection() throws SQLException {
        if (this.currentConn == null) {
            this.currentConn = this.balancer.pickConnection();
            return;
        }
        final Connection newConn = this.balancer.pickConnection();
        newConn.setTransactionIsolation(this.currentConn.getTransactionIsolation());
        newConn.setAutoCommit(this.currentConn.getAutoCommit());
        this.currentConn = newConn;
    }
    
    Object proxyIfInterfaceIsJdbc(final Object toProxy, final Class clazz) {
        final Class[] interfaces = clazz.getInterfaces();
        final int i = 0;
        if (i >= interfaces.length) {
            return toProxy;
        }
        final String packageName = interfaces[i].getPackage().getName();
        if ("java.sql".equals(packageName) || "javax.sql".equals(packageName)) {
            return Proxy.newProxyInstance(toProxy.getClass().getClassLoader(), interfaces, new ConnectionErrorFiringInvocationHandler(toProxy));
        }
        return this.proxyIfInterfaceIsJdbc(toProxy, interfaces[i]);
    }
    
    private static long getLocalTimeBestResolution() {
        if (LoadBalancingConnectionProxy.getLocalTimeMethod != null) {
            try {
                return (long)LoadBalancingConnectionProxy.getLocalTimeMethod.invoke(null, (Object[])null);
            }
            catch (IllegalArgumentException e) {}
            catch (IllegalAccessException e2) {}
            catch (InvocationTargetException ex) {}
        }
        return System.currentTimeMillis();
    }
    
    public synchronized void doPing() throws SQLException {
        final Iterator allConns = this.liveConnections.values().iterator();
        while (allConns.hasNext()) {
            allConns.next().ping();
        }
    }
    
    static {
        try {
            LoadBalancingConnectionProxy.getLocalTimeMethod = System.class.getMethod("nanoTime", (Class[])new Class[0]);
        }
        catch (SecurityException e) {}
        catch (NoSuchMethodException ex) {}
    }
    
    class BestResponseTimeBalanceStrategy implements BalanceStrategy
    {
        public Connection pickConnection() throws SQLException {
            long minResponseTime = Long.MAX_VALUE;
            int bestHostIndex = 0;
            final long[] localResponseTimes = new long[LoadBalancingConnectionProxy.this.responseTimes.length];
            synchronized (LoadBalancingConnectionProxy.this.responseTimes) {
                System.arraycopy(LoadBalancingConnectionProxy.this.responseTimes, 0, localResponseTimes, 0, LoadBalancingConnectionProxy.this.responseTimes.length);
            }
            SQLException ex = null;
            for (int attempts = 0; attempts < 1200; ++attempts) {
                for (int i = 0; i < localResponseTimes.length; ++i) {
                    final long candidateResponseTime = localResponseTimes[i];
                    if (candidateResponseTime < minResponseTime) {
                        if (candidateResponseTime == 0L) {
                            bestHostIndex = i;
                            break;
                        }
                        bestHostIndex = i;
                        minResponseTime = candidateResponseTime;
                    }
                }
                if (bestHostIndex == localResponseTimes.length - 1) {
                    synchronized (LoadBalancingConnectionProxy.this.responseTimes) {
                        System.arraycopy(LoadBalancingConnectionProxy.this.responseTimes, 0, localResponseTimes, 0, LoadBalancingConnectionProxy.this.responseTimes.length);
                        continue;
                    }
                }
                final String bestHost = LoadBalancingConnectionProxy.this.hostList.get(bestHostIndex);
                Connection conn = LoadBalancingConnectionProxy.this.liveConnections.get(bestHost);
                if (conn == null) {
                    try {
                        conn = LoadBalancingConnectionProxy.this.createConnectionForHost(bestHost);
                    }
                    catch (SQLException sqlEx) {
                        ex = sqlEx;
                        if (sqlEx instanceof CommunicationsException || "08S01".equals(sqlEx.getSQLState())) {
                            localResponseTimes[bestHostIndex] = Long.MAX_VALUE;
                            try {
                                Thread.sleep(250L);
                            }
                            catch (InterruptedException ex2) {}
                            continue;
                        }
                        throw sqlEx;
                    }
                }
                return conn;
            }
            if (ex != null) {
                throw ex;
            }
            return null;
        }
    }
    
    protected class ConnectionErrorFiringInvocationHandler implements InvocationHandler
    {
        Object invokeOn;
        
        public ConnectionErrorFiringInvocationHandler(final Object toInvokeOn) {
            this.invokeOn = null;
            this.invokeOn = toInvokeOn;
        }
        
        public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
            Object result = null;
            try {
                result = method.invoke(this.invokeOn, args);
                if (result != null) {
                    result = LoadBalancingConnectionProxy.this.proxyIfInterfaceIsJdbc(result, result.getClass());
                }
            }
            catch (InvocationTargetException e) {
                LoadBalancingConnectionProxy.this.dealWithInvocationException(e);
            }
            return result;
        }
    }
    
    class RandomBalanceStrategy implements BalanceStrategy
    {
        public Connection pickConnection() throws SQLException {
            int random = (int)(Math.random() * LoadBalancingConnectionProxy.this.hostList.size());
            if (random == LoadBalancingConnectionProxy.this.hostList.size()) {
                --random;
            }
            final String hostPortSpec = LoadBalancingConnectionProxy.this.hostList.get(random);
            SQLException ex = null;
            int attempts = 0;
            while (attempts < 1200) {
                Connection conn = LoadBalancingConnectionProxy.this.liveConnections.get(hostPortSpec);
                if (conn == null) {
                    Label_0150: {
                        try {
                            conn = LoadBalancingConnectionProxy.this.createConnectionForHost(hostPortSpec);
                        }
                        catch (SQLException sqlEx) {
                            ex = sqlEx;
                            if (!(sqlEx instanceof CommunicationsException)) {
                                if (!"08S01".equals(sqlEx.getSQLState())) {
                                    throw sqlEx;
                                }
                            }
                            try {
                                Thread.sleep(250L);
                            }
                            catch (InterruptedException ex2) {}
                            break Label_0150;
                        }
                        return conn;
                    }
                    ++attempts;
                    continue;
                }
                return conn;
            }
            if (ex != null) {
                throw ex;
            }
            return null;
        }
    }
    
    interface BalanceStrategy
    {
        Connection pickConnection() throws SQLException;
    }
}
