// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.log;

import java.sql.SQLException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import com.mysql.jdbc.SQLError;

public class LogFactory
{
    public static Log getLogger(final String className, final String instanceName) throws SQLException {
        if (className == null) {
            throw SQLError.createSQLException("Logger class can not be NULL", "S1009");
        }
        if (instanceName == null) {
            throw SQLError.createSQLException("Logger instance name can not be NULL", "S1009");
        }
        try {
            Class loggerClass = null;
            try {
                loggerClass = Class.forName(className);
            }
            catch (ClassNotFoundException nfe) {
                loggerClass = Class.forName(Log.class.getPackage().getName() + "." + className);
            }
            final Constructor constructor = loggerClass.getConstructor(String.class);
            return constructor.newInstance(instanceName);
        }
        catch (ClassNotFoundException cnfe) {
            throw SQLError.createSQLException("Unable to load class for logger '" + className + "'", "S1009");
        }
        catch (NoSuchMethodException nsme) {
            throw SQLError.createSQLException("Logger class does not have a single-arg constructor that takes an instance name", "S1009");
        }
        catch (InstantiationException inse) {
            throw SQLError.createSQLException("Unable to instantiate logger class '" + className + "', exception in constructor?", "S1009");
        }
        catch (InvocationTargetException ite) {
            throw SQLError.createSQLException("Unable to instantiate logger class '" + className + "', exception in constructor?", "S1009");
        }
        catch (IllegalAccessException iae) {
            throw SQLError.createSQLException("Unable to instantiate logger class '" + className + "', constructor not public", "S1009");
        }
        catch (ClassCastException cce) {
            throw SQLError.createSQLException("Logger class '" + className + "' does not implement the '" + Log.class.getName() + "' interface", "S1009");
        }
    }
}
