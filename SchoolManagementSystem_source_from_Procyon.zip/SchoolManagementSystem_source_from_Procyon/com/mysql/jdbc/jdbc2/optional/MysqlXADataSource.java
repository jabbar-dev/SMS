// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.jdbc2.optional;

import java.sql.SQLException;
import java.sql.Connection;
import javax.sql.XAConnection;
import javax.sql.XADataSource;

public class MysqlXADataSource extends MysqlDataSource implements XADataSource
{
    public XAConnection getXAConnection() throws SQLException {
        final Connection conn = this.getConnection();
        return this.wrapConnection(conn);
    }
    
    public XAConnection getXAConnection(final String user, final String password) throws SQLException {
        final Connection conn = this.getConnection(user, password);
        return this.wrapConnection(conn);
    }
    
    private XAConnection wrapConnection(final Connection conn) throws SQLException {
        if (this.getPinGlobalTxToPhysicalConnection() || ((com.mysql.jdbc.Connection)conn).getPinGlobalTxToPhysicalConnection()) {
            return new SuspendableXAConnection((com.mysql.jdbc.Connection)conn);
        }
        return new MysqlXAConnection((com.mysql.jdbc.Connection)conn, this.getLogXaCommands());
    }
}
