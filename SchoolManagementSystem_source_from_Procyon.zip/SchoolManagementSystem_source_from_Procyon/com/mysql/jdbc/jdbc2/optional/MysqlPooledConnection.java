// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.jdbc2.optional;

import java.util.Enumeration;
import javax.sql.ConnectionEvent;
import com.mysql.jdbc.SQLError;
import java.sql.SQLException;
import javax.sql.ConnectionEventListener;
import java.sql.Connection;
import java.util.Hashtable;
import javax.sql.PooledConnection;

public class MysqlPooledConnection implements PooledConnection
{
    public static final int CONNECTION_ERROR_EVENT = 1;
    public static final int CONNECTION_CLOSED_EVENT = 2;
    private Hashtable eventListeners;
    private Connection logicalHandle;
    private com.mysql.jdbc.Connection physicalConn;
    
    public MysqlPooledConnection(final com.mysql.jdbc.Connection connection) {
        this.logicalHandle = null;
        this.physicalConn = connection;
        this.eventListeners = new Hashtable(10);
    }
    
    public synchronized void addConnectionEventListener(final ConnectionEventListener connectioneventlistener) {
        if (this.eventListeners != null) {
            this.eventListeners.put(connectioneventlistener, connectioneventlistener);
        }
    }
    
    public synchronized void removeConnectionEventListener(final ConnectionEventListener connectioneventlistener) {
        if (this.eventListeners != null) {
            this.eventListeners.remove(connectioneventlistener);
        }
    }
    
    public synchronized Connection getConnection() throws SQLException {
        return this.getConnection(true, false);
    }
    
    protected synchronized Connection getConnection(final boolean resetServerState, final boolean forXa) throws SQLException {
        SQLException sqlException = null;
        if (this.physicalConn == null) {
            sqlException = SQLError.createSQLException("Physical Connection doesn't exist");
            this.callListener(1, sqlException);
            throw sqlException;
        }
        try {
            if (this.logicalHandle != null) {
                ((ConnectionWrapper)this.logicalHandle).close(false);
            }
            if (resetServerState) {
                this.physicalConn.resetServerState();
            }
            this.logicalHandle = new ConnectionWrapper(this, this.physicalConn, forXa);
        }
        catch (SQLException sqlException) {
            this.callListener(1, sqlException);
            throw sqlException;
        }
        return this.logicalHandle;
    }
    
    public synchronized void close() throws SQLException {
        if (this.physicalConn != null) {
            this.physicalConn.close();
        }
        this.physicalConn = null;
    }
    
    protected synchronized void callListener(final int eventType, final SQLException sqlException) {
        if (this.eventListeners == null) {
            return;
        }
        final Enumeration enumeration = this.eventListeners.keys();
        final ConnectionEvent connectionevent = new ConnectionEvent(this, sqlException);
        while (enumeration.hasMoreElements()) {
            final ConnectionEventListener connectioneventlistener = enumeration.nextElement();
            final ConnectionEventListener connectioneventlistener2 = this.eventListeners.get(connectioneventlistener);
            if (eventType == 2) {
                connectioneventlistener2.connectionClosed(connectionevent);
            }
            else {
                if (eventType != 1) {
                    continue;
                }
                connectioneventlistener2.connectionErrorOccurred(connectionevent);
            }
        }
    }
}
