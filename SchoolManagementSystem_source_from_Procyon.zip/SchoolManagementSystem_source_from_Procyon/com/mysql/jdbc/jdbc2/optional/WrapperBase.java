// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.jdbc2.optional;

import java.sql.SQLException;

abstract class WrapperBase
{
    protected MysqlPooledConnection pooledConnection;
    
    protected void checkAndFireConnectionError(final SQLException sqlEx) throws SQLException {
        if (this.pooledConnection != null && "08S01".equals(sqlEx.getSQLState())) {
            this.pooledConnection.callListener(1, sqlEx);
        }
        throw sqlEx;
    }
}
