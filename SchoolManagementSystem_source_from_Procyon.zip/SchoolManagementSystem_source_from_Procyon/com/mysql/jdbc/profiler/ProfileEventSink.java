// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.profiler;

import java.util.HashMap;
import java.sql.SQLException;
import com.mysql.jdbc.log.Log;
import com.mysql.jdbc.Connection;
import java.util.Map;

public class ProfileEventSink
{
    private static final Map CONNECTIONS_TO_SINKS;
    private Connection ownerConnection;
    private Log log;
    
    public static synchronized ProfileEventSink getInstance(final Connection conn) {
        ProfileEventSink sink = ProfileEventSink.CONNECTIONS_TO_SINKS.get(conn);
        if (sink == null) {
            sink = new ProfileEventSink(conn);
            ProfileEventSink.CONNECTIONS_TO_SINKS.put(conn, sink);
        }
        return sink;
    }
    
    public void consumeEvent(final ProfilerEvent evt) {
        if (evt.eventType == 0) {
            this.log.logWarn(evt);
        }
        else {
            this.log.logInfo(evt);
        }
    }
    
    public static synchronized void removeInstance(final Connection conn) {
        ProfileEventSink.CONNECTIONS_TO_SINKS.remove(conn);
    }
    
    private ProfileEventSink(final Connection conn) {
        this.ownerConnection = null;
        this.log = null;
        this.ownerConnection = conn;
        try {
            this.log = this.ownerConnection.getLog();
        }
        catch (SQLException sqlEx) {
            throw new RuntimeException("Unable to get logger from connection");
        }
    }
    
    static {
        CONNECTIONS_TO_SINKS = new HashMap();
    }
}
