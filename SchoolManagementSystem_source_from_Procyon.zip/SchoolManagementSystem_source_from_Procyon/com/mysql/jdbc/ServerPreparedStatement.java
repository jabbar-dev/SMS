// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.TimeZone;
import java.sql.Ref;
import java.sql.Clob;
import java.math.BigDecimal;
import java.sql.Array;
import java.io.Reader;
import java.sql.Blob;
import com.mysql.jdbc.profiler.ProfileEventSink;
import com.mysql.jdbc.profiler.ProfilerEvent;
import com.mysql.jdbc.exceptions.MySQLTimeoutException;
import java.util.TimerTask;
import java.sql.ParameterMetaData;
import java.sql.ResultSetMetaData;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.BatchUpdateException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.sql.Time;
import java.sql.SQLException;

public class ServerPreparedStatement extends PreparedStatement
{
    protected static final int BLOB_STREAM_READ_BUF_SIZE = 8192;
    private static final byte MAX_DATE_REP_LENGTH = 5;
    private static final byte MAX_DATETIME_REP_LENGTH = 12;
    private static final byte MAX_TIME_REP_LENGTH = 13;
    private boolean detectedLongParameterSwitch;
    private int fieldCount;
    private boolean invalid;
    private SQLException invalidationException;
    private boolean isSelectQuery;
    private Buffer outByteBuffer;
    private BindValue[] parameterBindings;
    private Field[] parameterFields;
    private Field[] resultFields;
    private boolean sendTypesToServer;
    private long serverStatementId;
    private int stringTypeCode;
    private boolean serverNeedsResetBeforeEachExecution;
    protected boolean isCached;
    
    private void storeTime(final Buffer intoBuf, final Time tm) throws SQLException {
        intoBuf.ensureCapacity(9);
        intoBuf.writeByte((byte)8);
        intoBuf.writeByte((byte)0);
        intoBuf.writeLong(0L);
        final Calendar sessionCalendar = this.getCalendarInstanceForSessionOrNew();
        synchronized (sessionCalendar) {
            final Date oldTime = sessionCalendar.getTime();
            try {
                sessionCalendar.setTime(tm);
                intoBuf.writeByte((byte)sessionCalendar.get(11));
                intoBuf.writeByte((byte)sessionCalendar.get(12));
                intoBuf.writeByte((byte)sessionCalendar.get(13));
            }
            finally {
                sessionCalendar.setTime(oldTime);
            }
        }
    }
    
    public ServerPreparedStatement(final Connection conn, final String sql, final String catalog, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        super(conn, catalog);
        this.detectedLongParameterSwitch = false;
        this.invalid = false;
        this.sendTypesToServer = false;
        this.stringTypeCode = 254;
        this.isCached = false;
        this.checkNullOrEmptyQuery(sql);
        this.isSelectQuery = StringUtils.startsWithIgnoreCaseAndWs(sql, "SELECT");
        if (this.connection.versionMeetsMinimum(5, 0, 0)) {
            this.serverNeedsResetBeforeEachExecution = !this.connection.versionMeetsMinimum(5, 0, 3);
        }
        else {
            this.serverNeedsResetBeforeEachExecution = !this.connection.versionMeetsMinimum(4, 1, 10);
        }
        this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
        this.hasLimitClause = (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1);
        this.firstCharOfStmt = StringUtils.firstNonWsCharUc(sql);
        this.originalSql = sql;
        if (this.connection.versionMeetsMinimum(4, 1, 2)) {
            this.stringTypeCode = 253;
        }
        else {
            this.stringTypeCode = 254;
        }
        try {
            this.serverPrepare(sql);
        }
        catch (SQLException sqlEx) {
            this.realClose(false, true);
            throw sqlEx;
        }
        catch (Exception ex) {
            this.realClose(false, true);
            throw SQLError.createSQLException(ex.toString(), "S1000");
        }
        this.setResultSetType(resultSetType);
        this.setResultSetConcurrency(resultSetConcurrency);
    }
    
    public synchronized void addBatch() throws SQLException {
        this.checkClosed();
        if (this.batchedArgs == null) {
            this.batchedArgs = new ArrayList();
        }
        this.batchedArgs.add(new BatchedBindValues(this.parameterBindings));
    }
    
    protected String asSql(final boolean quoteStreamsAndUnknowns) throws SQLException {
        if (this.isClosed) {
            return "statement has been closed, no further internal information available";
        }
        PreparedStatement pStmtForSub = null;
        try {
            pStmtForSub = new PreparedStatement(this.connection, this.originalSql, this.currentCatalog);
            for (int numParameters = pStmtForSub.parameterCount, ourNumParameters = this.parameterCount, i = 0; i < numParameters && i < ourNumParameters; ++i) {
                if (this.parameterBindings[i] != null) {
                    if (this.parameterBindings[i].isNull) {
                        pStmtForSub.setNull(i + 1, 0);
                    }
                    else {
                        final BindValue bindValue = this.parameterBindings[i];
                        switch (bindValue.bufferType) {
                            case 0: {
                                pStmtForSub.setByte(i + 1, bindValue.byteBinding);
                                break;
                            }
                            case 1: {
                                pStmtForSub.setShort(i + 1, bindValue.shortBinding);
                                break;
                            }
                            case 2: {
                                pStmtForSub.setInt(i + 1, bindValue.intBinding);
                                break;
                            }
                            case 7: {
                                pStmtForSub.setLong(i + 1, bindValue.longBinding);
                                break;
                            }
                            case 3: {
                                pStmtForSub.setFloat(i + 1, bindValue.floatBinding);
                                break;
                            }
                            case 4: {
                                pStmtForSub.setDouble(i + 1, bindValue.doubleBinding);
                                break;
                            }
                            default: {
                                pStmtForSub.setObject(i + 1, this.parameterBindings[i].value);
                                break;
                            }
                        }
                    }
                }
            }
            return pStmtForSub.asSql(quoteStreamsAndUnknowns);
        }
        finally {
            if (pStmtForSub != null) {
                try {
                    pStmtForSub.close();
                }
                catch (SQLException ex) {}
            }
        }
    }
    
    protected void checkClosed() throws SQLException {
        if (this.invalid) {
            throw this.invalidationException;
        }
        super.checkClosed();
    }
    
    public void clearParameters() throws SQLException {
        this.checkClosed();
        this.clearParametersInternal(true);
    }
    
    private void clearParametersInternal(final boolean clearServerParameters) throws SQLException {
        boolean hadLongData = false;
        if (this.parameterBindings != null) {
            for (int i = 0; i < this.parameterCount; ++i) {
                if (this.parameterBindings[i] != null && this.parameterBindings[i].isLongData) {
                    hadLongData = true;
                }
                this.parameterBindings[i].reset();
            }
        }
        if (clearServerParameters && hadLongData) {
            this.serverResetStatement();
            this.detectedLongParameterSwitch = false;
        }
    }
    
    protected void setClosed(final boolean flag) {
        this.isClosed = flag;
    }
    
    public void close() throws SQLException {
        if (this.isCached) {
            this.isClosed = true;
            this.connection.recachePreparedStatement(this);
            return;
        }
        this.realClose(true, true);
    }
    
    private void dumpCloseForTestcase() {
        final StringBuffer buf = new StringBuffer();
        this.connection.generateConnectionCommentBlock(buf);
        buf.append("DEALLOCATE PREPARE debug_stmt_");
        buf.append(this.statementId);
        buf.append(";\n");
        this.connection.dumpTestcaseQuery(buf.toString());
    }
    
    private void dumpExecuteForTestcase() throws SQLException {
        final StringBuffer buf = new StringBuffer();
        for (int i = 0; i < this.parameterCount; ++i) {
            this.connection.generateConnectionCommentBlock(buf);
            buf.append("SET @debug_stmt_param");
            buf.append(this.statementId);
            buf.append("_");
            buf.append(i);
            buf.append("=");
            if (this.parameterBindings[i].isNull) {
                buf.append("NULL");
            }
            else {
                buf.append(this.parameterBindings[i].toString(true));
            }
            buf.append(";\n");
        }
        this.connection.generateConnectionCommentBlock(buf);
        buf.append("EXECUTE debug_stmt_");
        buf.append(this.statementId);
        if (this.parameterCount > 0) {
            buf.append(" USING ");
            for (int i = 0; i < this.parameterCount; ++i) {
                if (i > 0) {
                    buf.append(", ");
                }
                buf.append("@debug_stmt_param");
                buf.append(this.statementId);
                buf.append("_");
                buf.append(i);
            }
        }
        buf.append(";\n");
        this.connection.dumpTestcaseQuery(buf.toString());
    }
    
    private void dumpPrepareForTestcase() throws SQLException {
        final StringBuffer buf = new StringBuffer(this.originalSql.length() + 64);
        this.connection.generateConnectionCommentBlock(buf);
        buf.append("PREPARE debug_stmt_");
        buf.append(this.statementId);
        buf.append(" FROM \"");
        buf.append(this.originalSql);
        buf.append("\";\n");
        this.connection.dumpTestcaseQuery(buf.toString());
    }
    
    public synchronized int[] executeBatchSerially() throws SQLException {
        if (this.connection.isReadOnly()) {
            throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.2") + Messages.getString("ServerPreparedStatement.3"), "S1009");
        }
        this.checkClosed();
        synchronized (this.connection.getMutex()) {
            this.clearWarnings();
            final BindValue[] oldBindValues = this.parameterBindings;
            try {
                int[] updateCounts = null;
                if (this.batchedArgs != null) {
                    final int nbrCommands = this.batchedArgs.size();
                    updateCounts = new int[nbrCommands];
                    if (this.retrieveGeneratedKeys) {
                        this.batchedGeneratedKeys = new ArrayList(nbrCommands);
                    }
                    for (int i = 0; i < nbrCommands; ++i) {
                        updateCounts[i] = -3;
                    }
                    SQLException sqlEx = null;
                    int commandIndex = 0;
                    BindValue[] previousBindValuesForBatch = null;
                    for (commandIndex = 0; commandIndex < nbrCommands; ++commandIndex) {
                        final Object arg = this.batchedArgs.get(commandIndex);
                        if (arg instanceof String) {
                            updateCounts[commandIndex] = this.executeUpdate((String)arg);
                        }
                        else {
                            this.parameterBindings = ((BatchedBindValues)arg).batchedParameterValues;
                            try {
                                if (previousBindValuesForBatch != null) {
                                    for (int j = 0; j < this.parameterBindings.length; ++j) {
                                        if (this.parameterBindings[j].bufferType != previousBindValuesForBatch[j].bufferType) {
                                            this.sendTypesToServer = true;
                                            break;
                                        }
                                    }
                                }
                                try {
                                    updateCounts[commandIndex] = this.executeUpdate(false, true);
                                }
                                finally {
                                    previousBindValuesForBatch = this.parameterBindings;
                                }
                                if (this.retrieveGeneratedKeys) {
                                    ResultSet rs = null;
                                    try {
                                        rs = this.getGeneratedKeysInternal();
                                        while (rs.next()) {
                                            this.batchedGeneratedKeys.add(new byte[][] { rs.getBytes(1) });
                                        }
                                    }
                                    finally {
                                        if (rs != null) {
                                            rs.close();
                                        }
                                    }
                                }
                            }
                            catch (SQLException ex) {
                                updateCounts[commandIndex] = -3;
                                if (!this.continueBatchOnError) {
                                    final int[] newUpdateCounts = new int[commandIndex];
                                    System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
                                    throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
                                }
                                sqlEx = ex;
                            }
                        }
                    }
                    if (sqlEx != null) {
                        throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
                    }
                }
                return (updateCounts != null) ? updateCounts : new int[0];
            }
            finally {
                this.parameterBindings = oldBindValues;
                this.sendTypesToServer = true;
                this.clearBatch();
            }
        }
    }
    
    protected com.mysql.jdbc.ResultSet executeInternal(final int maxRowsToRetrieve, final Buffer sendPacket, final boolean createStreamingResultSet, final boolean queryIsSelectOnly, final boolean unpackFields, final Field[] metadataFromCache, final boolean isBatch) throws SQLException {
        ++this.numberOfExecutions;
        try {
            return this.serverExecute(maxRowsToRetrieve, createStreamingResultSet, unpackFields, metadataFromCache);
        }
        catch (SQLException sqlEx) {
            if (this.connection.getEnablePacketDebug()) {
                this.connection.getIO().dumpPacketRingBuffer();
            }
            if (this.connection.getDumpQueriesOnException()) {
                final String extractedSql = this.toString();
                final StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);
                messageBuf.append("\n\nQuery being executed when exception was thrown:\n\n");
                messageBuf.append(extractedSql);
                sqlEx = Connection.appendMessageToException(sqlEx, messageBuf.toString());
            }
            throw sqlEx;
        }
        catch (Exception ex) {
            if (this.connection.getEnablePacketDebug()) {
                this.connection.getIO().dumpPacketRingBuffer();
            }
            SQLException sqlEx2 = SQLError.createSQLException(ex.toString(), "S1000");
            if (this.connection.getDumpQueriesOnException()) {
                final String extractedSql2 = this.toString();
                final StringBuffer messageBuf2 = new StringBuffer(extractedSql2.length() + 32);
                messageBuf2.append("\n\nQuery being executed when exception was thrown:\n\n");
                messageBuf2.append(extractedSql2);
                sqlEx2 = Connection.appendMessageToException(sqlEx2, messageBuf2.toString());
            }
            throw sqlEx2;
        }
    }
    
    protected Buffer fillSendPacket() throws SQLException {
        return null;
    }
    
    protected Buffer fillSendPacket(final byte[][] batchedParameterStrings, final InputStream[] batchedParameterStreams, final boolean[] batchedIsStream, final int[] batchedStreamLengths) throws SQLException {
        return null;
    }
    
    private BindValue getBinding(int parameterIndex, final boolean forLongData) throws SQLException {
        this.checkClosed();
        if (this.parameterBindings.length == 0) {
            throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.8"), "S1009");
        }
        if (--parameterIndex < 0 || parameterIndex >= this.parameterBindings.length) {
            throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.9") + (parameterIndex + 1) + Messages.getString("ServerPreparedStatement.10") + this.parameterBindings.length, "S1009");
        }
        if (this.parameterBindings[parameterIndex] == null) {
            this.parameterBindings[parameterIndex] = new BindValue();
        }
        else if (this.parameterBindings[parameterIndex].isLongData && !forLongData) {
            this.detectedLongParameterSwitch = true;
        }
        this.parameterBindings[parameterIndex].isSet = true;
        this.parameterBindings[parameterIndex].boundBeforeExecutionNum = this.numberOfExecutions;
        return this.parameterBindings[parameterIndex];
    }
    
    byte[] getBytes(final int parameterIndex) throws SQLException {
        final BindValue bindValue = this.getBinding(parameterIndex, false);
        if (bindValue.isNull) {
            return null;
        }
        if (bindValue.isLongData) {
            throw new NotImplemented();
        }
        if (this.outByteBuffer == null) {
            this.outByteBuffer = new Buffer(this.connection.getNetBufferLength());
        }
        this.outByteBuffer.clear();
        final int originalPosition = this.outByteBuffer.getPosition();
        this.storeBinding(this.outByteBuffer, bindValue, this.connection.getIO());
        final int newPosition = this.outByteBuffer.getPosition();
        final int length = newPosition - originalPosition;
        final byte[] valueAsBytes = new byte[length];
        System.arraycopy(this.outByteBuffer.getByteBuffer(), originalPosition, valueAsBytes, 0, length);
        return valueAsBytes;
    }
    
    public ResultSetMetaData getMetaData() throws SQLException {
        this.checkClosed();
        if (this.resultFields == null) {
            return null;
        }
        return new com.mysql.jdbc.ResultSetMetaData(this.resultFields, this.connection.getUseOldAliasMetadataBehavior());
    }
    
    public ParameterMetaData getParameterMetaData() throws SQLException {
        this.checkClosed();
        if (this.parameterMetaData == null) {
            this.parameterMetaData = new MysqlParameterMetadata(this.parameterFields, this.parameterCount);
        }
        return this.parameterMetaData;
    }
    
    boolean isNull(final int paramIndex) {
        throw new IllegalArgumentException(Messages.getString("ServerPreparedStatement.7"));
    }
    
    protected void realClose(final boolean calledExplicitly, final boolean closeOpenResults) throws SQLException {
        if (this.isClosed) {
            return;
        }
        if (this.connection != null) {
            if (this.connection.getAutoGenerateTestcaseScript()) {
                this.dumpCloseForTestcase();
            }
            synchronized (this.connection.getMutex()) {
                SQLException exceptionDuringClose = null;
                if (calledExplicitly) {
                    try {
                        final MysqlIO mysql = this.connection.getIO();
                        final Buffer packet = mysql.getSharedSendPacket();
                        packet.writeByte((byte)25);
                        packet.writeLong(this.serverStatementId);
                        mysql.sendCommand(25, null, packet, true, null);
                    }
                    catch (SQLException sqlEx) {
                        exceptionDuringClose = sqlEx;
                    }
                }
                super.realClose(calledExplicitly, closeOpenResults);
                this.clearParametersInternal(false);
                this.parameterBindings = null;
                this.parameterFields = null;
                this.resultFields = null;
                if (exceptionDuringClose != null) {
                    throw exceptionDuringClose;
                }
            }
        }
    }
    
    protected void rePrepare() throws SQLException {
        this.invalidationException = null;
        try {
            this.serverPrepare(this.originalSql);
        }
        catch (SQLException sqlEx) {
            this.invalidationException = sqlEx;
        }
        catch (Exception ex) {
            this.invalidationException = SQLError.createSQLException(ex.toString(), "S1000");
        }
        if (this.invalidationException != null) {
            this.invalid = true;
            this.parameterBindings = null;
            this.parameterFields = null;
            this.resultFields = null;
            if (this.results != null) {
                try {
                    this.results.close();
                }
                catch (Exception ex2) {}
            }
            if (this.connection != null) {
                if (this.maxRowsChanged) {
                    this.connection.unsetMaxRows(this);
                }
                if (!this.connection.getDontTrackOpenResources()) {
                    this.connection.unregisterStatement(this);
                }
            }
        }
    }
    
    private com.mysql.jdbc.ResultSet serverExecute(final int maxRowsToRetrieve, final boolean createStreamingResultSet, final boolean unpackFields, final Field[] metadataFromCache) throws SQLException {
        synchronized (this.connection.getMutex()) {
            if (this.detectedLongParameterSwitch) {
                boolean firstFound = false;
                long boundTimeToCheck = 0L;
                for (int i = 0; i < this.parameterCount - 1; ++i) {
                    if (this.parameterBindings[i].isLongData) {
                        if (firstFound && boundTimeToCheck != this.parameterBindings[i].boundBeforeExecutionNum) {
                            throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.11") + Messages.getString("ServerPreparedStatement.12"), "S1C00");
                        }
                        firstFound = true;
                        boundTimeToCheck = this.parameterBindings[i].boundBeforeExecutionNum;
                    }
                }
                this.serverResetStatement();
            }
            for (int j = 0; j < this.parameterCount; ++j) {
                if (!this.parameterBindings[j].isSet) {
                    throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.13") + (j + 1) + Messages.getString("ServerPreparedStatement.14"), "S1009");
                }
            }
            for (int j = 0; j < this.parameterCount; ++j) {
                if (this.parameterBindings[j].isLongData) {
                    this.serverLongData(j, this.parameterBindings[j]);
                }
            }
            if (this.connection.getAutoGenerateTestcaseScript()) {
                this.dumpExecuteForTestcase();
            }
            final MysqlIO mysql = this.connection.getIO();
            final Buffer packet = mysql.getSharedSendPacket();
            packet.clear();
            packet.writeByte((byte)23);
            packet.writeLong(this.serverStatementId);
            boolean usingCursor = false;
            if (this.connection.versionMeetsMinimum(4, 1, 2)) {
                if (this.resultFields != null && this.connection.isCursorFetchEnabled() && this.getResultSetType() == 1003 && this.getResultSetConcurrency() == 1007 && this.getFetchSize() > 0) {
                    packet.writeByte((byte)1);
                    usingCursor = true;
                }
                else {
                    packet.writeByte((byte)0);
                }
                packet.writeLong(1L);
            }
            final int nullCount = (this.parameterCount + 7) / 8;
            final int nullBitsPosition = packet.getPosition();
            for (int k = 0; k < nullCount; ++k) {
                packet.writeByte((byte)0);
            }
            final byte[] nullBitsBuffer = new byte[nullCount];
            packet.writeByte((byte)(this.sendTypesToServer ? 1 : 0));
            if (this.sendTypesToServer) {
                for (int l = 0; l < this.parameterCount; ++l) {
                    packet.writeInt(this.parameterBindings[l].bufferType);
                }
            }
            for (int l = 0; l < this.parameterCount; ++l) {
                if (!this.parameterBindings[l].isLongData) {
                    if (!this.parameterBindings[l].isNull) {
                        this.storeBinding(packet, this.parameterBindings[l], mysql);
                    }
                    else {
                        final byte[] array = nullBitsBuffer;
                        final int n = l / 8;
                        array[n] |= (byte)(1 << (l & 0x7));
                    }
                }
            }
            final int endPosition = packet.getPosition();
            packet.setPosition(nullBitsPosition);
            packet.writeBytesNoNull(nullBitsBuffer);
            packet.setPosition(endPosition);
            long begin = 0L;
            final boolean logSlowQueries = this.connection.getLogSlowQueries();
            final boolean gatherPerformanceMetrics = this.connection.getGatherPerformanceMetrics();
            if (this.profileSQL || logSlowQueries || gatherPerformanceMetrics) {
                begin = mysql.getCurrentTimeNanosOrMillis();
            }
            synchronized (this.cancelTimeoutMutex) {
                this.wasCancelled = false;
            }
            CancelTask timeoutTask = null;
            try {
                if (this.connection.getEnableQueryTimeouts() && this.timeoutInMillis != 0 && this.connection.versionMeetsMinimum(5, 0, 0)) {
                    timeoutTask = new CancelTask();
                    final Connection connection = this.connection;
                    Connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
                }
                final Buffer resultPacket = mysql.sendCommand(23, null, packet, false, null);
                long queryEndTime = 0L;
                if (logSlowQueries || gatherPerformanceMetrics || this.profileSQL) {
                    queryEndTime = mysql.getCurrentTimeNanosOrMillis();
                }
                if (timeoutTask != null) {
                    timeoutTask.cancel();
                    if (timeoutTask.caughtWhileCancelling != null) {
                        throw timeoutTask.caughtWhileCancelling;
                    }
                    timeoutTask = null;
                }
                synchronized (this.cancelTimeoutMutex) {
                    if (this.wasCancelled) {
                        this.wasCancelled = false;
                        throw new MySQLTimeoutException();
                    }
                }
                boolean queryWasSlow = false;
                if (logSlowQueries || gatherPerformanceMetrics) {
                    final long elapsedTime = queryEndTime - begin;
                    if (logSlowQueries && elapsedTime >= mysql.getSlowQueryThreshold()) {
                        queryWasSlow = true;
                        final StringBuffer mesgBuf = new StringBuffer(48 + this.originalSql.length());
                        mesgBuf.append(Messages.getString("ServerPreparedStatement.15"));
                        mesgBuf.append(mysql.getSlowQueryThreshold());
                        mesgBuf.append(Messages.getString("ServerPreparedStatement.15a"));
                        mesgBuf.append(elapsedTime);
                        mesgBuf.append(Messages.getString("ServerPreparedStatement.16"));
                        mesgBuf.append("as prepared: ");
                        mesgBuf.append(this.originalSql);
                        mesgBuf.append("\n\n with parameters bound:\n\n");
                        mesgBuf.append(this.asSql(true));
                        this.eventSink.consumeEvent(new ProfilerEvent((byte)6, "", this.currentCatalog, this.connection.getId(), this.getId(), 0, System.currentTimeMillis(), elapsedTime, mysql.getQueryTimingUnits(), null, new Throwable(), mesgBuf.toString()));
                    }
                    if (gatherPerformanceMetrics) {
                        this.connection.registerQueryExecutionTime(elapsedTime);
                    }
                }
                this.connection.incrementNumberOfPreparedExecutes();
                if (this.profileSQL) {
                    (this.eventSink = ProfileEventSink.getInstance(this.connection)).consumeEvent(new ProfilerEvent((byte)4, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), (int)(mysql.getCurrentTimeNanosOrMillis() - begin), mysql.getQueryTimingUnits(), null, new Throwable(), this.truncateQueryToLog(this.asSql(true))));
                }
                final com.mysql.jdbc.ResultSet rs = mysql.readAllResults(this, maxRowsToRetrieve, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, resultPacket, true, this.fieldCount, unpackFields, metadataFromCache);
                if (this.profileSQL) {
                    final long fetchEndTime = mysql.getCurrentTimeNanosOrMillis();
                    this.eventSink.consumeEvent(new ProfilerEvent((byte)5, "", this.currentCatalog, this.connection.getId(), this.getId(), rs.resultId, System.currentTimeMillis(), fetchEndTime - queryEndTime, mysql.getQueryTimingUnits(), null, new Throwable(), null));
                }
                if (queryWasSlow && this.connection.getExplainSlowQueries()) {
                    final String queryAsString = this.asSql(true);
                    mysql.explainSlowQuery(queryAsString.getBytes(), queryAsString);
                }
                if (!createStreamingResultSet && this.serverNeedsResetBeforeEachExecution) {
                    this.serverResetStatement();
                }
                this.sendTypesToServer = false;
                this.results = rs;
                if (mysql.hadWarnings()) {
                    mysql.scanForAndThrowDataTruncation();
                }
                return rs;
            }
            finally {
                if (timeoutTask != null) {
                    timeoutTask.cancel();
                }
            }
        }
    }
    
    private void serverLongData(final int parameterIndex, final BindValue longData) throws SQLException {
        synchronized (this.connection.getMutex()) {
            final MysqlIO mysql = this.connection.getIO();
            final Buffer packet = mysql.getSharedSendPacket();
            final Object value = longData.value;
            if (value instanceof byte[]) {
                packet.clear();
                packet.writeByte((byte)24);
                packet.writeLong(this.serverStatementId);
                packet.writeInt(parameterIndex);
                packet.writeBytesNoNull((byte[])longData.value);
                mysql.sendCommand(24, null, packet, true, null);
            }
            else if (value instanceof InputStream) {
                this.storeStream(mysql, parameterIndex, packet, (InputStream)value);
            }
            else if (value instanceof Blob) {
                this.storeStream(mysql, parameterIndex, packet, ((Blob)value).getBinaryStream());
            }
            else {
                if (!(value instanceof Reader)) {
                    throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.18") + value.getClass().getName() + "'", "S1009");
                }
                this.storeReader(mysql, parameterIndex, packet, (Reader)value);
            }
        }
    }
    
    private void serverPrepare(final String sql) throws SQLException {
        synchronized (this.connection.getMutex()) {
            final MysqlIO mysql = this.connection.getIO();
            if (this.connection.getAutoGenerateTestcaseScript()) {
                this.dumpPrepareForTestcase();
            }
            try {
                long begin = 0L;
                if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA")) {
                    this.isLoadDataQuery = true;
                }
                else {
                    this.isLoadDataQuery = false;
                }
                if (this.connection.getProfileSql()) {
                    begin = mysql.getCurrentTimeNanosOrMillis();
                }
                String characterEncoding = null;
                final String connectionEncoding = this.connection.getEncoding();
                if (!this.isLoadDataQuery && this.connection.getUseUnicode() && connectionEncoding != null) {
                    characterEncoding = connectionEncoding;
                }
                final Buffer prepareResultPacket = mysql.sendCommand(22, sql, null, false, characterEncoding);
                if (this.connection.versionMeetsMinimum(4, 1, 1)) {
                    prepareResultPacket.setPosition(1);
                }
                else {
                    prepareResultPacket.setPosition(0);
                }
                this.serverStatementId = prepareResultPacket.readLong();
                this.fieldCount = prepareResultPacket.readInt();
                this.parameterCount = prepareResultPacket.readInt();
                this.parameterBindings = new BindValue[this.parameterCount];
                for (int i = 0; i < this.parameterCount; ++i) {
                    this.parameterBindings[i] = new BindValue();
                }
                this.connection.incrementNumberOfPrepares();
                if (this.profileSQL) {
                    this.eventSink.consumeEvent(new ProfilerEvent((byte)2, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), mysql.getCurrentTimeNanosOrMillis() - begin, mysql.getQueryTimingUnits(), null, new Throwable(), this.truncateQueryToLog(sql)));
                }
                if (this.parameterCount > 0 && this.connection.versionMeetsMinimum(4, 1, 2) && !mysql.isVersion(5, 0, 0)) {
                    this.parameterFields = new Field[this.parameterCount];
                    Buffer metaDataPacket = mysql.readPacket();
                    for (int j = 0; !metaDataPacket.isLastDataPacket() && j < this.parameterCount; this.parameterFields[j++] = mysql.unpackField(metaDataPacket, false), metaDataPacket = mysql.readPacket()) {}
                }
                if (this.fieldCount > 0) {
                    this.resultFields = new Field[this.fieldCount];
                    Buffer fieldPacket = mysql.readPacket();
                    for (int j = 0; !fieldPacket.isLastDataPacket() && j < this.fieldCount; this.resultFields[j++] = mysql.unpackField(fieldPacket, false), fieldPacket = mysql.readPacket()) {}
                }
            }
            catch (SQLException sqlEx) {
                if (this.connection.getDumpQueriesOnException()) {
                    final StringBuffer messageBuf = new StringBuffer(this.originalSql.length() + 32);
                    messageBuf.append("\n\nQuery being prepared when exception was thrown:\n\n");
                    messageBuf.append(this.originalSql);
                    sqlEx = Connection.appendMessageToException(sqlEx, messageBuf.toString());
                }
                throw sqlEx;
            }
            finally {
                this.connection.getIO().clearInputStream();
            }
        }
    }
    
    private String truncateQueryToLog(final String sql) {
        String query = null;
        if (sql.length() > this.connection.getMaxQuerySizeToLog()) {
            final StringBuffer queryBuf = new StringBuffer(this.connection.getMaxQuerySizeToLog() + 12);
            queryBuf.append(sql.substring(0, this.connection.getMaxQuerySizeToLog()));
            queryBuf.append(Messages.getString("MysqlIO.25"));
            query = queryBuf.toString();
        }
        else {
            query = sql;
        }
        return query;
    }
    
    private void serverResetStatement() throws SQLException {
        synchronized (this.connection.getMutex()) {
            final MysqlIO mysql = this.connection.getIO();
            final Buffer packet = mysql.getSharedSendPacket();
            packet.clear();
            packet.writeByte((byte)26);
            packet.writeLong(this.serverStatementId);
            try {
                mysql.sendCommand(26, null, packet, !this.connection.versionMeetsMinimum(4, 1, 2), null);
            }
            catch (SQLException sqlEx) {
                throw sqlEx;
            }
            catch (Exception ex) {
                throw SQLError.createSQLException(ex.toString(), "S1000");
            }
            finally {
                mysql.clearInputStream();
            }
        }
    }
    
    public void setArray(final int i, final Array x) throws SQLException {
        throw new NotImplemented();
    }
    
    public void setAsciiStream(final int parameterIndex, final InputStream x, final int length) throws SQLException {
        this.checkClosed();
        if (x == null) {
            this.setNull(parameterIndex, -2);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, true);
            this.setType(binding, 252);
            binding.value = x;
            binding.isNull = false;
            binding.isLongData = true;
            if (this.connection.getUseStreamLengthsInPrepStmts()) {
                binding.bindLength = length;
            }
            else {
                binding.bindLength = -1L;
            }
        }
    }
    
    public void setBigDecimal(final int parameterIndex, final BigDecimal x) throws SQLException {
        this.checkClosed();
        if (x == null) {
            this.setNull(parameterIndex, 3);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, false);
            if (this.connection.versionMeetsMinimum(5, 0, 3)) {
                this.setType(binding, 246);
            }
            else {
                this.setType(binding, this.stringTypeCode);
            }
            binding.value = StringUtils.fixDecimalExponent(StringUtils.consistentToString(x));
            binding.isNull = false;
            binding.isLongData = false;
        }
    }
    
    public void setBinaryStream(final int parameterIndex, final InputStream x, final int length) throws SQLException {
        this.checkClosed();
        if (x == null) {
            this.setNull(parameterIndex, -2);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, true);
            this.setType(binding, 252);
            binding.value = x;
            binding.isNull = false;
            binding.isLongData = true;
            if (this.connection.getUseStreamLengthsInPrepStmts()) {
                binding.bindLength = length;
            }
            else {
                binding.bindLength = -1L;
            }
        }
    }
    
    public void setBlob(final int parameterIndex, final Blob x) throws SQLException {
        this.checkClosed();
        if (x == null) {
            this.setNull(parameterIndex, -2);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, true);
            this.setType(binding, 252);
            binding.value = x;
            binding.isNull = false;
            binding.isLongData = true;
            if (this.connection.getUseStreamLengthsInPrepStmts()) {
                binding.bindLength = x.length();
            }
            else {
                binding.bindLength = -1L;
            }
        }
    }
    
    public void setBoolean(final int parameterIndex, final boolean x) throws SQLException {
        this.setByte(parameterIndex, (byte)(x ? 1 : 0));
    }
    
    public void setByte(final int parameterIndex, final byte x) throws SQLException {
        this.checkClosed();
        final BindValue binding = this.getBinding(parameterIndex, false);
        this.setType(binding, 1);
        binding.value = null;
        binding.byteBinding = x;
        binding.isNull = false;
        binding.isLongData = false;
    }
    
    public void setBytes(final int parameterIndex, final byte[] x) throws SQLException {
        this.checkClosed();
        if (x == null) {
            this.setNull(parameterIndex, -2);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, false);
            this.setType(binding, 253);
            binding.value = x;
            binding.isNull = false;
            binding.isLongData = false;
        }
    }
    
    public void setCharacterStream(final int parameterIndex, final Reader reader, final int length) throws SQLException {
        this.checkClosed();
        if (reader == null) {
            this.setNull(parameterIndex, -2);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, true);
            this.setType(binding, 252);
            binding.value = reader;
            binding.isNull = false;
            binding.isLongData = true;
            if (this.connection.getUseStreamLengthsInPrepStmts()) {
                binding.bindLength = length;
            }
            else {
                binding.bindLength = -1L;
            }
        }
    }
    
    public void setClob(final int parameterIndex, final Clob x) throws SQLException {
        this.checkClosed();
        if (x == null) {
            this.setNull(parameterIndex, -2);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, true);
            this.setType(binding, 252);
            binding.value = x.getCharacterStream();
            binding.isNull = false;
            binding.isLongData = true;
            if (this.connection.getUseStreamLengthsInPrepStmts()) {
                binding.bindLength = x.length();
            }
            else {
                binding.bindLength = -1L;
            }
        }
    }
    
    public void setDate(final int parameterIndex, final java.sql.Date x) throws SQLException {
        this.setDate(parameterIndex, x, null);
    }
    
    public void setDate(final int parameterIndex, final java.sql.Date x, final Calendar cal) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 91);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, false);
            this.setType(binding, 10);
            binding.value = x;
            binding.isNull = false;
            binding.isLongData = false;
        }
    }
    
    public void setDouble(final int parameterIndex, final double x) throws SQLException {
        this.checkClosed();
        if (!this.connection.getAllowNanAndInf() && (x == Double.POSITIVE_INFINITY || x == Double.NEGATIVE_INFINITY || Double.isNaN(x))) {
            throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009");
        }
        final BindValue binding = this.getBinding(parameterIndex, false);
        this.setType(binding, 5);
        binding.value = null;
        binding.doubleBinding = x;
        binding.isNull = false;
        binding.isLongData = false;
    }
    
    public void setFloat(final int parameterIndex, final float x) throws SQLException {
        this.checkClosed();
        final BindValue binding = this.getBinding(parameterIndex, false);
        this.setType(binding, 4);
        binding.value = null;
        binding.floatBinding = x;
        binding.isNull = false;
        binding.isLongData = false;
    }
    
    public void setInt(final int parameterIndex, final int x) throws SQLException {
        this.checkClosed();
        final BindValue binding = this.getBinding(parameterIndex, false);
        this.setType(binding, 3);
        binding.value = null;
        binding.intBinding = x;
        binding.isNull = false;
        binding.isLongData = false;
    }
    
    public void setLong(final int parameterIndex, final long x) throws SQLException {
        this.checkClosed();
        final BindValue binding = this.getBinding(parameterIndex, false);
        this.setType(binding, 8);
        binding.value = null;
        binding.longBinding = x;
        binding.isNull = false;
        binding.isLongData = false;
    }
    
    public void setNull(final int parameterIndex, final int sqlType) throws SQLException {
        this.checkClosed();
        final BindValue binding = this.getBinding(parameterIndex, false);
        if (binding.bufferType == 0) {
            this.setType(binding, 6);
        }
        binding.value = null;
        binding.isNull = true;
        binding.isLongData = false;
    }
    
    public void setNull(final int parameterIndex, final int sqlType, final String typeName) throws SQLException {
        this.checkClosed();
        final BindValue binding = this.getBinding(parameterIndex, false);
        if (binding.bufferType == 0) {
            this.setType(binding, 6);
        }
        binding.value = null;
        binding.isNull = true;
        binding.isLongData = false;
    }
    
    public void setRef(final int i, final Ref x) throws SQLException {
        throw new NotImplemented();
    }
    
    public void setShort(final int parameterIndex, final short x) throws SQLException {
        this.checkClosed();
        final BindValue binding = this.getBinding(parameterIndex, false);
        this.setType(binding, 2);
        binding.value = null;
        binding.shortBinding = x;
        binding.isNull = false;
        binding.isLongData = false;
    }
    
    public void setString(final int parameterIndex, final String x) throws SQLException {
        this.checkClosed();
        if (x == null) {
            this.setNull(parameterIndex, 1);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, false);
            this.setType(binding, this.stringTypeCode);
            binding.value = x;
            binding.isNull = false;
            binding.isLongData = false;
        }
    }
    
    public void setTime(final int parameterIndex, final Time x) throws SQLException {
        this.setTimeInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
    }
    
    public void setTime(final int parameterIndex, final Time x, final Calendar cal) throws SQLException {
        this.setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
    }
    
    public void setTimeInternal(final int parameterIndex, final Time x, final Calendar targetCalendar, final TimeZone tz, final boolean rollForward) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 92);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, false);
            this.setType(binding, 11);
            final Calendar sessionCalendar = this.getCalendarInstanceForSessionOrNew();
            synchronized (sessionCalendar) {
                binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
            }
            binding.isNull = false;
            binding.isLongData = false;
        }
    }
    
    public void setTimestamp(final int parameterIndex, final Timestamp x) throws SQLException {
        this.setTimestampInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
    }
    
    public void setTimestamp(final int parameterIndex, final Timestamp x, final Calendar cal) throws SQLException {
        this.setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
    }
    
    protected void setTimestampInternal(final int parameterIndex, final Timestamp x, final Calendar targetCalendar, final TimeZone tz, final boolean rollForward) throws SQLException {
        if (x == null) {
            this.setNull(parameterIndex, 93);
        }
        else {
            final BindValue binding = this.getBinding(parameterIndex, false);
            this.setType(binding, 12);
            final Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : this.getCalendarInstanceForSessionOrNew();
            synchronized (sessionCalendar) {
                binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
            }
            binding.isNull = false;
            binding.isLongData = false;
        }
    }
    
    private void setType(final BindValue oldValue, final int bufferType) {
        if (oldValue.bufferType != bufferType) {
            this.sendTypesToServer = true;
        }
        oldValue.bufferType = bufferType;
    }
    
    public void setUnicodeStream(final int parameterIndex, final InputStream x, final int length) throws SQLException {
        this.checkClosed();
        throw new NotImplemented();
    }
    
    public void setURL(final int parameterIndex, final URL x) throws SQLException {
        this.checkClosed();
        this.setString(parameterIndex, x.toString());
    }
    
    private void storeBinding(final Buffer packet, final BindValue bindValue, final MysqlIO mysql) throws SQLException {
        try {
            final Object value = bindValue.value;
            switch (bindValue.bufferType) {
                case 1: {
                    packet.writeByte(bindValue.byteBinding);
                }
                case 2: {
                    packet.ensureCapacity(2);
                    packet.writeInt(bindValue.shortBinding);
                }
                case 3: {
                    packet.ensureCapacity(4);
                    packet.writeLong(bindValue.intBinding);
                }
                case 8: {
                    packet.ensureCapacity(8);
                    packet.writeLongLong(bindValue.longBinding);
                }
                case 4: {
                    packet.ensureCapacity(4);
                    packet.writeFloat(bindValue.floatBinding);
                }
                case 5: {
                    packet.ensureCapacity(8);
                    packet.writeDouble(bindValue.doubleBinding);
                }
                case 11: {
                    this.storeTime(packet, (Time)value);
                }
                case 7:
                case 10:
                case 12: {
                    this.storeDateTime(packet, (Date)value, mysql);
                }
                case 0:
                case 15:
                case 246:
                case 253:
                case 254: {
                    if (value instanceof byte[]) {
                        packet.writeLenBytes((byte[])value);
                    }
                    else if (!this.isLoadDataQuery) {
                        packet.writeLenString((String)value, this.charEncoding, this.connection.getServerCharacterEncoding(), this.charConverter, this.connection.parserKnowsUnicode(), this.connection);
                    }
                    else {
                        packet.writeLenBytes(((String)value).getBytes());
                    }
                }
            }
        }
        catch (UnsupportedEncodingException uEE) {
            throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.22") + this.connection.getEncoding() + "'", "S1000");
        }
    }
    
    private void storeDataTime412AndOlder(final Buffer intoBuf, final Date dt) throws SQLException {
        final Calendar sessionCalendar = this.getCalendarInstanceForSessionOrNew();
        synchronized (sessionCalendar) {
            final Date oldTime = sessionCalendar.getTime();
            try {
                intoBuf.ensureCapacity(8);
                intoBuf.writeByte((byte)7);
                sessionCalendar.setTime(dt);
                final int year = sessionCalendar.get(1);
                final int month = sessionCalendar.get(2) + 1;
                final int date = sessionCalendar.get(5);
                intoBuf.writeInt(year);
                intoBuf.writeByte((byte)month);
                intoBuf.writeByte((byte)date);
                if (dt instanceof java.sql.Date) {
                    intoBuf.writeByte((byte)0);
                    intoBuf.writeByte((byte)0);
                    intoBuf.writeByte((byte)0);
                }
                else {
                    intoBuf.writeByte((byte)sessionCalendar.get(11));
                    intoBuf.writeByte((byte)sessionCalendar.get(12));
                    intoBuf.writeByte((byte)sessionCalendar.get(13));
                }
            }
            finally {
                sessionCalendar.setTime(oldTime);
            }
        }
    }
    
    private void storeDateTime(final Buffer intoBuf, final Date dt, final MysqlIO mysql) throws SQLException {
        if (this.connection.versionMeetsMinimum(4, 1, 3)) {
            this.storeDateTime413AndNewer(intoBuf, dt);
        }
        else {
            this.storeDataTime412AndOlder(intoBuf, dt);
        }
    }
    
    private void storeDateTime413AndNewer(final Buffer intoBuf, final Date dt) throws SQLException {
        final Calendar sessionCalendar = (dt instanceof Timestamp && this.connection.getUseJDBCCompliantTimezoneShift()) ? this.connection.getUtcCalendar() : this.getCalendarInstanceForSessionOrNew();
        synchronized (sessionCalendar) {
            final Date oldTime = sessionCalendar.getTime();
            try {
                sessionCalendar.setTime(dt);
                if (dt instanceof java.sql.Date) {
                    sessionCalendar.set(11, 0);
                    sessionCalendar.set(12, 0);
                    sessionCalendar.set(13, 0);
                }
                byte length = 7;
                if (dt instanceof Timestamp) {
                    length = 11;
                }
                intoBuf.ensureCapacity(length);
                intoBuf.writeByte(length);
                final int year = sessionCalendar.get(1);
                final int month = sessionCalendar.get(2) + 1;
                final int date = sessionCalendar.get(5);
                intoBuf.writeInt(year);
                intoBuf.writeByte((byte)month);
                intoBuf.writeByte((byte)date);
                if (dt instanceof java.sql.Date) {
                    intoBuf.writeByte((byte)0);
                    intoBuf.writeByte((byte)0);
                    intoBuf.writeByte((byte)0);
                }
                else {
                    intoBuf.writeByte((byte)sessionCalendar.get(11));
                    intoBuf.writeByte((byte)sessionCalendar.get(12));
                    intoBuf.writeByte((byte)sessionCalendar.get(13));
                }
                if (length == 11) {
                    intoBuf.writeLong(((Timestamp)dt).getNanos() / 1000);
                }
            }
            finally {
                sessionCalendar.setTime(oldTime);
            }
        }
    }
    
    private void storeReader(final MysqlIO mysql, final int parameterIndex, final Buffer packet, final Reader inStream) throws SQLException {
        final String forcedEncoding = this.connection.getClobCharacterEncoding();
        final String clobEncoding = (forcedEncoding == null) ? this.connection.getEncoding() : forcedEncoding;
        int maxBytesChar = 2;
        if (clobEncoding != null) {
            if (!clobEncoding.equals("UTF-16")) {
                maxBytesChar = this.connection.getMaxBytesPerChar(clobEncoding);
                if (maxBytesChar == 1) {
                    maxBytesChar = 2;
                }
            }
            else {
                maxBytesChar = 4;
            }
        }
        final char[] buf = new char[8192 / maxBytesChar];
        int numRead = 0;
        int bytesInPacket = 0;
        int totalBytesRead = 0;
        int bytesReadAtLastSend = 0;
        final int packetIsFullAt = this.connection.getBlobSendChunkSize();
        try {
            packet.clear();
            packet.writeByte((byte)24);
            packet.writeLong(this.serverStatementId);
            packet.writeInt(parameterIndex);
            boolean readAny = false;
            while ((numRead = inStream.read(buf)) != -1) {
                readAny = true;
                final byte[] valueAsBytes = StringUtils.getBytes(buf, null, clobEncoding, this.connection.getServerCharacterEncoding(), 0, numRead, this.connection.parserKnowsUnicode());
                packet.writeBytesNoNull(valueAsBytes, 0, valueAsBytes.length);
                bytesInPacket += valueAsBytes.length;
                totalBytesRead += valueAsBytes.length;
                if (bytesInPacket >= packetIsFullAt) {
                    bytesReadAtLastSend = totalBytesRead;
                    mysql.sendCommand(24, null, packet, true, null);
                    bytesInPacket = 0;
                    packet.clear();
                    packet.writeByte((byte)24);
                    packet.writeLong(this.serverStatementId);
                    packet.writeInt(parameterIndex);
                }
            }
            if (totalBytesRead != bytesReadAtLastSend) {
                mysql.sendCommand(24, null, packet, true, null);
            }
            if (!readAny) {
                mysql.sendCommand(24, null, packet, true, null);
            }
        }
        catch (IOException ioEx) {
            throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.24") + ioEx.toString(), "S1000");
        }
        finally {
            if (this.connection.getAutoClosePStmtStreams() && inStream != null) {
                try {
                    inStream.close();
                }
                catch (IOException ex) {}
            }
        }
    }
    
    private void storeStream(final MysqlIO mysql, final int parameterIndex, final Buffer packet, final InputStream inStream) throws SQLException {
        final byte[] buf = new byte[8192];
        int numRead = 0;
        try {
            int bytesInPacket = 0;
            int totalBytesRead = 0;
            int bytesReadAtLastSend = 0;
            final int packetIsFullAt = this.connection.getBlobSendChunkSize();
            packet.clear();
            packet.writeByte((byte)24);
            packet.writeLong(this.serverStatementId);
            packet.writeInt(parameterIndex);
            boolean readAny = false;
            while ((numRead = inStream.read(buf)) != -1) {
                readAny = true;
                packet.writeBytesNoNull(buf, 0, numRead);
                bytesInPacket += numRead;
                totalBytesRead += numRead;
                if (bytesInPacket >= packetIsFullAt) {
                    bytesReadAtLastSend = totalBytesRead;
                    mysql.sendCommand(24, null, packet, true, null);
                    bytesInPacket = 0;
                    packet.clear();
                    packet.writeByte((byte)24);
                    packet.writeLong(this.serverStatementId);
                    packet.writeInt(parameterIndex);
                }
            }
            if (totalBytesRead != bytesReadAtLastSend) {
                mysql.sendCommand(24, null, packet, true, null);
            }
            if (!readAny) {
                mysql.sendCommand(24, null, packet, true, null);
            }
        }
        catch (IOException ioEx) {
            throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.25") + ioEx.toString(), "S1000");
        }
        finally {
            if (this.connection.getAutoClosePStmtStreams() && inStream != null) {
                try {
                    inStream.close();
                }
                catch (IOException ex) {}
            }
        }
    }
    
    public String toString() {
        final StringBuffer toStringBuf = new StringBuffer();
        toStringBuf.append("com.mysql.jdbc.ServerPreparedStatement[");
        toStringBuf.append(this.serverStatementId);
        toStringBuf.append("] - ");
        try {
            toStringBuf.append(this.asSql());
        }
        catch (SQLException sqlEx) {
            toStringBuf.append(Messages.getString("ServerPreparedStatement.6"));
            toStringBuf.append(sqlEx);
        }
        return toStringBuf.toString();
    }
    
    protected long getServerStatementId() {
        return this.serverStatementId;
    }
    
    public synchronized boolean canRewriteAsMultivalueInsertStatement() {
        if (!super.canRewriteAsMultivalueInsertStatement()) {
            return false;
        }
        BindValue[] currentBindValues = null;
        final BindValue[] previousBindValues = null;
        for (int nbrCommands = this.batchedArgs.size(), commandIndex = 0; commandIndex < nbrCommands; ++commandIndex) {
            final Object arg = this.batchedArgs.get(commandIndex);
            if (!(arg instanceof String)) {
                currentBindValues = ((BatchedBindValues)arg).batchedParameterValues;
                if (previousBindValues != null) {
                    for (int j = 0; j < this.parameterBindings.length; ++j) {
                        if (currentBindValues[j].bufferType != previousBindValues[j].bufferType) {
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }
    
    protected long[] computeMaxParameterSetSizeAndBatchSize(final int numBatchedArgs) {
        long sizeOfEntireBatch = 10L;
        long maxSizeOfParameterSet = 0L;
        for (int i = 0; i < numBatchedArgs; ++i) {
            final BindValue[] paramArg = this.batchedArgs.get(i).batchedParameterValues;
            long sizeOfParameterSet = 0L;
            sizeOfParameterSet += (this.parameterCount + 7) / 8;
            sizeOfParameterSet += this.parameterCount * 2;
            for (int j = 0; j < this.parameterBindings.length; ++j) {
                if (!paramArg[j].isNull) {
                    final long size = paramArg[j].getBoundLength();
                    if (paramArg[j].isLongData) {
                        if (size != -1L) {
                            sizeOfParameterSet += size;
                        }
                    }
                    else {
                        sizeOfParameterSet += size;
                    }
                }
            }
            sizeOfEntireBatch += sizeOfParameterSet;
            if (sizeOfParameterSet > maxSizeOfParameterSet) {
                maxSizeOfParameterSet = sizeOfParameterSet;
            }
        }
        return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
    }
    
    protected int setOneBatchedParameterSet(final java.sql.PreparedStatement batchedStatement, int batchedParamIndex, final Object paramSet) throws SQLException {
        final BindValue[] paramArg = ((BatchedBindValues)paramSet).batchedParameterValues;
        for (int j = 0; j < paramArg.length; ++j) {
            if (paramArg[j].isNull) {
                batchedStatement.setNull(batchedParamIndex++, 0);
            }
            else if (paramArg[j].isLongData) {
                final Object value = paramArg[j].value;
                if (value instanceof InputStream) {
                    batchedStatement.setBinaryStream(batchedParamIndex++, (InputStream)value, (int)paramArg[j].bindLength);
                }
                else {
                    batchedStatement.setCharacterStream(batchedParamIndex++, (Reader)value, (int)paramArg[j].bindLength);
                }
            }
            else {
                switch (paramArg[j].bufferType) {
                    case 1: {
                        batchedStatement.setByte(batchedParamIndex++, paramArg[j].byteBinding);
                        break;
                    }
                    case 2: {
                        batchedStatement.setShort(batchedParamIndex++, paramArg[j].shortBinding);
                        break;
                    }
                    case 3: {
                        batchedStatement.setInt(batchedParamIndex++, paramArg[j].intBinding);
                        break;
                    }
                    case 8: {
                        batchedStatement.setLong(batchedParamIndex++, paramArg[j].longBinding);
                        break;
                    }
                    case 4: {
                        batchedStatement.setFloat(batchedParamIndex++, paramArg[j].floatBinding);
                        break;
                    }
                    case 5: {
                        batchedStatement.setDouble(batchedParamIndex++, paramArg[j].doubleBinding);
                        break;
                    }
                    case 11: {
                        batchedStatement.setTime(batchedParamIndex++, (Time)paramArg[j].value);
                        break;
                    }
                    case 10: {
                        batchedStatement.setDate(batchedParamIndex++, (java.sql.Date)paramArg[j].value);
                        break;
                    }
                    case 7:
                    case 12: {
                        batchedStatement.setTimestamp(batchedParamIndex++, (Timestamp)paramArg[j].value);
                        break;
                    }
                    case 0:
                    case 15:
                    case 246:
                    case 253:
                    case 254: {
                        final Object value = paramArg[j].value;
                        if (value instanceof byte[]) {
                            batchedStatement.setBytes(batchedParamIndex, (byte[])value);
                        }
                        else {
                            batchedStatement.setString(batchedParamIndex, (String)value);
                        }
                        final BindValue asBound = ((ServerPreparedStatement)batchedStatement).getBinding(batchedParamIndex + 1, false);
                        asBound.bufferType = paramArg[j].bufferType;
                        ++batchedParamIndex;
                        break;
                    }
                    default: {
                        throw new IllegalArgumentException("Unknown type when re-binding parameter into batched statement for parameter index " + batchedParamIndex);
                    }
                }
            }
        }
        return batchedParamIndex;
    }
    
    static class BatchedBindValues
    {
        BindValue[] batchedParameterValues;
        
        BatchedBindValues(final BindValue[] paramVals) {
            final int numParams = paramVals.length;
            this.batchedParameterValues = new BindValue[numParams];
            for (int i = 0; i < numParams; ++i) {
                this.batchedParameterValues[i] = new BindValue(paramVals[i]);
            }
        }
    }
    
    static class BindValue
    {
        long boundBeforeExecutionNum;
        long bindLength;
        int bufferType;
        byte byteBinding;
        double doubleBinding;
        float floatBinding;
        int intBinding;
        boolean isLongData;
        boolean isNull;
        boolean isSet;
        long longBinding;
        short shortBinding;
        Object value;
        
        BindValue() {
            this.boundBeforeExecutionNum = 0L;
            this.isSet = false;
        }
        
        BindValue(final BindValue copyMe) {
            this.boundBeforeExecutionNum = 0L;
            this.isSet = false;
            this.value = copyMe.value;
            this.isSet = copyMe.isSet;
            this.isLongData = copyMe.isLongData;
            this.isNull = copyMe.isNull;
            this.bufferType = copyMe.bufferType;
            this.bindLength = copyMe.bindLength;
            this.byteBinding = copyMe.byteBinding;
            this.shortBinding = copyMe.shortBinding;
            this.intBinding = copyMe.intBinding;
            this.longBinding = copyMe.longBinding;
            this.floatBinding = copyMe.floatBinding;
            this.doubleBinding = copyMe.doubleBinding;
        }
        
        void reset() {
            this.isSet = false;
            this.value = null;
            this.isLongData = false;
            this.byteBinding = 0;
            this.shortBinding = 0;
            this.intBinding = 0;
            this.longBinding = 0L;
            this.floatBinding = 0.0f;
            this.doubleBinding = 0.0;
        }
        
        public String toString() {
            return this.toString(false);
        }
        
        public String toString(final boolean quoteIfNeeded) {
            if (this.isLongData) {
                return "' STREAM DATA '";
            }
            switch (this.bufferType) {
                case 1: {
                    return String.valueOf(this.byteBinding);
                }
                case 2: {
                    return String.valueOf(this.shortBinding);
                }
                case 3: {
                    return String.valueOf(this.intBinding);
                }
                case 8: {
                    return String.valueOf(this.longBinding);
                }
                case 4: {
                    return String.valueOf(this.floatBinding);
                }
                case 5: {
                    return String.valueOf(this.doubleBinding);
                }
                case 7:
                case 10:
                case 11:
                case 12:
                case 15:
                case 253:
                case 254: {
                    if (quoteIfNeeded) {
                        return "'" + String.valueOf(this.value) + "'";
                    }
                    return String.valueOf(this.value);
                }
                default: {
                    if (this.value instanceof byte[]) {
                        return "byte data";
                    }
                    if (quoteIfNeeded) {
                        return "'" + String.valueOf(this.value) + "'";
                    }
                    return String.valueOf(this.value);
                }
            }
        }
        
        long getBoundLength() {
            if (this.isNull) {
                return 0L;
            }
            if (this.isLongData) {
                return this.bindLength;
            }
            switch (this.bufferType) {
                case 1: {
                    return 1L;
                }
                case 2: {
                    return 2L;
                }
                case 3: {
                    return 4L;
                }
                case 8: {
                    return 8L;
                }
                case 4: {
                    return 4L;
                }
                case 5: {
                    return 8L;
                }
                case 11: {
                    return 9L;
                }
                case 10: {
                    return 7L;
                }
                case 7:
                case 12: {
                    return 11L;
                }
                case 0:
                case 15:
                case 246:
                case 253:
                case 254: {
                    if (this.value instanceof byte[]) {
                        return ((byte[])this.value).length;
                    }
                    return ((String)this.value).length();
                }
                default: {
                    return 0L;
                }
            }
        }
    }
}
