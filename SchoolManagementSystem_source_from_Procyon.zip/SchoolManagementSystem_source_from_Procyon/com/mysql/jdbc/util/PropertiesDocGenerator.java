// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.util;

import java.sql.SQLException;
import com.mysql.jdbc.ConnectionProperties;

public class PropertiesDocGenerator extends ConnectionProperties
{
    public static void main(final String[] args) throws SQLException {
        System.out.println(new PropertiesDocGenerator().exposeAsXml());
    }
}
