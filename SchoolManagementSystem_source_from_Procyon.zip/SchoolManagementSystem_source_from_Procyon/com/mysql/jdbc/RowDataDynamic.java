// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import com.mysql.jdbc.profiler.ProfilerEvent;
import com.mysql.jdbc.profiler.ProfileEventSink;
import java.sql.SQLException;

public class RowDataDynamic implements RowData
{
    private int columnCount;
    private Field[] fields;
    private int index;
    private MysqlIO io;
    private boolean isAfterEnd;
    private boolean isAtEnd;
    private boolean isBinaryEncoded;
    private Object[] nextRow;
    private ResultSet owner;
    private boolean streamerClosed;
    private boolean wasEmpty;
    
    public RowDataDynamic(final MysqlIO io, final int colCount, final Field[] fields, final boolean isBinaryEncoded) throws SQLException {
        this.index = -1;
        this.isAfterEnd = false;
        this.isAtEnd = false;
        this.isBinaryEncoded = false;
        this.streamerClosed = false;
        this.wasEmpty = false;
        this.io = io;
        this.columnCount = colCount;
        this.isBinaryEncoded = isBinaryEncoded;
        this.fields = fields;
        this.nextRecord();
    }
    
    public void addRow(final byte[][] row) throws SQLException {
        this.notSupported();
    }
    
    public void afterLast() throws SQLException {
        this.notSupported();
    }
    
    public void beforeFirst() throws SQLException {
        this.notSupported();
    }
    
    public void beforeLast() throws SQLException {
        this.notSupported();
    }
    
    public void close() throws SQLException {
        boolean hadMore = false;
        int howMuchMore = 0;
        while (this.hasNext()) {
            this.next();
            hadMore = true;
            if (++howMuchMore % 100 == 0) {
                Thread.yield();
            }
        }
        if (this.owner != null) {
            final Connection conn = this.owner.connection;
            if (conn != null && conn.getUseUsageAdvisor() && hadMore) {
                final ProfileEventSink eventSink = ProfileEventSink.getInstance(conn);
                eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owner.owningStatement == null) ? "N/A" : this.owner.owningStatement.currentCatalog, this.owner.connectionId, (this.owner.owningStatement == null) ? -1 : this.owner.owningStatement.getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, null, Messages.getString("RowDataDynamic.2") + howMuchMore + Messages.getString("RowDataDynamic.3") + Messages.getString("RowDataDynamic.4") + Messages.getString("RowDataDynamic.5") + Messages.getString("RowDataDynamic.6") + this.owner.pointOfOrigin));
            }
        }
        this.fields = null;
        this.owner = null;
    }
    
    public Object[] getAt(final int ind) throws SQLException {
        this.notSupported();
        return null;
    }
    
    public int getCurrentRowNumber() throws SQLException {
        this.notSupported();
        return -1;
    }
    
    public ResultSet getOwner() {
        return this.owner;
    }
    
    public boolean hasNext() throws SQLException {
        final boolean hasNext = this.nextRow != null;
        if (!hasNext && !this.streamerClosed) {
            this.io.closeStreamer(this);
            this.streamerClosed = true;
        }
        return hasNext;
    }
    
    public boolean isAfterLast() throws SQLException {
        return this.isAfterEnd;
    }
    
    public boolean isBeforeFirst() throws SQLException {
        return this.index < 0;
    }
    
    public boolean isDynamic() {
        return true;
    }
    
    public boolean isEmpty() throws SQLException {
        this.notSupported();
        return false;
    }
    
    public boolean isFirst() throws SQLException {
        this.notSupported();
        return false;
    }
    
    public boolean isLast() throws SQLException {
        this.notSupported();
        return false;
    }
    
    public void moveRowRelative(final int rows) throws SQLException {
        this.notSupported();
    }
    
    public Object[] next() throws SQLException {
        if (this.index != Integer.MAX_VALUE) {
            ++this.index;
        }
        final Object[] ret = this.nextRow;
        this.nextRecord();
        return ret;
    }
    
    private void nextRecord() throws SQLException {
        try {
            if (!this.isAtEnd) {
                this.nextRow = this.io.nextRow(this.fields, this.columnCount, this.isBinaryEncoded, 1007);
                if (this.nextRow == null) {
                    this.isAtEnd = true;
                    if (this.index == -1) {
                        this.wasEmpty = true;
                    }
                }
            }
            else {
                this.isAfterEnd = true;
            }
        }
        catch (CommunicationsException comEx) {
            comEx.setWasStreamingResults();
            throw comEx;
        }
        catch (SQLException sqlEx) {
            throw sqlEx;
        }
        catch (Exception ex) {
            final String exceptionType = ex.getClass().getName();
            String exceptionMessage = ex.getMessage();
            exceptionMessage += Messages.getString("RowDataDynamic.7");
            exceptionMessage += Util.stackTraceToString(ex);
            throw new SQLException(Messages.getString("RowDataDynamic.8") + exceptionType + Messages.getString("RowDataDynamic.9") + exceptionMessage, "S1000");
        }
    }
    
    private void notSupported() throws SQLException {
        throw new OperationNotSupportedException();
    }
    
    public void removeRow(final int ind) throws SQLException {
        this.notSupported();
    }
    
    public void setCurrentRow(final int rowNumber) throws SQLException {
        this.notSupported();
    }
    
    public void setOwner(final ResultSet rs) {
        this.owner = rs;
    }
    
    public int size() {
        return -1;
    }
    
    public boolean wasEmpty() {
        return this.wasEmpty;
    }
    
    class OperationNotSupportedException extends SQLException
    {
        OperationNotSupportedException() {
            super(Messages.getString("RowDataDynamic.10"), "S1009");
        }
    }
}
