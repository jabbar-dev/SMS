// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.util.Hashtable;
import com.mysql.jdbc.exceptions.MySQLTransactionRollbackException;
import com.mysql.jdbc.exceptions.MySQLSyntaxErrorException;
import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;
import com.mysql.jdbc.exceptions.MySQLDataException;
import com.mysql.jdbc.exceptions.MySQLNonTransientConnectionException;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.HashMap;
import java.util.TreeMap;
import java.sql.DataTruncation;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.util.Map;

public class SQLError
{
    static final int ER_WARNING_NOT_COMPLETE_ROLLBACK = 1196;
    private static Map mysqlToSql99State;
    private static Map mysqlToSqlState;
    public static final String SQL_STATE_BASE_TABLE_NOT_FOUND = "S0002";
    public static final String SQL_STATE_BASE_TABLE_OR_VIEW_ALREADY_EXISTS = "S0001";
    public static final String SQL_STATE_BASE_TABLE_OR_VIEW_NOT_FOUND = "42S02";
    public static final String SQL_STATE_COLUMN_ALREADY_EXISTS = "S0021";
    public static final String SQL_STATE_COLUMN_NOT_FOUND = "S0022";
    public static final String SQL_STATE_COMMUNICATION_LINK_FAILURE = "08S01";
    public static final String SQL_STATE_CONNECTION_FAIL_DURING_TX = "08007";
    public static final String SQL_STATE_CONNECTION_IN_USE = "08002";
    public static final String SQL_STATE_CONNECTION_NOT_OPEN = "08003";
    public static final String SQL_STATE_CONNECTION_REJECTED = "08004";
    public static final String SQL_STATE_DATE_TRUNCATED = "01004";
    public static final String SQL_STATE_DATETIME_FIELD_OVERFLOW = "22008";
    public static final String SQL_STATE_DEADLOCK = "41000";
    public static final String SQL_STATE_DISCONNECT_ERROR = "01002";
    public static final String SQL_STATE_DIVISION_BY_ZERO = "22012";
    public static final String SQL_STATE_DRIVER_NOT_CAPABLE = "S1C00";
    public static final String SQL_STATE_ERROR_IN_ROW = "01S01";
    public static final String SQL_STATE_GENERAL_ERROR = "S1000";
    public static final String SQL_STATE_ILLEGAL_ARGUMENT = "S1009";
    public static final String SQL_STATE_INDEX_ALREADY_EXISTS = "S0011";
    public static final String SQL_STATE_INDEX_NOT_FOUND = "S0012";
    public static final String SQL_STATE_INSERT_VALUE_LIST_NO_MATCH_COL_LIST = "21S01";
    public static final String SQL_STATE_INVALID_AUTH_SPEC = "28000";
    public static final String SQL_STATE_INVALID_CHARACTER_VALUE_FOR_CAST = "22018";
    public static final String SQL_STATE_INVALID_COLUMN_NUMBER = "S1002";
    public static final String SQL_STATE_INVALID_CONNECTION_ATTRIBUTE = "01S00";
    public static final String SQL_STATE_MEMORY_ALLOCATION_FAILURE = "S1001";
    public static final String SQL_STATE_MORE_THAN_ONE_ROW_UPDATED_OR_DELETED = "01S04";
    public static final String SQL_STATE_NO_DEFAULT_FOR_COLUMN = "S0023";
    public static final String SQL_STATE_NO_ROWS_UPDATED_OR_DELETED = "01S03";
    public static final String SQL_STATE_NUMERIC_VALUE_OUT_OF_RANGE = "22003";
    public static final String SQL_STATE_PRIVILEGE_NOT_REVOKED = "01006";
    public static final String SQL_STATE_SYNTAX_ERROR = "42000";
    public static final String SQL_STATE_TIMEOUT_EXPIRED = "S1T00";
    public static final String SQL_STATE_TRANSACTION_RESOLUTION_UNKNOWN = "08007";
    public static final String SQL_STATE_UNABLE_TO_CONNECT_TO_DATASOURCE = "08001";
    public static final String SQL_STATE_WRONG_NO_OF_PARAMETERS = "07001";
    public static final String SQL_STATE_INVALID_TRANSACTION_TERMINATION = "2D000";
    private static Map sqlStateMessages;
    
    static SQLWarning convertShowWarningsToSQLWarnings(final Connection connection) throws SQLException {
        return convertShowWarningsToSQLWarnings(connection, 0, false);
    }
    
    static SQLWarning convertShowWarningsToSQLWarnings(final Connection connection, final int warningCountIfKnown, final boolean forTruncationOnly) throws SQLException {
        Statement stmt = null;
        ResultSet warnRs = null;
        SQLWarning currentWarning = null;
        try {
            if (warningCountIfKnown < 100) {
                stmt = connection.createStatement();
                if (stmt.getMaxRows() != 0) {
                    stmt.setMaxRows(0);
                }
            }
            else {
                stmt = connection.createStatement(1003, 1007);
                stmt.setFetchSize(Integer.MIN_VALUE);
            }
            warnRs = stmt.executeQuery("SHOW WARNINGS");
            while (warnRs.next()) {
                final int code = warnRs.getInt("Code");
                if (forTruncationOnly) {
                    if (code != 1265 && code != 1264) {
                        continue;
                    }
                    final DataTruncation newTruncation = new MysqlDataTruncation(warnRs.getString("Message"), 0, false, false, 0, 0);
                    if (currentWarning == null) {
                        currentWarning = newTruncation;
                    }
                    else {
                        currentWarning.setNextWarning(newTruncation);
                    }
                }
                else {
                    final String level = warnRs.getString("Level");
                    final String message = warnRs.getString("Message");
                    final SQLWarning newWarning = new SQLWarning(message, mysqlToSqlState(code, connection.getUseSqlStateCodes()), code);
                    if (currentWarning == null) {
                        currentWarning = newWarning;
                    }
                    else {
                        currentWarning.setNextWarning(newWarning);
                    }
                }
            }
            if (forTruncationOnly && currentWarning != null) {
                throw currentWarning;
            }
            return currentWarning;
        }
        finally {
            SQLException reThrow = null;
            if (warnRs != null) {
                try {
                    warnRs.close();
                }
                catch (SQLException sqlEx) {
                    reThrow = sqlEx;
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                }
                catch (SQLException sqlEx) {
                    reThrow = sqlEx;
                }
            }
            if (reThrow != null) {
                throw reThrow;
            }
        }
    }
    
    public static void dumpSqlStatesMappingsAsXml() throws Exception {
        final TreeMap allErrorNumbers = new TreeMap();
        final Map mysqlErrorNumbersToNames = new HashMap();
        Integer errorNumber = null;
        Iterator mysqlErrorNumbers = SQLError.mysqlToSql99State.keySet().iterator();
        while (mysqlErrorNumbers.hasNext()) {
            errorNumber = mysqlErrorNumbers.next();
            allErrorNumbers.put(errorNumber, errorNumber);
        }
        mysqlErrorNumbers = SQLError.mysqlToSqlState.keySet().iterator();
        while (mysqlErrorNumbers.hasNext()) {
            errorNumber = mysqlErrorNumbers.next();
            allErrorNumbers.put(errorNumber, errorNumber);
        }
        final Field[] possibleFields = MysqlErrorNumbers.class.getDeclaredFields();
        for (int i = 0; i < possibleFields.length; ++i) {
            final String fieldName = possibleFields[i].getName();
            if (fieldName.startsWith("ER_")) {
                mysqlErrorNumbersToNames.put(possibleFields[i].get(null), fieldName);
            }
        }
        System.out.println("<ErrorMappings>");
        final Iterator allErrorNumbersIter = allErrorNumbers.keySet().iterator();
        while (allErrorNumbersIter.hasNext()) {
            errorNumber = allErrorNumbersIter.next();
            final String sql92State = mysqlToSql99(errorNumber);
            final String oldSqlState = mysqlToXOpen(errorNumber);
            System.out.println("   <ErrorMapping mysqlErrorNumber=\"" + errorNumber + "\" mysqlErrorName=\"" + mysqlErrorNumbersToNames.get(errorNumber) + "\" legacySqlState=\"" + ((oldSqlState == null) ? "" : oldSqlState) + "\" sql92SqlState=\"" + ((sql92State == null) ? "" : sql92State) + "\"/>");
        }
        System.out.println("</ErrorMappings>");
    }
    
    static String get(final String stateCode) {
        return SQLError.sqlStateMessages.get(stateCode);
    }
    
    private static String mysqlToSql99(final int errno) {
        final Integer err = new Integer(errno);
        if (SQLError.mysqlToSql99State.containsKey(err)) {
            return SQLError.mysqlToSql99State.get(err);
        }
        return "HY000";
    }
    
    static String mysqlToSqlState(final int errno, final boolean useSql92States) {
        if (useSql92States) {
            return mysqlToSql99(errno);
        }
        return mysqlToXOpen(errno);
    }
    
    private static String mysqlToXOpen(final int errno) {
        final Integer err = new Integer(errno);
        if (SQLError.mysqlToSqlState.containsKey(err)) {
            return SQLError.mysqlToSqlState.get(err);
        }
        return "S1000";
    }
    
    public static SQLException createSQLException(final String message, final String sqlState) {
        if (sqlState != null) {
            if (sqlState.startsWith("08")) {
                return new MySQLNonTransientConnectionException(message, sqlState);
            }
            if (sqlState.startsWith("22")) {
                return new MySQLDataException(message, sqlState);
            }
            if (sqlState.startsWith("23")) {
                return new MySQLIntegrityConstraintViolationException(message, sqlState);
            }
            if (sqlState.startsWith("42")) {
                return new MySQLSyntaxErrorException(message, sqlState);
            }
            if (sqlState.startsWith("40")) {
                return new MySQLTransactionRollbackException(message, sqlState);
            }
        }
        return new SQLException(message, sqlState);
    }
    
    public static SQLException createSQLException(final String message) {
        return new SQLException(message);
    }
    
    public static SQLException createSQLException(final String message, final String sqlState, final int vendorErrorCode) {
        if (sqlState != null) {
            if (sqlState.startsWith("08")) {
                return new MySQLNonTransientConnectionException(message, sqlState, vendorErrorCode);
            }
            if (sqlState.startsWith("22")) {
                return new MySQLDataException(message, sqlState, vendorErrorCode);
            }
            if (sqlState.startsWith("23")) {
                return new MySQLIntegrityConstraintViolationException(message, sqlState, vendorErrorCode);
            }
            if (sqlState.startsWith("42")) {
                return new MySQLSyntaxErrorException(message, sqlState, vendorErrorCode);
            }
            if (sqlState.startsWith("40")) {
                return new MySQLTransactionRollbackException(message, sqlState, vendorErrorCode);
            }
        }
        return new SQLException(message, sqlState, vendorErrorCode);
    }
    
    static {
        (SQLError.sqlStateMessages = new HashMap()).put("01002", Messages.getString("SQLError.35"));
        SQLError.sqlStateMessages.put("01004", Messages.getString("SQLError.36"));
        SQLError.sqlStateMessages.put("01006", Messages.getString("SQLError.37"));
        SQLError.sqlStateMessages.put("01S00", Messages.getString("SQLError.38"));
        SQLError.sqlStateMessages.put("01S01", Messages.getString("SQLError.39"));
        SQLError.sqlStateMessages.put("01S03", Messages.getString("SQLError.40"));
        SQLError.sqlStateMessages.put("01S04", Messages.getString("SQLError.41"));
        SQLError.sqlStateMessages.put("07001", Messages.getString("SQLError.42"));
        SQLError.sqlStateMessages.put("08001", Messages.getString("SQLError.43"));
        SQLError.sqlStateMessages.put("08002", Messages.getString("SQLError.44"));
        SQLError.sqlStateMessages.put("08003", Messages.getString("SQLError.45"));
        SQLError.sqlStateMessages.put("08004", Messages.getString("SQLError.46"));
        SQLError.sqlStateMessages.put("08007", Messages.getString("SQLError.47"));
        SQLError.sqlStateMessages.put("08S01", Messages.getString("SQLError.48"));
        SQLError.sqlStateMessages.put("21S01", Messages.getString("SQLError.49"));
        SQLError.sqlStateMessages.put("22003", Messages.getString("SQLError.50"));
        SQLError.sqlStateMessages.put("22008", Messages.getString("SQLError.51"));
        SQLError.sqlStateMessages.put("22012", Messages.getString("SQLError.52"));
        SQLError.sqlStateMessages.put("41000", Messages.getString("SQLError.53"));
        SQLError.sqlStateMessages.put("28000", Messages.getString("SQLError.54"));
        SQLError.sqlStateMessages.put("42000", Messages.getString("SQLError.55"));
        SQLError.sqlStateMessages.put("42S02", Messages.getString("SQLError.56"));
        SQLError.sqlStateMessages.put("S0001", Messages.getString("SQLError.57"));
        SQLError.sqlStateMessages.put("S0002", Messages.getString("SQLError.58"));
        SQLError.sqlStateMessages.put("S0011", Messages.getString("SQLError.59"));
        SQLError.sqlStateMessages.put("S0012", Messages.getString("SQLError.60"));
        SQLError.sqlStateMessages.put("S0021", Messages.getString("SQLError.61"));
        SQLError.sqlStateMessages.put("S0022", Messages.getString("SQLError.62"));
        SQLError.sqlStateMessages.put("S0023", Messages.getString("SQLError.63"));
        SQLError.sqlStateMessages.put("S1000", Messages.getString("SQLError.64"));
        SQLError.sqlStateMessages.put("S1001", Messages.getString("SQLError.65"));
        SQLError.sqlStateMessages.put("S1002", Messages.getString("SQLError.66"));
        SQLError.sqlStateMessages.put("S1009", Messages.getString("SQLError.67"));
        SQLError.sqlStateMessages.put("S1C00", Messages.getString("SQLError.68"));
        SQLError.sqlStateMessages.put("S1T00", Messages.getString("SQLError.69"));
        (SQLError.mysqlToSqlState = new Hashtable()).put(new Integer(1040), "08004");
        SQLError.mysqlToSqlState.put(new Integer(1042), "08004");
        SQLError.mysqlToSqlState.put(new Integer(1043), "08004");
        SQLError.mysqlToSqlState.put(new Integer(1047), "08S01");
        SQLError.mysqlToSqlState.put(new Integer(1081), "08S01");
        SQLError.mysqlToSqlState.put(new Integer(1129), "08004");
        SQLError.mysqlToSqlState.put(new Integer(1130), "08004");
        SQLError.mysqlToSqlState.put(new Integer(1045), "28000");
        SQLError.mysqlToSqlState.put(new Integer(1037), "S1001");
        SQLError.mysqlToSqlState.put(new Integer(1038), "S1001");
        SQLError.mysqlToSqlState.put(new Integer(1064), "42000");
        SQLError.mysqlToSqlState.put(new Integer(1065), "42000");
        SQLError.mysqlToSqlState.put(new Integer(1055), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1056), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1057), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1059), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1060), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1061), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1062), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1063), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1066), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1067), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1068), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1069), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1070), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1071), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1072), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1073), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1074), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1075), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1082), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1083), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1084), "S1009");
        SQLError.mysqlToSqlState.put(new Integer(1058), "21S01");
        SQLError.mysqlToSqlState.put(new Integer(1051), "42S02");
        SQLError.mysqlToSqlState.put(new Integer(1054), "S0022");
        SQLError.mysqlToSqlState.put(new Integer(1205), "41000");
        SQLError.mysqlToSqlState.put(new Integer(1213), "41000");
        (SQLError.mysqlToSql99State = new HashMap()).put(new Integer(1205), "41000");
        SQLError.mysqlToSql99State.put(new Integer(1213), "41000");
        SQLError.mysqlToSql99State.put(new Integer(1022), "23000");
        SQLError.mysqlToSql99State.put(new Integer(1037), "HY001");
        SQLError.mysqlToSql99State.put(new Integer(1038), "HY001");
        SQLError.mysqlToSql99State.put(new Integer(1040), "08004");
        SQLError.mysqlToSql99State.put(new Integer(1042), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1043), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1044), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1045), "28000");
        SQLError.mysqlToSql99State.put(new Integer(1050), "42S01");
        SQLError.mysqlToSql99State.put(new Integer(1051), "42S02");
        SQLError.mysqlToSql99State.put(new Integer(1052), "23000");
        SQLError.mysqlToSql99State.put(new Integer(1053), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1054), "42S22");
        SQLError.mysqlToSql99State.put(new Integer(1055), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1056), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1057), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1058), "21S01");
        SQLError.mysqlToSql99State.put(new Integer(1059), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1060), "42S21");
        SQLError.mysqlToSql99State.put(new Integer(1061), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1062), "23000");
        SQLError.mysqlToSql99State.put(new Integer(1063), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1064), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1065), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1066), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1067), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1068), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1069), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1070), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1071), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1072), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1073), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1074), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1075), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1080), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1081), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1082), "42S12");
        SQLError.mysqlToSql99State.put(new Integer(1083), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1084), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1090), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1091), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1101), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1102), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1103), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1104), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1106), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1107), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1109), "42S02");
        SQLError.mysqlToSql99State.put(new Integer(1110), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1112), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1113), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1115), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1118), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1120), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1121), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1131), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1132), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1133), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1136), "21S01");
        SQLError.mysqlToSql99State.put(new Integer(1138), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1139), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1140), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1141), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1142), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1143), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1144), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1145), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1146), "42S02");
        SQLError.mysqlToSql99State.put(new Integer(1147), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1148), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1149), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1152), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1153), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1154), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1155), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1156), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1157), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1158), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1159), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1160), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1161), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1162), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1163), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1164), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1166), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1167), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1169), "23000");
        SQLError.mysqlToSql99State.put(new Integer(1170), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1171), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1172), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1173), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1177), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1178), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1179), "25000");
        SQLError.mysqlToSql99State.put(new Integer(1184), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1189), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1190), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1203), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1207), "25000");
        SQLError.mysqlToSql99State.put(new Integer(1211), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1213), "40001");
        SQLError.mysqlToSql99State.put(new Integer(1216), "23000");
        SQLError.mysqlToSql99State.put(new Integer(1217), "23000");
        SQLError.mysqlToSql99State.put(new Integer(1218), "08S01");
        SQLError.mysqlToSql99State.put(new Integer(1222), "21000");
        SQLError.mysqlToSql99State.put(new Integer(1226), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1230), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1231), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1232), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1234), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1235), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1239), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1241), "21000");
        SQLError.mysqlToSql99State.put(new Integer(1242), "21000");
        SQLError.mysqlToSql99State.put(new Integer(1247), "42S22");
        SQLError.mysqlToSql99State.put(new Integer(1248), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1249), "01000");
        SQLError.mysqlToSql99State.put(new Integer(1250), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1251), "08004");
        SQLError.mysqlToSql99State.put(new Integer(1252), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1253), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1261), "01000");
        SQLError.mysqlToSql99State.put(new Integer(1262), "01000");
        SQLError.mysqlToSql99State.put(new Integer(1263), "01000");
        SQLError.mysqlToSql99State.put(new Integer(1264), "01000");
        SQLError.mysqlToSql99State.put(new Integer(1265), "01000");
        SQLError.mysqlToSql99State.put(new Integer(1280), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1281), "42000");
        SQLError.mysqlToSql99State.put(new Integer(1286), "42000");
    }
}
