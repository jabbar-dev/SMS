// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

interface WriterWatcher
{
    void writerClosed(final WatchableWriter p0);
}
