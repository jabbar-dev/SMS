// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.sql.ResultSetMetaData;
import java.util.Map;

class CachedResultSetMetaData
{
    Map columnNameToIndex;
    Field[] fields;
    Map fullColumnNameToIndex;
    ResultSetMetaData metadata;
    
    CachedResultSetMetaData() {
        this.columnNameToIndex = null;
        this.fullColumnNameToIndex = null;
    }
}
