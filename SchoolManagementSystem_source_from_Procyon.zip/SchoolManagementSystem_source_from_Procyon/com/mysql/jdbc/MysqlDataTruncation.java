// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.sql.DataTruncation;

public class MysqlDataTruncation extends DataTruncation
{
    private String message;
    
    public MysqlDataTruncation(final String message, final int index, final boolean parameter, final boolean read, final int dataSize, final int transferSize) {
        super(index, parameter, read, dataSize, transferSize);
        this.message = message;
    }
    
    public String getMessage() {
        return super.getMessage() + ": " + this.message;
    }
}
