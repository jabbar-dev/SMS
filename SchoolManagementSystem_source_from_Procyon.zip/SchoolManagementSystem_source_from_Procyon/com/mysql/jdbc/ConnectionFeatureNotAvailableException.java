// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

public class ConnectionFeatureNotAvailableException extends CommunicationsException
{
    public ConnectionFeatureNotAvailableException(final Connection conn, final long lastPacketSentTimeMs, final Exception underlyingException) {
        super(conn, lastPacketSentTimeMs, underlyingException);
    }
    
    public String getMessage() {
        return "Feature not available in this distribution of Connector/J";
    }
    
    public String getSQLState() {
        return "01S00";
    }
}
