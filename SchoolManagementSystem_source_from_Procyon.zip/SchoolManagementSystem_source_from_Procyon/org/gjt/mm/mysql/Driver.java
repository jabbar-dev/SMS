// 
// Decompiled by Procyon v0.5.36
// 

package org.gjt.mm.mysql;

import java.sql.SQLException;

public class Driver extends com.mysql.jdbc.Driver
{
    public Driver() throws SQLException {
    }
}
