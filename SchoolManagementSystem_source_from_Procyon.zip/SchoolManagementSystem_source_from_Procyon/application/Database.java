// 
// Decompiled by Procyon v0.5.36
// 

package application;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

public class Database
{
    public static void main(final String[] args) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata", "root", "");
            final Statement st = con.createStatement();
            final String sql = "SELECT * FROM `students` WHERE `Name` LIKE 'Abdul Jabbar Shah' ";
            st.executeQuery(sql);
        }
        catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }
}
