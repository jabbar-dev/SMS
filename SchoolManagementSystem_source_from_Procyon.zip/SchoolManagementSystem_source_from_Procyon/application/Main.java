// 
// Decompiled by Procyon v0.5.36
// 

package application;

import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.Stage;
import javafx.application.Application;

public class Main extends Application
{
    public void start(final Stage primaryStage) {
        try {
            final Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("/application/Login.fxml"));
            final Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.show();
            primaryStage.setTitle("Login");
            primaryStage.setResizable(false);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void main(final String[] args) {
        launch(args);
    }
}
