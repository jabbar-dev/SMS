// 
// Decompiled by Procyon v0.5.36
// 

package application;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class SearchClassController
{
    @FXML
    private Label validate;
    @FXML
    private Label RollNum;
    @FXML
    private Label Name;
    @FXML
    private Label FName;
    @FXML
    private Label Caste;
    @FXML
    private Label Religion;
    @FXML
    private Label ClassName;
    @FXML
    private Label Address;
    @FXML
    private Label GuardianNumber;
    @FXML
    private Label DOB;
    @FXML
    private Label CNIC;
    @FXML
    private Label PlaceOfBirth;
    @FXML
    private Label Nationality;
    @FXML
    private Label LastSchool;
    @FXML
    private TextField searchbar;
    @FXML
    private Button search;
    
    public void Search(final ActionEvent event) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata", "root", "");
            final Statement st = con.createStatement();
            final String sql = "SELECT * FROM `students` WHERE `Class` LIKE '" + this.searchbar.getText() + "'";
            final ResultSet rs = st.executeQuery(sql);
            boolean check = false;
            String N = "";
            String R = "";
            String F = "";
            String C = "";
            String RL = "";
            String CN = "";
            String A = "";
            String GN = "";
            String D = "";
            String CNI = "";
            String P = "";
            String NE = "";
            String LI = "";
            while (rs.next()) {
                N = String.valueOf(N) + rs.getString("Name") + "\n\n";
                this.Name.setWrapText(true);
                this.Name.setText(N);
                this.RollNum.setWrapText(true);
                R = String.valueOf(R) + rs.getString("RollNumber") + "\n\n";
                this.RollNum.setText(R);
                this.FName.setWrapText(true);
                F = String.valueOf(F) + rs.getString("FatherName") + "\n\n";
                this.FName.setText(F);
                this.Caste.setWrapText(true);
                C = String.valueOf(C) + rs.getString("Caste") + "\n\n";
                this.Caste.setText(C);
                this.Religion.setWrapText(true);
                RL = String.valueOf(RL) + rs.getString("Religion") + "\n\n";
                this.Religion.setText(RL);
                this.ClassName.setWrapText(true);
                CN = String.valueOf(CN) + rs.getString("Class") + "\n\n";
                this.ClassName.setText(CN);
                this.Address.setWrapText(true);
                A = String.valueOf(A) + rs.getString("Address") + "\n\n";
                this.Address.setText(A);
                this.GuardianNumber.setWrapText(true);
                GN = String.valueOf(GN) + rs.getString("GuardianContact") + "\n\n";
                this.GuardianNumber.setText(GN);
                this.DOB.setWrapText(true);
                D = String.valueOf(D) + rs.getString("DateOfBirth") + "\n\n";
                this.DOB.setText(D);
                this.CNIC.setWrapText(true);
                CNI = String.valueOf(CNI) + rs.getString("GuardianCNIC") + "\n\n";
                this.CNIC.setText(CNI);
                this.PlaceOfBirth.setWrapText(true);
                P = String.valueOf(P) + rs.getString("PlaceOfBirth") + "\n\n";
                this.PlaceOfBirth.setText(P);
                this.Nationality.setWrapText(true);
                NE = String.valueOf(NE) + rs.getString("Nationality") + "\n\n";
                this.Nationality.setText(NE);
                this.LastSchool.setWrapText(true);
                LI = String.valueOf(LI) + rs.getString("LastSchool") + "\n\n";
                this.LastSchool.setText(LI);
                check = true;
                this.validate.setText("");
            }
            if (this.searchbar.getText().equals("")) {
                this.validate.setText("Search Bar Cannot Be Empty");
            }
            if (!check) {
                this.validate.setText("No Such Student Found");
            }
        }
        catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }
}
