// 
// Decompiled by Procyon v0.5.36
// 

package application;

import java.util.ResourceBundle;
import java.net.URL;
import java.util.Collection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.time.LocalDate;
import java.sql.DriverManager;
import javafx.event.ActionEvent;
import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;

public class AddStudentController implements Initializable
{
    ObservableList list;
    @FXML
    private DatePicker DOB;
    @FXML
    private TextField RollNumber;
    @FXML
    private TextField StudentName;
    @FXML
    private TextField FatherName;
    @FXML
    private TextField Caste;
    @FXML
    private ChoiceBox<?> Gender;
    @FXML
    private TextField Religion;
    @FXML
    private TextField GuardianNumber;
    @FXML
    private TextField PlaceOfBirth;
    @FXML
    private TextField GCNIC;
    @FXML
    private TextField Nationality;
    @FXML
    private TextArea Address;
    @FXML
    private TextField LastInstitute;
    @FXML
    private CheckBox StudentCheck;
    @FXML
    private Button SubmitStudent;
    @FXML
    private Label StudentStatus;
    @FXML
    private TextField ClassName;
    
    public AddStudentController() {
        this.list = FXCollections.observableArrayList();
    }
    
    public void SubmitStudent(final ActionEvent event) throws Exception {
        String Error = "";
        if (this.DOB.getValue() == null) {
            Error = String.valueOf(Error) + "Date of Birth ";
        }
        if (this.RollNumber.getText().equals("")) {
            Error = String.valueOf(Error) + "Roll Number \n";
        }
        if (this.StudentName.getText().equals("")) {
            Error = String.valueOf(Error) + "Student Name ";
        }
        if (this.FatherName.getText().equals("")) {
            Error = String.valueOf(Error) + "Father Name \n";
        }
        if (this.Caste.getText().equals("")) {
            Error = String.valueOf(Error) + "Caste ";
        }
        if (this.Gender.getValue() == null) {
            Error = String.valueOf(Error) + "Gender \n";
        }
        if (this.Religion.getText().equals("")) {
            Error = String.valueOf(Error) + "Religion ";
        }
        if (this.ClassName.getText().equals("")) {
            Error = String.valueOf(Error) + "Class \n";
        }
        if (this.Address.getText().equals("")) {
            Error = String.valueOf(Error) + "Address ";
        }
        if (this.GuardianNumber.getText().equals("")) {
            Error = String.valueOf(Error) + "Guardian Number: \n ";
        }
        if (this.GCNIC.getText().equals("")) {
            Error = String.valueOf(Error) + "Guardian CNIC ";
        }
        if (this.PlaceOfBirth.getText().equals("")) {
            Error = String.valueOf(Error) + "Place of Birth  \n";
        }
        if (this.Nationality.getText().equals("")) {
            Error = String.valueOf(Error) + "Nationality ";
        }
        if (this.LastInstitute.getText().equals("")) {
            Error = String.valueOf(Error) + "Last Insititute \n";
        }
        if (!this.StudentCheck.isSelected()) {
            Error = String.valueOf(Error) + "\nPlease Accept the Terms and Conditions";
        }
        if (this.RollNumber.getText().equals("") | this.StudentName.getText().equals("") | this.FatherName.getText().equals("") | this.Caste.getText().equals("") | this.Address.getText().equals("") | this.GuardianNumber.getText().equals("") | this.DOB.getValue() == null | this.GCNIC.getText().equals("") | this.PlaceOfBirth.getText().equals("") | this.Nationality.getText().equals("") | this.LastInstitute.getText().equals("") | !this.StudentCheck.isSelected()) {
            final String BigError = "Please Fill Following Fields to Continue: \n" + Error;
            this.StudentStatus.setText(BigError);
        }
        else {
            Class.forName("com.mysql.jdbc.Driver");
            final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata", "root", "");
            final Statement st = con.createStatement();
            final String sql3 = "Select * from students where RollNumber='" + this.RollNumber.getText() + "'";
            final ResultSet rs = st.executeQuery(sql3);
            if (!rs.next()) {
                final String sql4 = "INSERT INTO students (RollNumber, Name, FatherName, Caste, Gender, Religion, Class, Address, GuardianContact, DateOfBirth, GuardianCNIC, PlaceOfBirth, Nationality, LastSchool)values(+'" + this.RollNumber.getText() + "'" + "," + "'" + this.StudentName.getText() + "'" + "," + "'" + this.FatherName.getText() + "'" + "," + "'" + this.Caste.getText() + "'" + "," + "'" + this.Gender.getValue().toString() + "'" + "," + "'" + this.Religion.getText() + "'" + "," + "'" + this.ClassName.getText() + "'" + "," + "'" + this.Address.getText() + "'" + "," + "'" + this.GuardianNumber.getText() + "'" + "," + "'" + ((LocalDate)this.DOB.getValue()).toString() + "'" + "," + "'" + this.GCNIC.getText() + "'" + "," + "'" + this.PlaceOfBirth.getText() + "'" + "," + "'" + this.Nationality.getText() + "'" + "," + "'" + this.LastInstitute.getText() + "'" + ")";
                st.executeUpdate(sql4);
                this.StudentStatus.setText("Registration was Successfull");
                this.RollNumber.clear();
                this.StudentName.clear();
                this.FatherName.clear();
                this.Caste.clear();
                this.Gender.setValue((Object)null);
                this.Religion.clear();
                this.ClassName.clear();
                this.Address.clear();
                this.GuardianNumber.clear();
                this.DOB.setValue((Object)null);
                this.GCNIC.clear();
                this.PlaceOfBirth.clear();
                this.Nationality.clear();
                this.LastInstitute.clear();
            }
            else {
                this.StudentStatus.setText("Roll Number Already Exist \n Choose New One");
            }
        }
    }
    
    public void loadData() {
        this.list.removeAll((Collection)this.list);
        final String Male = "Male";
        final String Female = "Female";
        final String non = "Non Specified";
        this.list.addAll(new Object[] { Male, Female, non });
        this.Gender.getItems().addAll((Collection)this.list);
    }
    
    public void initialize(final URL arg0, final ResourceBundle arg1) {
        this.loadData();
    }
}
