// 
// Decompiled by Procyon v0.5.36
// 

package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import java.util.ResourceBundle;
import java.net.URL;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.fxml.Initializable;

public class DashboardController implements Initializable
{
    @FXML
    private Label dlabel;
    MainController mc;
    
    public DashboardController() {
        this.mc = new MainController();
    }
    
    public void SearchById() throws Exception {
        final Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("/application/SearchById.fxml"));
        final Scene scene = new Scene(root);
        final Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("Search By Id");
    }
    
    public void AboutUs() throws Exception {
        final Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("/application/AboutUs.fxml"));
        final Scene scene = new Scene(root);
        final Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("About Us");
    }
    
    public void SearchByName() throws Exception {
        final Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("/application/StudentByName.fxml"));
        final Scene scene = new Scene(root);
        final Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("Search By Name");
    }
    
    public void SearchByClass() throws Exception {
        final Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("/application/SearchClass.fxml"));
        final Scene scene = new Scene(root);
        final Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("Search By Class");
    }
    
    public void initialize(final URL arg0, final ResourceBundle arg1) {
    }
    
    public void logout(final ActionEvent event) throws Exception {
        this.mc.Exit(event);
    }
    
    public void setText(final String user) {
        this.dlabel.setText(user);
    }
    
    public void AddStudent(final ActionEvent event) throws IOException {
        final Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("/application/AddStudent.fxml"));
        final Scene scene = new Scene(root);
        final Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("Add Student's Record");
    }
}
