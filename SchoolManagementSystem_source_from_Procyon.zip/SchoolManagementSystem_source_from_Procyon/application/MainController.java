// 
// Decompiled by Procyon v0.5.36
// 

package application;

import java.util.ResourceBundle;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import java.sql.DriverManager;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.fxml.Initializable;

public class MainController implements Initializable
{
    public boolean database;
    String user;
    @FXML
    private Label conlabel;
    @FXML
    private Label status;
    @FXML
    private TextField uname;
    public String username;
    @FXML
    private TextField password;
    @FXML
    private Label dlabel;
    
    public MainController() {
        this.database = true;
        this.user = "";
    }
    
    public void Exit(final ActionEvent event) {
        System.exit(0);
    }
    
    public void Login(final ActionEvent event) throws Exception {
        try {
            if (this.database) {
                Class.forName("com.mysql.jdbc.Driver");
                final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata", "root", "");
                final Statement st = con.createStatement();
                final String sql = "Select * from login where Username='" + this.uname.getText() + "' and Password='" + this.password.getText() + "'";
                final ResultSet rs = st.executeQuery(sql);
                if (this.uname.getText().equals("")) {
                    this.uname.setText(" ");
                }
                if (rs.next() & !this.uname.getText().equals(" ")) {
                    this.status.setText("Login Successful");
                    final FXMLLoader loader = new FXMLLoader(this.getClass().getResource("/application/Dashboard.fxml"));
                    final Parent root = (Parent)loader.load();
                    final DashboardController sc = (DashboardController)loader.getController();
                    sc.setText("WELCOME " + this.uname.getText().toUpperCase());
                    final Scene scene = new Scene(root);
                    final Stage primaryStage = new Stage();
                    primaryStage.setScene(scene);
                    primaryStage.show();
                    primaryStage.setResizable(false);
                    primaryStage.setTitle("Dashboard School Management System");
                    this.uname.clear();
                    this.password.clear();
                }
            }
            if (!this.database) {
                this.status.setText("Database is Not Connected");
            }
            if (this.uname.getText().equals(" ")) {
                this.status.setText("Please Enter Username or Password");
            }
            else {
                this.status.setText("INVALID Username or Password");
            }
        }
        catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }
    
    public void Register(final ActionEvent event) throws Exception {
        try {
            final Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("/application/Register.fxml"));
            final Scene scene = new Scene(root);
            final Stage primaryStage = new Stage();
            primaryStage.setScene(scene);
            primaryStage.show();
            primaryStage.setTitle("Register");
        }
        catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }
    
    public void initialize(final URL arg0, final ResourceBundle arg1) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata", "root", "");
            this.database = true;
            this.conlabel.setText("Database is Connected*");
        }
        catch (Exception e) {
            this.database = false;
            this.conlabel.setText("Database is Disconnected");
        }
    }
}
