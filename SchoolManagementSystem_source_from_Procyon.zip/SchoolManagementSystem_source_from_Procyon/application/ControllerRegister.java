// 
// Decompiled by Procyon v0.5.36
// 

package application;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.application.Application;

public class ControllerRegister
{
    Application primaryStage;
    @FXML
    private Label status;
    @FXML
    private TextField euname;
    @FXML
    private TextField epassword;
    @FXML
    private CheckBox check;
    @FXML
    private TextField name;
    @FXML
    private TextArea address;
    @FXML
    private TextField email;
    @FXML
    private TextField cnic;
    @FXML
    private DatePicker dob;
    
    public void Back(final ActionEvent event) throws Exception {
        final Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("/application/Login.fxml"));
        final Scene scene = new Scene(root);
        final Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("Login");
    }
    
    public void Submit(final ActionEvent event) throws Exception {
        String error = "";
        if (this.euname.getText().equals("")) {
            error = String.valueOf(error) + "Username ";
        }
        if (this.name.getText().equals("")) {
            error = String.valueOf(error) + "Name ";
        }
        if (this.email.getText().equals("")) {
            error = String.valueOf(error) + "Email ";
        }
        if (this.epassword.getText().equals("")) {
            error = String.valueOf(error) + "Password ";
        }
        if (this.cnic.getText().equals("")) {
            error = String.valueOf(error) + "CNIC ";
        }
        if (this.address.getText().equals("")) {
            error = String.valueOf(error) + "Address ";
        }
        if (this.dob.getValue() == null) {
            error = String.valueOf(error) + "Date of Birth ";
        }
        if (!this.check.isSelected()) {
            error = String.valueOf(error) + " \nPlease Accept Terms and Conditions ";
        }
        if (this.name.getText().equals("") | this.euname.getText().equals("") | this.epassword.getText().equals("") | this.address.getText().equals("") | this.cnic.getText().equals("") | this.email.getText().equals("") | this.dob.getValue() == null) {
            final String FinalError = "Please Fill Following Areas: \n" + error;
            this.status.setText(FinalError);
        }
        else {
            final String Username = this.euname.getText();
            final String Password = this.epassword.getText();
            Class.forName("com.mysql.jdbc.Driver");
            final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata", "root", "");
            final Statement st = con.createStatement();
            if (!(this.name.getText().equals("") | this.euname.getText().equals("") | this.epassword.getText().equals("") | this.address.getText().equals("") | this.cnic.getText().equals("") | this.email.getText().equals("") | this.dob.getValue() == null)) {
                final String sql2 = "Select * from login where Username='" + this.euname.getText() + "'";
                final ResultSet rs = st.executeQuery(sql2);
                if (!rs.next()) {
                    final String sql3 = "INSERT INTO login(Username, Password) values (+'" + Username + "'" + "," + "'" + Password + "'" + ") ";
                    st.executeUpdate(sql3);
                    this.status.setText("Congratulations! You are Successfully Registered\nBack to Login");
                    this.euname.clear();
                    this.epassword.clear();
                    this.name.clear();
                    this.email.clear();
                    this.cnic.clear();
                    this.address.clear();
                    this.check.setSelected(false);
                    this.dob.setValue((Object)null);
                }
                else {
                    this.status.setText("Username Already Exist Please Choose New One");
                }
            }
        }
    }
}
